# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------


#
# Delete any existing table `wp_bp_activity`
#

DROP TABLE IF EXISTS `wp_bp_activity`;


#
# Table structure of table `wp_bp_activity`
#

CREATE TABLE `wp_bp_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `component` varchar(75) NOT NULL,
  `type` varchar(75) NOT NULL,
  `action` text NOT NULL,
  `content` longtext NOT NULL,
  `primary_link` varchar(255) NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `date_recorded` datetime NOT NULL,
  `hide_sitewide` tinyint(1) DEFAULT '0',
  `mptt_left` int(11) NOT NULL DEFAULT '0',
  `mptt_right` int(11) NOT NULL DEFAULT '0',
  `is_spam` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_recorded` (`date_recorded`),
  KEY `user_id` (`user_id`),
  KEY `item_id` (`item_id`),
  KEY `secondary_item_id` (`secondary_item_id`),
  KEY `component` (`component`),
  KEY `type` (`type`),
  KEY `mptt_left` (`mptt_left`),
  KEY `mptt_right` (`mptt_right`),
  KEY `hide_sitewide` (`hide_sitewide`),
  KEY `is_spam` (`is_spam`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_bp_activity (3 records)
#
 
INSERT INTO `wp_bp_activity` VALUES (1, 1, 'members', 'last_activity', '', '', '', 0, NULL, '2014-10-15 01:29:09', 0, 0, 0, 0) ; 
INSERT INTO `wp_bp_activity` VALUES (2, 2, 'members', 'last_activity', '', '', '', 0, NULL, '2014-08-27 19:21:16', 0, 0, 0, 0) ; 
INSERT INTO `wp_bp_activity` VALUES (3, 2, 'activity', 'activity_update', '<a href="http://localhost:8888/members/mcfombrun/" title="marie f">marie f</a> posted an update', '<a href=\'http://localhost:8888/members/rfombrun/\' rel=\'nofollow\'>@rfombrun</a> lookin good with that hat. which festival was that pic taken at?', 'http://localhost:8888/members/mcfombrun/', 0, 0, '2014-08-27 17:53:51', 0, 0, 0, 0) ;
#
# End of data contents of table wp_bp_activity
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------


#
# Delete any existing table `wp_bp_activity_meta`
#

DROP TABLE IF EXISTS `wp_bp_activity_meta`;


#
# Table structure of table `wp_bp_activity_meta`
#

CREATE TABLE `wp_bp_activity_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `activity_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `activity_id` (`activity_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_bp_activity_meta (1 records)
#
 
INSERT INTO `wp_bp_activity_meta` VALUES (1, 3, 'favorite_count', '1') ;
#
# End of data contents of table wp_bp_activity_meta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------


#
# Delete any existing table `wp_bp_notifications`
#

DROP TABLE IF EXISTS `wp_bp_notifications`;


#
# Table structure of table `wp_bp_notifications`
#

CREATE TABLE `wp_bp_notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `component_name` varchar(75) NOT NULL,
  `component_action` varchar(75) NOT NULL,
  `date_notified` datetime NOT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `secondary_item_id` (`secondary_item_id`),
  KEY `user_id` (`user_id`),
  KEY `is_new` (`is_new`),
  KEY `component_name` (`component_name`),
  KEY `component_action` (`component_action`),
  KEY `useritem` (`user_id`,`is_new`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_bp_notifications (1 records)
#
 
INSERT INTO `wp_bp_notifications` VALUES (1, 1, 3, 2, 'activity', 'new_at_mention', '2014-08-27 17:53:51', 0) ;
#
# End of data contents of table wp_bp_notifications
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------


#
# Delete any existing table `wp_bp_xprofile_data`
#

DROP TABLE IF EXISTS `wp_bp_xprofile_data`;


#
# Table structure of table `wp_bp_xprofile_data`
#

CREATE TABLE `wp_bp_xprofile_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `value` longtext NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_bp_xprofile_data (3 records)
#
 
INSERT INTO `wp_bp_xprofile_data` VALUES (1, 1, 1, 'rfombrun', '2014-06-04 17:13:40') ; 
INSERT INTO `wp_bp_xprofile_data` VALUES (2, 1, 2, 'marie f', '2014-08-27 17:43:32') ; 
INSERT INTO `wp_bp_xprofile_data` VALUES (3, 1, 3, 'carron w', '2014-08-27 17:41:53') ;
#
# End of data contents of table wp_bp_xprofile_data
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------


#
# Delete any existing table `wp_bp_xprofile_fields`
#

DROP TABLE IF EXISTS `wp_bp_xprofile_fields`;


#
# Table structure of table `wp_bp_xprofile_fields`
#

CREATE TABLE `wp_bp_xprofile_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL,
  `type` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` longtext NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_default_option` tinyint(1) NOT NULL DEFAULT '0',
  `field_order` bigint(20) NOT NULL DEFAULT '0',
  `option_order` bigint(20) NOT NULL DEFAULT '0',
  `order_by` varchar(15) NOT NULL DEFAULT '',
  `can_delete` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `parent_id` (`parent_id`),
  KEY `field_order` (`field_order`),
  KEY `can_delete` (`can_delete`),
  KEY `is_required` (`is_required`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_bp_xprofile_fields (1 records)
#
 
INSERT INTO `wp_bp_xprofile_fields` VALUES (1, 1, 0, 'textbox', 'Name', '', 1, 0, 0, 0, '', 0) ;
#
# End of data contents of table wp_bp_xprofile_fields
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------


#
# Delete any existing table `wp_bp_xprofile_groups`
#

DROP TABLE IF EXISTS `wp_bp_xprofile_groups`;


#
# Table structure of table `wp_bp_xprofile_groups`
#

CREATE TABLE `wp_bp_xprofile_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `description` mediumtext NOT NULL,
  `group_order` bigint(20) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `can_delete` (`can_delete`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_bp_xprofile_groups (1 records)
#
 
INSERT INTO `wp_bp_xprofile_groups` VALUES (1, 'Base', '', 0, 0) ;
#
# End of data contents of table wp_bp_xprofile_groups
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------


#
# Delete any existing table `wp_bp_xprofile_meta`
#

DROP TABLE IF EXISTS `wp_bp_xprofile_meta`;


#
# Table structure of table `wp_bp_xprofile_meta`
#

CREATE TABLE `wp_bp_xprofile_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) NOT NULL,
  `object_type` varchar(150) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_bp_xprofile_meta (0 records)
#

#
# End of data contents of table wp_bp_xprofile_meta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (4 records)
#
 
INSERT INTO `wp_commentmeta` VALUES (1, 9, 'rating', '3') ; 
INSERT INTO `wp_commentmeta` VALUES (2, 10, 'rating', '1') ; 
INSERT INTO `wp_commentmeta` VALUES (3, 11, 'rating', '2') ; 
INSERT INTO `wp_commentmeta` VALUES (4, 12, 'rating', '3') ;
#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (12 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-05-26 22:33:13', '2014-05-26 22:33:13', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (2, 152, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-07-29 16:03:14', '2014-07-29 16:03:14', 'Haven\'t decided if I hate this single yet, but I def don\'t like it.', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (3, 122, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-07-29 16:13:50', '2014-07-29 16:13:50', 'Why would I want to ship my idea when I can fax it? :-P', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (4, 95, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-07-29 16:15:34', '2014-07-29 16:15:34', 'Enjoying this little black shirt more than my little black dress! Go Ninja!!!!', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (5, 152, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-09-12 21:09:00', '2014-09-12 21:09:00', 'Am I going crazy? Why can\'t I see any comments?', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.120 Safari/537.36', '', 2, 1) ; 
INSERT INTO `wp_comments` VALUES (6, 122, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-09-12 21:31:57', '2014-09-12 21:31:57', 'take 2 at getting a reply comment to show up', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.120 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (7, 165, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-09-21 03:56:46', '2014-09-21 03:56:46', 'well, does this work?', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.122 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (8, 122, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-09-23 00:39:52', '2014-09-23 00:39:52', 'I wonder if debug bar will notice this post?', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.122 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (9, 101, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-09-29 01:00:53', '2014-09-29 01:00:53', 'it\'s gray. not much more to say. womp womp', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (10, 152, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-09-29 01:02:43', '2014-09-29 01:02:43', 'Will I get PT for a 3rd review left on this same item?', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (11, 152, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-09-29 01:04:28', '2014-09-29 01:04:28', 'Turns out that 1out of 5 was the first review. The other so-called reviews must atually have been comments NOT reviews. Anywho, will the system reward me with PT for the 2nd review I write on this same woo single  #2. This time I rate it 2 out of 5.', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36', '', 0, 1) ; 
INSERT INTO `wp_comments` VALUES (12, 122, 'rfombrun', 'rfombrun@gmail.com', '', '::1', '2014-10-07 02:02:06', '2014-10-07 02:02:06', 'hey shamma! isn\'t this website greatttt!', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36', '', 0, 1) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------


#
# Delete any existing table `wp_myCRED_log`
#

DROP TABLE IF EXISTS `wp_myCRED_log`;


#
# Table structure of table `wp_myCRED_log`
#

CREATE TABLE `wp_myCRED_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(256) NOT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `creds` decimal(22,2) DEFAULT NULL,
  `ctype` varchar(64) DEFAULT 'mycred_default',
  `time` bigint(20) DEFAULT NULL,
  `entry` longtext,
  `data` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_myCRED_log (14 records)
#
 
INSERT INTO `wp_myCRED_log` VALUES (1, 'approved_comment', 2, 1, '10.00', 'mycred_default', 1406649794, '%plural% for Writing Review aka Approved Comment', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (2, 'approved_comment', 3, 1, '10.00', 'mycred_default', 1406650430, '%plural% for Writing Review aka Approved Comment', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (3, 'approved_comment', 4, 1, '2000.00', 'mycred_default', 1406650534, '%plural% for Writing Review aka Approved Comment', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (4, 'registration', 2, 2, '100.00', 'mycred_default', 1409161247, '%plural% for becoming a member', 'a:1:{s:8:"ref_type";s:4:"user";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (5, 'registration', 3, 3, '100.00', 'mycred_default', 1409161313, '%plural% for becoming a member', 'a:1:{s:8:"ref_type";s:4:"user";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (6, 'product_review', 5, 1, '10.00', 'mycred_default', 1410556141, '%plural% for product review', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (7, 'product_review', 6, 1, '10.00', 'mycred_default', 1410557517, '%plural% for product review', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (8, 'approved_comment', 7, 1, '1.00', 'mycred_default', 1411271806, '%plural% for Approved Comment', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (9, 'product_review', 8, 1, '10.00', 'mycred_default', 1411432792, '%plural% for product review', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (10, 'approved_comment', 9, 1, '1.00', 'mycred_default', 1411952453, '%plural% for Approved Comment', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (11, 'product_review', 9, 1, '10.00', 'mycred_default', 1411952453, '%plural% for product review', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (12, 'product_review', 10, 1, '10.00', 'mycred_default', 1411952563, '%plural% for product review', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (13, 'product_review', 11, 1, '10.00', 'mycred_default', 1411952669, '%plural% for product review', 'a:1:{s:8:"ref_type";s:7:"comment";}') ; 
INSERT INTO `wp_myCRED_log` VALUES (14, 'product_review', 12, 1, '10.00', 'mycred_default', 1412647326, '%plural% for product review', 'a:1:{s:8:"ref_type";s:7:"comment";}') ;
#
# End of data contents of table wp_myCRED_log
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6786 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (392 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost:8888/prettytendr/htdocs', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'PrettyTendr', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'The Currency of Beauty', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'rfombrun@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'comment_moderation', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (32, 'active_plugins', 'a:3:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:17:"mycred/mycred.php";i:2;s:27:"woocommerce/woocommerce.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'home', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', 'a:5:{i:0;s:63:"/Applications/MAMP/htdocs/wp-content/themes/cwhite-pt/style.css";i:1;s:64:"/Applications/MAMP/htdocs/wp-content/themes/cwhite-pt/footer.php";i:2;s:64:"/Applications/MAMP/htdocs/wp-content/themes/cwhite-pt/header.php";i:4;s:72:"/Applications/MAMP/htdocs/wp-content/themes/html5blank-master/header.php";i:5;s:71:"/Applications/MAMP/htdocs/wp-content/themes/html5blank-master/style.css";}', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'twentyfourteen', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'twentyfourteen', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '30133', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:1:{s:17:"mycred/mycred.php";s:23:"mycred_plugin_uninstall";}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '218', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'initial_db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:132:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:3:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"delete_posts";b:0;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:110:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-1";a:0:{}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'cron', 'a:12:{i:1419120000;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1419130800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1419138829;a:1:{s:29:"wp_session_garbage_collection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1419147240;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1419150433;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1419154162;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1419157998;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1419187088;a:1:{s:16:"mycred_reset_key";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1419193265;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1419201229;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1419202800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (127, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (190, 'bp-deactivated-components', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (191, 'bb-config-location', '/Applications/MAMP/htdocs/bb-config.php', 'yes') ; 
INSERT INTO `wp_options` VALUES (192, 'bp-xprofile-base-group-name', 'Base', 'yes') ; 
INSERT INTO `wp_options` VALUES (193, 'bp-xprofile-fullname-field-name', 'Name', 'yes') ; 
INSERT INTO `wp_options` VALUES (194, 'bp-blogs-first-install', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (195, 'bp-disable-profile-sync', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (196, 'hide-loggedout-adminbar', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (197, 'bp-disable-avatar-uploads', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (198, 'bp-disable-account-deletion', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (199, 'bp-disable-blogforum-comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (200, '_bp_theme_package_id', 'legacy', 'yes') ; 
INSERT INTO `wp_options` VALUES (201, 'bp_restrict_group_creation', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (202, '_bp_enable_akismet', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (203, '_bp_enable_heartbeat_refresh', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (204, '_bp_force_buddybar', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (205, '_bp_retain_bp_default', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (206, 'widget_bp_core_login_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (207, 'widget_bp_core_members_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (208, 'widget_bp_core_whos_online_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (209, 'widget_bp_core_recently_active_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (210, 'widget_bp_groups_widget', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (211, 'widget_bp_messages_sitewide_notices_widget', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (216, 'woocommerce_default_country', 'US:NJ', 'yes') ; 
INSERT INTO `wp_options` VALUES (217, 'woocommerce_allowed_countries', 'specific', 'yes') ; 
INSERT INTO `wp_options` VALUES (218, 'woocommerce_specific_allowed_countries', 'a:1:{i:0;s:2:"US";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (219, 'woocommerce_demo_store', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (220, 'woocommerce_demo_store_notice', 'This is a demo store for testing purposes — no orders shall be fulfilled.', 'no') ; 
INSERT INTO `wp_options` VALUES (221, 'woocommerce_api_enabled', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (222, 'woocommerce_currency', 'USD', 'yes') ; 
INSERT INTO `wp_options` VALUES (223, 'woocommerce_currency_pos', 'left', 'yes') ; 
INSERT INTO `wp_options` VALUES (224, 'woocommerce_price_thousand_sep', ',', 'yes') ; 
INSERT INTO `wp_options` VALUES (225, 'woocommerce_price_decimal_sep', '.', 'yes') ; 
INSERT INTO `wp_options` VALUES (226, 'woocommerce_price_num_decimals', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (227, 'woocommerce_enable_lightbox', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (228, 'woocommerce_enable_chosen', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (229, 'woocommerce_shop_page_id', '6', 'yes') ; 
INSERT INTO `wp_options` VALUES (230, 'woocommerce_shop_page_display', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (231, 'woocommerce_category_archive_display', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (232, 'woocommerce_default_catalog_orderby', 'menu_order', 'yes') ; 
INSERT INTO `wp_options` VALUES (233, 'woocommerce_cart_redirect_after_add', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (234, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (235, 'woocommerce_weight_unit', 'lbs', 'yes') ; 
INSERT INTO `wp_options` VALUES (236, 'woocommerce_dimension_unit', 'in', 'yes') ; 
INSERT INTO `wp_options` VALUES (237, 'woocommerce_enable_review_rating', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (238, 'woocommerce_review_rating_required', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (239, 'woocommerce_review_rating_verification_label', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (240, 'woocommerce_review_rating_verification_required', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (241, 'shop_catalog_image_size', 'a:2:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (242, 'shop_single_image_size', 'a:2:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (243, 'shop_thumbnail_image_size', 'a:2:{s:5:"width";s:2:"90";s:6:"height";s:2:"90";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (244, 'woocommerce_file_download_method', 'force', 'no') ; 
INSERT INTO `wp_options` VALUES (245, 'woocommerce_downloads_require_login', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (246, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (247, 'woocommerce_manage_stock', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (248, 'woocommerce_hold_stock_minutes', '60', 'no') ; 
INSERT INTO `wp_options` VALUES (249, 'woocommerce_notify_low_stock', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (250, 'woocommerce_notify_no_stock', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (251, 'woocommerce_stock_email_recipient', 'rfombrun@gmail.com', 'no') ; 
INSERT INTO `wp_options` VALUES (252, 'woocommerce_notify_low_stock_amount', '2', 'no') ; 
INSERT INTO `wp_options` VALUES (253, 'woocommerce_notify_no_stock_amount', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (254, 'woocommerce_hide_out_of_stock_items', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (255, 'woocommerce_stock_format', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (256, 'woocommerce_calc_taxes', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (257, 'woocommerce_prices_include_tax', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (258, 'woocommerce_tax_based_on', 'shipping', 'yes') ; 
INSERT INTO `wp_options` VALUES (259, 'woocommerce_default_customer_address', 'base', 'yes') ; 
INSERT INTO `wp_options` VALUES (260, 'woocommerce_shipping_tax_class', 'title', 'yes') ; 
INSERT INTO `wp_options` VALUES (261, 'woocommerce_tax_round_at_subtotal', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (262, 'woocommerce_tax_classes', 'Reduced Rate
Zero Rate', 'yes') ; 
INSERT INTO `wp_options` VALUES (263, 'woocommerce_tax_display_shop', 'excl', 'yes') ; 
INSERT INTO `wp_options` VALUES (264, 'woocommerce_price_display_suffix', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (265, 'woocommerce_tax_display_cart', 'excl', 'no') ; 
INSERT INTO `wp_options` VALUES (266, 'woocommerce_tax_total_display', 'itemized', 'no') ; 
INSERT INTO `wp_options` VALUES (267, 'woocommerce_enable_coupons', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (268, 'woocommerce_enable_guest_checkout', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (269, 'woocommerce_force_ssl_checkout', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (270, 'woocommerce_unforce_ssl_checkout', 'no', 'yes') ; 
INSERT INTO `wp_options` VALUES (271, 'woocommerce_cart_page_id', '7', 'yes') ; 
INSERT INTO `wp_options` VALUES (272, 'woocommerce_checkout_page_id', '8', 'yes') ; 
INSERT INTO `wp_options` VALUES (273, 'woocommerce_terms_page_id', '', 'no') ; 
INSERT INTO `wp_options` VALUES (274, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes') ; 
INSERT INTO `wp_options` VALUES (275, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes') ; 
INSERT INTO `wp_options` VALUES (276, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes') ; 
INSERT INTO `wp_options` VALUES (277, 'woocommerce_calc_shipping', 'yes', 'yes') ; 
INSERT INTO `wp_options` VALUES (278, 'woocommerce_enable_shipping_calc', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (279, 'woocommerce_shipping_cost_requires_address', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (280, 'woocommerce_shipping_method_format', '', 'no') ; 
INSERT INTO `wp_options` VALUES (281, 'woocommerce_ship_to_billing', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (282, 'woocommerce_ship_to_billing_address_only', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (283, 'woocommerce_ship_to_countries', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (284, 'woocommerce_specific_ship_to_countries', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (285, 'woocommerce_myaccount_page_id', '9', 'yes') ; 
INSERT INTO `wp_options` VALUES (286, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes') ; 
INSERT INTO `wp_options` VALUES (287, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes') ; 
INSERT INTO `wp_options` VALUES (288, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes') ; 
INSERT INTO `wp_options` VALUES (289, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes') ; 
INSERT INTO `wp_options` VALUES (290, 'woocommerce_logout_endpoint', 'customer-logout', 'yes') ; 
INSERT INTO `wp_options` VALUES (291, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (292, 'woocommerce_enable_myaccount_registration', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (293, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (294, 'woocommerce_registration_generate_username', 'yes', 'no') ; 
INSERT INTO `wp_options` VALUES (295, 'woocommerce_registration_generate_password', 'no', 'no') ; 
INSERT INTO `wp_options` VALUES (296, 'woocommerce_email_from_name', 'PrettyTendr', 'no') ; 
INSERT INTO `wp_options` VALUES (297, 'woocommerce_email_from_address', 'rfombrun@gmail.com', 'no') ; 
INSERT INTO `wp_options` VALUES (298, 'woocommerce_email_header_image', '', 'no') ; 
INSERT INTO `wp_options` VALUES (299, 'woocommerce_email_footer_text', 'PrettyTendr - Powered by WooCommerce', 'no') ; 
INSERT INTO `wp_options` VALUES (300, 'woocommerce_email_base_color', '#557da1', 'no') ; 
INSERT INTO `wp_options` VALUES (301, 'woocommerce_email_background_color', '#f5f5f5', 'no') ; 
INSERT INTO `wp_options` VALUES (302, 'woocommerce_email_body_background_color', '#fdfdfd', 'no') ; 
INSERT INTO `wp_options` VALUES (303, 'woocommerce_email_text_color', '#505050', 'no') ; 
INSERT INTO `wp_options` VALUES (305, 'woocommerce_db_version', '2.2.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (306, 'woocommerce_version', '2.2.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (310, 'PMXI_Plugin_Options', 'a:22:{s:18:"history_file_count";i:10000;s:16:"history_file_age";i:365;s:15:"highlight_limit";i:10000;s:19:"upload_max_filesize";i:2048;s:13:"post_max_size";i:2048;s:14:"max_input_time";i:-1;s:18:"max_execution_time";i:-1;s:7:"dismiss";i:0;s:18:"dismiss_manage_top";i:0;s:21:"dismiss_manage_bottom";i:0;s:13:"html_entities";i:0;s:11:"utf8_decode";i:0;s:12:"cron_job_key";s:9:"05FqeoCi6";s:10:"chunk_size";i:32;s:9:"pingbacks";i:1;s:33:"legacy_special_character_handling";i:1;s:14:"case_sensitive";i:1;s:12:"session_mode";s:7:"default";s:17:"enable_ftp_import";i:0;s:16:"large_feed_limit";i:1000;s:33:"enable_cron_processing_time_limit";i:0;s:26:"cron_processing_time_limit";i:120;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (311, 'PMWI_Plugin_Options', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (313, '_transient_timeout_woocommerce_processing_order_count', '1433438010', 'no') ; 
INSERT INTO `wp_options` VALUES (314, '_transient_woocommerce_processing_order_count', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (316, '_transient_random_seed', '5a95fd3a7f1e291fb75a961f4219a47e', 'yes') ; 
INSERT INTO `wp_options` VALUES (317, 'registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (318, 'bp-active-components', 'a:5:{s:8:"activity";i:1;s:7:"members";i:1;s:8:"settings";i:1;s:8:"xprofile";i:1;s:13:"notifications";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (319, 'bp-pages', 'a:4:{s:8:"activity";i:4;s:7:"members";i:5;s:8:"register";i:9;s:8:"activate";i:185;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (320, '_bp_db_version', '8311', 'yes') ; 
INSERT INTO `wp_options` VALUES (323, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (327, 'mycred_version_db', '1.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (328, 'mycred_pref_core', 'a:10:{s:7:"cred_id";s:14:"mycred_default";s:6:"format";a:3:{s:4:"type";s:7:"decimal";s:8:"decimals";i:2;s:10:"separators";a:2:{s:7:"decimal";s:1:".";s:8:"thousand";s:0:"";}}s:4:"name";a:2:{s:8:"singular";s:2:"PT";s:6:"plural";s:2:"PT";}s:6:"before";s:0:"";s:5:"after";s:0:"";s:4:"caps";a:2:{s:6:"plugin";s:14:"manage_options";s:5:"creds";s:6:"export";}s:3:"max";s:4:"0.00";s:7:"exclude";a:3:{s:14:"plugin_editors";i:0;s:12:"cred_editors";i:0;s:4:"list";s:0:"";}s:11:"delete_user";i:0;s:10:"buddypress";a:8:{s:16:"balance_location";s:0:"";s:10:"visibility";a:2:{s:7:"balance";b:0;s:7:"history";b:0;}s:16:"history_location";s:0:"";s:16:"balance_template";s:17:"%plural% balance:";s:18:"history_menu_title";a:2:{s:2:"me";s:10:"My History";s:6:"others";s:12:"%s\'s History";}s:16:"history_menu_pos";i:99;s:11:"history_url";s:14:"mycred-history";s:11:"history_num";i:10;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (329, 'mycred_setup_completed', '1401903562', 'yes') ; 
INSERT INTO `wp_options` VALUES (330, 'mycred_pref_hooks', 'a:3:{s:9:"installed";a:8:{s:12:"registration";a:3:{s:5:"title";s:26:"%plural% for registrations";s:11:"description";s:47:"Award %_plural% for users joining your website.";s:8:"callback";a:1:{i:0;s:24:"myCRED_Hook_Registration";}}s:10:"logging_in";a:3:{s:5:"title";s:19:"%plural% for logins";s:11:"description";s:83:"Award %_plural% for logging in to your website. You can also set an optional limit.";s:8:"callback";a:1:{i:0;s:22:"myCRED_Hook_Logging_In";}}s:18:"publishing_content";a:3:{s:5:"title";s:31:"%plural% for publishing content";s:11:"description";s:134:"Award %_plural% for publishing content on your website. If your custom post type is not shown bellow, make sure it is set to "Public".";s:8:"callback";a:1:{i:0;s:30:"myCRED_Hook_Publishing_Content";}}s:8:"comments";a:3:{s:5:"title";s:21:"%plural% for comments";s:11:"description";s:36:"Award %_plural% for making comments.";s:8:"callback";a:1:{i:0;s:20:"myCRED_Hook_Comments";}}s:10:"link_click";a:3:{s:5:"title";s:30:"%plural% for clicking on links";s:11:"description";s:86:"Award %_plural% to users who clicks on links generated by the [mycred_link] shortcode.";s:8:"callback";a:1:{i:0;s:23:"myCRED_Hook_Click_Links";}}s:10:"video_view";a:3:{s:5:"title";s:27:"%plural% for viewing Videos";s:11:"description";s:88:"Award %_plural% to users who watches videos embedded using the [mycred_video] shortcode.";s:8:"callback";a:1:{i:0;s:23:"myCRED_Hook_Video_Views";}}s:9:"affiliate";a:3:{s:5:"title";s:22:"%plural% for referrals";s:11:"description";s:77:"Award %_plural% to users who refer either visitors and/or new member signups.";s:8:"callback";a:1:{i:0;s:21:"myCRED_Hook_Affiliate";}}s:9:"wooreview";a:3:{s:5:"title";s:27:"WooCommerce Product Reviews";s:11:"description";s:72:"Awards %_plural% for users leaving reviews on your WooCommerce products.";s:8:"callback";a:1:{i:0;s:31:"myCRED_Hook_WooCommerce_Reviews";}}}s:6:"active";a:3:{i:0;s:12:"registration";i:1;s:9:"affiliate";i:2;s:9:"wooreview";}s:10:"hook_prefs";a:8:{s:12:"registration";a:2:{s:5:"creds";s:6:"100.00";s:3:"log";s:30:"%plural% for becoming a member";}s:10:"logging_in";a:3:{s:5:"creds";s:4:"0.00";s:3:"log";s:23:"%plural% for logging in";s:5:"limit";s:5:"daily";}s:18:"publishing_content";a:3:{s:4:"post";a:2:{s:5:"creds";s:4:"0.00";s:3:"log";s:21:"%plural% for new Post";}s:4:"page";a:2:{s:5:"creds";s:4:"0.00";s:3:"log";s:21:"%plural% for new Page";}s:7:"product";a:2:{s:5:"creds";s:4:"0.00";s:3:"log";s:0:"";}}s:8:"comments";a:4:{s:8:"approved";a:3:{s:5:"creds";s:4:"1.00";s:6:"author";s:4:"0.00";s:3:"log";s:29:"%plural% for Approved Comment";}s:4:"spam";a:3:{s:5:"creds";s:4:"0.00";s:6:"author";s:4:"0.00";s:3:"log";s:45:"%plural% deduction for Comment marked as SPAM";}s:5:"trash";a:3:{s:5:"creds";s:4:"0.00";s:6:"author";s:4:"0.00";s:3:"log";s:51:"%plural% deduction for deleted / unapproved Comment";}s:6:"limits";a:3:{s:8:"per_post";i:1;s:7:"per_day";i:0;s:10:"self_reply";i:0;}}s:10:"link_click";a:3:{s:5:"creds";s:4:"1.00";s:3:"log";s:39:"%plural% for clicking on link to: %url%";s:8:"limit_by";s:4:"none";}s:10:"video_view";a:5:{s:5:"creds";s:4:"1.00";s:3:"log";s:26:"%plural% for viewing video";s:5:"logic";s:4:"play";s:8:"interval";s:0:"";s:8:"leniency";s:2:"10";}s:9:"affiliate";a:4:{s:5:"visit";a:4:{s:5:"creds";s:4:"0.00";s:3:"log";s:32:"%plural% for referring a visitor";s:5:"limit";s:1:"0";s:8:"limit_by";s:5:"total";}s:6:"signup";a:4:{s:5:"creds";s:5:"20.00";s:3:"log";s:35:"%plural% for referring a new member";s:5:"limit";s:1:"0";s:8:"limit_by";s:5:"total";}s:5:"setup";a:2:{s:5:"links";s:8:"username";s:2:"IP";s:1:"0";}s:10:"buddypress";a:4:{s:7:"profile";s:1:"1";s:5:"title";s:17:"Affiliate Program";s:4:"desc";s:0:"";s:8:"priority";s:5:"10.00";}}s:9:"wooreview";a:2:{s:5:"creds";s:5:"10.00";s:3:"log";s:27:"%plural% for product review";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (345, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (346, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (347, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (348, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (349, 'widget_mycred_widget_balance', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (350, 'widget_mycred_widget_list', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (351, 'widget_woocommerce_widget_cart', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (352, 'widget_woocommerce_products', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (353, 'widget_woocommerce_layered_nav', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (354, 'widget_woocommerce_layered_nav_filters', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (355, 'widget_woocommerce_price_filter', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (356, 'widget_woocommerce_product_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (357, 'widget_woocommerce_product_search', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (358, 'widget_woocommerce_product_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (359, 'widget_woocommerce_recent_reviews', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (360, 'widget_woocommerce_recently_viewed_products', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (361, 'widget_woocommerce_top_rated_products', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (362, 'widget_widget_twentyfourteen_ephemera', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (363, 'theme_mods_twentyfourteen', 'a:7:{s:16:"header_textcolor";s:3:"fff";s:16:"background_color";s:6:"ffffff";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:23:"featured_content_layout";s:6:"slider";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (376, 'current_theme', 'Twenty Fourteen', 'yes') ; 
INSERT INTO `wp_options` VALUES (377, 'theme_mods_html5blank-master', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1413404362;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:13:"widget-area-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"widget-area-2";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (378, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (379, 'woocommerce_admin_notices', 'a:2:{i:0;s:14:"template_files";i:1;s:13:"theme_support";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (394, 'wsi_settings', 'a:34:{s:15:"hook_buddypress";s:4:"true";s:15:"enable_facebook";s:4:"true";s:12:"facebook_key";s:0:"";s:15:"facebook_secret";s:0:"";s:14:"enable_twitter";s:4:"true";s:11:"twitter_key";s:0:"";s:14:"twitter_secret";s:0:"";s:13:"enable_google";s:4:"true";s:10:"google_key";s:0:"";s:13:"google_secret";s:0:"";s:15:"enable_linkedin";s:5:"false";s:12:"linkedin_key";s:0:"";s:15:"linkedin_secret";s:0:"";s:12:"enable_yahoo";s:4:"true";s:9:"yahoo_key";s:0:"";s:12:"yahoo_secret";s:0:"";s:17:"enable_foursquare";s:5:"false";s:14:"foursquare_key";s:0:"";s:17:"foursquare_secret";s:0:"";s:11:"enable_live";s:4:"true";s:11:"enable_mail";s:4:"true";s:7:"subject";s:32:"I invite you to join PrettyTendr";s:12:"html_message";s:96:"<h3>%%INVITERNAME%% just invited you!</h3>
%%INVITERNAME%% would like you to join %%SITENAME%%.";s:25:"html_non_editable_message";s:120:"Please accept the invitation in %%ACCEPTURL%%
Follow my twitter <a href="http://twitter.com/chifliiiii">@chifliiiii</a>";s:12:"text_subject";s:32:"I invite you to join PrettyTendr";s:7:"message";s:76:"%%INVITERNAME%% would like you to join %%SITENAME%% , click on %%ACCEPTURL%%";s:10:"fb_message";s:51:"%%INVITERNAME%% would like you to join %%SITENAME%%";s:25:"text_non_editable_message";s:45:"Please accept the invitation in %%ACCEPTURL%%";s:10:"tw_message";s:76:"%%INVITERNAME%% would like you to join %%SITENAME%% , click on %%ACCEPTURL%%";s:9:"send_with";s:3:"own";s:12:"emails_limit";s:2:"20";s:17:"emails_limit_time";s:3:"600";s:10:"custom_css";s:551:".service-filters {
}
.service-filters li {
}
.service-filters li a {
}
.service-filters li:hover, .service-filters li.selected,.service-filters li.completed {
}
.service-filters li.completed{
}
.ready-label.hidden{ display: none;}
}
.service-filters li .service-filter-name-container .service-filter-name-outer {
}
.service-filters li .service-filter-name-container .service-filter-name-outer .service-filter-name-inner {
}
.service-filters li .service-filter-name-container .service-filter-name-outer .service-filter-name-inner a {
}";s:10:"enable_dev";s:5:"false";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (395, 'wsi-version', '1.5.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (1421, 'widget_wsi_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2054, 'product_cat_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2055, 'product_shipping_class_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2148, 'slurp_page_installed', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2154, 'woocommerce_frontend_css_colors', 'a:5:{s:7:"primary";s:7:"#ad74a2";s:9:"secondary";s:7:"#f7f6f7";s:9:"highlight";s:7:"#85ad74";s:10:"content_bg";s:7:"#ffffff";s:7:"subtext";s:7:"#777777";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2208, 'woocommerce_bacs_settings', 'a:5:{s:7:"enabled";s:2:"no";s:5:"title";s:20:"Direct Bank Transfer";s:11:"description";s:173:"Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won\'t be shipped until the funds have cleared in our account.";s:12:"instructions";s:173:"Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won\'t be shipped until the funds have cleared in our account.";s:15:"account_details";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2209, 'woocommerce_bacs_accounts', 'a:1:{i:0;a:6:{s:12:"account_name";s:0:"";s:14:"account_number";s:0:"";s:9:"bank_name";s:0:"";s:9:"sort_code";s:0:"";s:4:"iban";s:0:"";s:3:"bic";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2212, 'woocommerce_cheque_settings', 'a:4:{s:7:"enabled";s:2:"no";s:5:"title";s:14:"Cheque Payment";s:11:"description";s:102:"Please send your cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.";s:12:"instructions";s:102:"Please send your cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2220, 'woocommerce_paypal_settings', 'a:16:{s:7:"enabled";s:2:"no";s:5:"title";s:6:"PayPal";s:11:"description";s:84:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account";s:5:"email";s:0:"";s:14:"receiver_email";s:0:"";s:14:"identity_token";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"paymentaction";s:4:"sale";s:22:"form_submission_method";s:2:"no";s:10:"page_style";s:0:"";s:8:"shipping";s:0:"";s:13:"send_shipping";s:2:"no";s:16:"address_override";s:2:"no";s:7:"testing";s:0:"";s:8:"testmode";s:2:"no";s:5:"debug";s:2:"no";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2228, 'mycred_types', 'a:1:{s:14:"mycred_default";s:23:"<strong>my</strong>CRED";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2229, 'mycred_pref_remote', 'a:4:{s:7:"enabled";i:0;s:3:"key";s:0:"";s:3:"uri";s:7:"api-dev";s:5:"debug";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2245, 'woocommerce_permalinks', 'a:4:{s:13:"category_base";s:0:"";s:8:"tag_base";s:0:"";s:14:"attribute_base";s:0:"";s:12:"product_base";s:8:"/product";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2264, 'mycred_pref_addons', 'a:2:{s:6:"active";a:2:{i:0;s:7:"gateway";i:1;s:13:"notifications";}s:9:"installed";a:9:{s:7:"banking";a:7:{s:4:"name";s:7:"Banking";s:11:"description";s:76:"Setup recurring payouts or offer / charge interest on user account balances.";s:9:"addon_url";s:33:"http://mycred.me/add-ons/banking/";s:7:"version";s:3:"1.0";s:6:"author";s:19:"Gabriel S Merovingi";s:10:"author_url";s:24:"http://www.merovingi.com";s:4:"path";s:91:"/Applications/MAMP/htdocs/wp-content/plugins/mycred/addons/banking/myCRED-addon-banking.php";}s:9:"buy-creds";a:7:{s:4:"name";s:7:"buyCRED";s:11:"description";s:197:"The <strong>buy</strong>CRED Add-on allows your users to buy points using PayPal, Skrill (Moneybookers) or NETbilling. <strong>buy</strong>CRED can also let your users buy points for other members.";s:9:"addon_url";s:33:"http://mycred.me/add-ons/buycred/";s:7:"version";s:3:"1.2";s:6:"author";s:19:"Gabriel S Merovingi";s:10:"author_url";s:24:"http://www.merovingi.com";s:4:"path";s:95:"/Applications/MAMP/htdocs/wp-content/plugins/mycred/addons/buy-creds/myCRED-addon-buy-creds.php";}s:7:"coupons";a:7:{s:4:"name";s:7:"Coupons";s:11:"description";s:99:"The coupons add-on allows you to create coupons that users can use to add points to their accounts.";s:9:"addon_url";s:33:"http://mycred.me/add-ons/coupons/";s:7:"version";s:3:"1.0";s:6:"author";s:19:"Gabriel S Merovingi";s:10:"author_url";s:24:"http://www.merovingi.com";s:4:"path";s:91:"/Applications/MAMP/htdocs/wp-content/plugins/mycred/addons/coupons/myCRED-addon-coupons.php";}s:13:"email-notices";a:7:{s:4:"name";s:13:"Email Notices";s:11:"description";s:53:"Create email notices for any type of myCRED instance.";s:9:"addon_url";s:39:"http://mycred.me/add-ons/email-notices/";s:7:"version";s:3:"1.2";s:6:"author";s:19:"Gabriel S Merovingi";s:10:"author_url";s:24:"http://www.merovingi.com";s:4:"path";s:103:"/Applications/MAMP/htdocs/wp-content/plugins/mycred/addons/email-notices/myCRED-addon-email-notices.php";}s:7:"gateway";a:7:{s:4:"name";s:7:"Gateway";s:11:"description";s:205:"Let your users pay using their <strong>my</strong>CRED points balance. Supported Carts: WooCommerce, MarketPress and WP E-Commerce. Supported Event Bookings: Event Espresso and Events Manager (free & pro).";s:9:"addon_url";s:33:"http://mycred.me/add-ons/gateway/";s:7:"version";s:3:"1.4";s:6:"author";s:19:"Gabriel S Merovingi";s:10:"author_url";s:24:"http://www.merovingi.com";s:4:"path";s:91:"/Applications/MAMP/htdocs/wp-content/plugins/mycred/addons/gateway/myCRED-addon-gateway.php";}s:13:"notifications";a:8:{s:4:"name";s:13:"Notifications";s:11:"description";s:64:"Create pop-up notifications for when users gain or loose points.";s:9:"addon_url";s:39:"http://mycred.me/add-ons/notifications/";s:7:"version";s:3:"1.1";s:6:"author";s:19:"Gabriel S Merovingi";s:10:"author_url";s:24:"http://www.merovingi.com";s:4:"path";s:103:"/Applications/MAMP/htdocs/wp-content/plugins/mycred/addons/notifications/myCRED-addon-notifications.php";s:7:"pro_url";s:44:"http://mycred.me/add-ons/notifications-plus/";}s:5:"ranks";a:7:{s:4:"name";s:5:"Ranks";s:11:"description";s:105:"Create ranks for users reaching a certain number of %_plural% with the option to add logos for each rank.";s:9:"addon_url";s:31:"http://mycred.me/add-ons/ranks/";s:7:"version";s:3:"1.2";s:6:"author";s:19:"Gabriel S Merovingi";s:10:"author_url";s:24:"http://www.merovingi.com";s:4:"path";s:87:"/Applications/MAMP/htdocs/wp-content/plugins/mycred/addons/ranks/myCRED-addon-ranks.php";}s:12:"sell-content";a:7:{s:4:"name";s:12:"Sell Content";s:11:"description";s:208:"This add-on allows you to sell posts, pages or any public post types on your website. You can either sell the entire content or using our shortcode, sell parts of your content allowing you to offer "teasers".";s:9:"addon_url";s:38:"http://mycred.me/add-ons/sell-content/";s:7:"version";s:5:"1.2.1";s:6:"author";s:19:"Gabriel S Merovingi";s:10:"author_url";s:24:"http://www.merovingi.com";s:4:"path";s:101:"/Applications/MAMP/htdocs/wp-content/plugins/mycred/addons/sell-content/myCRED-addon-sell-content.php";}s:8:"transfer";a:7:{s:4:"name";s:9:"Transfers";s:11:"description";s:137:"Allow your users to send or "donate" points to other members by either using the mycred_transfer shortcode or the myCRED Transfer widget.";s:9:"addon_url";s:34:"http://mycred.me/add-ons/transfer/";s:7:"version";s:3:"1.2";s:6:"author";s:19:"Gabriel S Merovingi";s:10:"author_url";s:24:"http://www.merovingi.com";s:4:"path";s:93:"/Applications/MAMP/htdocs/wp-content/plugins/mycred/addons/transfer/myCRED-addon-transfer.php";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2280, 'woocommerce_mycred_settings', 'a:10:{s:7:"enabled";s:3:"yes";s:5:"title";s:15:"Pay with myCRED";s:11:"description";s:43:"Deduct the amount from your points balance.";s:12:"log_template";s:30:"Payment for Order: #%order_id%";s:10:"point_type";s:0:"";s:13:"exchange_rate";s:4:"0.01";s:10:"show_total";s:3:"all";s:11:"total_label";s:21:"Order Total in points";s:22:"profit_sharing_percent";s:1:"0";s:18:"profit_sharing_log";s:20:"Sale of %post_title%";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2675, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2768, 'auto_core_update_notified', 'a:4:{s:4:"type";s:6:"manual";s:5:"email";s:18:"rfombrun@gmail.com";s:7:"version";s:5:"4.0.1";s:9:"timestamp";i:1416720492;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3099, '_transient_bp_active_member_count', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (3614, 'mc4wp_lite', 'a:1:{s:7:"api_key";s:36:"26041dd692ca4f28954414238121f583-us4";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3615, 'mc4wp_lite_checkbox', 'a:8:{s:5:"lists";a:1:{s:10:"9a376a20e0";s:10:"9a376a20e0";}s:12:"double_optin";s:1:"1";s:20:"show_at_comment_form";s:1:"1";s:25:"show_at_registration_form";s:1:"1";s:23:"show_at_buddypress_form";s:1:"1";s:5:"label";s:30:"Sign me up for the newsletter!";s:8:"precheck";s:1:"1";s:3:"css";s:1:"1";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3616, 'mc4wp_lite_form', 'a:11:{s:3:"css";s:7:"default";s:5:"lists";a:1:{s:10:"9a376a20e0";s:10:"9a376a20e0";}s:6:"markup";s:348:"<p>
    <label>Email Address:</label>
    <input type="email" name="EMAIL" placeholder="Your email address" required="required">
</p><p>
	<label for="mc4wp_email">Email address: </label>
	<input type="email" id="mc4wp_email" name="EMAIL" placeholder="Your email address" required />
</p>

<p>
	<input type="submit" value="Sign up" />
</p>";s:12:"double_optin";s:1:"1";s:18:"hide_after_success";s:1:"0";s:8:"redirect";s:0:"";s:12:"text_success";s:79:"Thank you, your sign-up request was successful! Please check your e-mail inbox.";s:18:"text_invalid_email";s:37:"Please provide a valid email address.";s:27:"text_required_field_missing";s:35:"Please fill in the required fields.";s:23:"text_already_subscribed";s:53:"Given email address is already subscribed, thank you!";s:10:"text_error";s:51:"Oops. Something went wrong. Please try again later.";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4378, '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (4406, '_transient_timeout_wc_rating_count_125', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4407, '_transient_wc_rating_count_125', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (4408, '_transient_timeout_wc_average_rating_125', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4409, '_transient_wc_average_rating_125', '', 'no') ; 
INSERT INTO `wp_options` VALUES (4414, '_transient_timeout_wc_rating_count_113', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4415, '_transient_wc_rating_count_113', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (4416, '_transient_timeout_wc_average_rating_113', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4417, '_transient_wc_average_rating_113', '', 'no') ; 
INSERT INTO `wp_options` VALUES (4418, '_transient_timeout_wc_rating_count_95', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4419, '_transient_wc_rating_count_95', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (4420, '_transient_timeout_wc_average_rating_95', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4421, '_transient_wc_average_rating_95', '', 'no') ; 
INSERT INTO `wp_options` VALUES (4422, '_transient_timeout_wc_rating_count_116', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4423, '_transient_wc_rating_count_116', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (4424, '_transient_timeout_wc_average_rating_116', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4425, '_transient_wc_average_rating_116', '', 'no') ; 
INSERT INTO `wp_options` VALUES (4426, '_transient_timeout_wc_rating_count_110', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4427, '_transient_wc_rating_count_110', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (4428, '_transient_timeout_wc_average_rating_110', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4429, '_transient_wc_average_rating_110', '', 'no') ; 
INSERT INTO `wp_options` VALUES (4430, '_transient_timeout_wc_rating_count_89', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4431, '_transient_wc_rating_count_89', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (4432, '_transient_timeout_wc_average_rating_89', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4433, '_transient_wc_average_rating_89', '', 'no') ; 
INSERT INTO `wp_options` VALUES (4434, '_transient_timeout_wc_rating_count_128', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4435, '_transient_wc_rating_count_128', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (4436, '_transient_timeout_wc_average_rating_128', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4437, '_transient_wc_average_rating_128', '', 'no') ; 
INSERT INTO `wp_options` VALUES (4438, '_transient_timeout_wc_rating_count_92', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4439, '_transient_wc_rating_count_92', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (4440, '_transient_timeout_wc_average_rating_92', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4441, '_transient_wc_average_rating_92', '', 'no') ; 
INSERT INTO `wp_options` VALUES (4442, '_transient_timeout_wc_rating_count_104', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4443, '_transient_wc_rating_count_104', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (4444, '_transient_timeout_wc_average_rating_104', '1442000210', 'no') ; 
INSERT INTO `wp_options` VALUES (4445, '_transient_wc_average_rating_104', '', 'no') ; 
INSERT INTO `wp_options` VALUES (4953, 'woocommerce_ship_to_destination', 'shipping', 'no') ; 
INSERT INTO `wp_options` VALUES (4983, '_transient_product_query-transient-version', '1411938954', 'yes') ; 
INSERT INTO `wp_options` VALUES (5197, '_transient_timeout_wc_rating_count_137', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5198, '_transient_wc_rating_count_137', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5199, '_transient_timeout_wc_average_rating_137', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5200, '_transient_wc_average_rating_137', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5201, '_transient_timeout_wc_rating_count_140', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5202, '_transient_wc_rating_count_140', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5203, '_transient_timeout_wc_average_rating_140', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5204, '_transient_wc_average_rating_140', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5205, '_transient_timeout_wc_rating_count_143', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5206, '_transient_wc_rating_count_143', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5207, '_transient_timeout_wc_average_rating_143', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5208, '_transient_wc_average_rating_143', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5209, '_transient_timeout_wc_rating_count_149', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5210, '_transient_wc_rating_count_149', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5211, '_transient_timeout_wc_average_rating_149', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5212, '_transient_wc_average_rating_149', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5213, '_transient_timeout_wc_rating_count_86', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5214, '_transient_wc_rating_count_86', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5215, '_transient_timeout_wc_average_rating_86', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5216, '_transient_wc_average_rating_86', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5217, '_transient_timeout_wc_rating_count_119', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5218, '_transient_wc_rating_count_119', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5219, '_transient_timeout_wc_average_rating_119', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5220, '_transient_wc_average_rating_119', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5221, '_transient_timeout_wc_rating_count_134', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5222, '_transient_wc_rating_count_134', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5223, '_transient_timeout_wc_average_rating_134', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5224, '_transient_wc_average_rating_134', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5225, '_transient_timeout_wc_rating_count_98', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5226, '_transient_wc_rating_count_98', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5227, '_transient_timeout_wc_average_rating_98', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5228, '_transient_wc_average_rating_98', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5229, '_transient_timeout_wc_rating_count_107', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5230, '_transient_wc_rating_count_107', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5231, '_transient_timeout_wc_average_rating_107', '1442085309', 'no') ; 
INSERT INTO `wp_options` VALUES (5232, '_transient_wc_average_rating_107', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5261, '_transient_woocommerce_cache_excluded_uris', 'a:6:{i:0;s:3:"p=7";i:1;s:3:"p=8";i:2;s:3:"p=9";i:3;s:5:"/cart";i:4;s:9:"/checkout";i:5;s:11:"/my-account";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (5432, 'mycred_version', '1.4.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (5433, 'mycred_key', 'A}&gN#w2CYc;', 'yes') ; 
INSERT INTO `wp_options` VALUES (5440, '_transient_timeout_wc_rating_count_146', '1442093270', 'no') ; 
INSERT INTO `wp_options` VALUES (5441, '_transient_wc_rating_count_146', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (5442, '_transient_timeout_wc_average_rating_146', '1442093270', 'no') ; 
INSERT INTO `wp_options` VALUES (5443, '_transient_wc_average_rating_146', '', 'no') ; 
INSERT INTO `wp_options` VALUES (5702, '_transient_timeout_wc_uf_pid_831592cd060013cc11959e68c98294e9', '1443482517', 'no') ; 
INSERT INTO `wp_options` VALUES (5703, '_transient_wc_uf_pid_831592cd060013cc11959e68c98294e9', 'a:23:{i:0;i:152;i:1;i:146;i:2;i:149;i:3;i:86;i:4;i:119;i:5;i:89;i:6;i:122;i:7;i:92;i:8;i:125;i:9;i:95;i:10;i:128;i:11;i:98;i:12;i:131;i:13;i:101;i:14;i:134;i:15;i:104;i:16;i:137;i:17;i:107;i:18;i:140;i:19;i:110;i:20;i:143;i:21;i:113;i:22;i:116;}', 'no') ; 
INSERT INTO `wp_options` VALUES (5707, '_transient_timeout_wc_rating_count_101', '1443488454', 'no') ; 
INSERT INTO `wp_options` VALUES (5708, '_transient_wc_rating_count_101', '1', 'no') ; 
INSERT INTO `wp_options` VALUES (5709, '_transient_timeout_wc_average_rating_101', '1443488454', 'no') ; 
INSERT INTO `wp_options` VALUES (5710, '_transient_wc_average_rating_101', '3.00', 'no') ; 
INSERT INTO `wp_options` VALUES (5740, '_transient_timeout_wc_rating_count_152', '1443488669', 'no') ; 
INSERT INTO `wp_options` VALUES (5741, '_transient_wc_rating_count_152', '2', 'no') ; 
INSERT INTO `wp_options` VALUES (5742, '_transient_timeout_wc_average_rating_152', '1443488669', 'no') ; 
INSERT INTO `wp_options` VALUES (5743, '_transient_wc_average_rating_152', '1.50', 'no') ; 
INSERT INTO `wp_options` VALUES (5883, '_transient_timeout_wc_rating_count_122', '1444183327', 'no') ; 
INSERT INTO `wp_options` VALUES (5884, '_transient_wc_rating_count_122', '1', 'no') ; 
INSERT INTO `wp_options` VALUES (5885, '_transient_timeout_wc_average_rating_122', '1444183327', 'no') ; 
INSERT INTO `wp_options` VALUES (5886, '_transient_wc_average_rating_122', '3.00', 'no') ; 
INSERT INTO `wp_options` VALUES (5964, 'theme_mods_twentyfourteen-child', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1417754794;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-1";a:0:{}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6074, 'theme_mods_foundation', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:10:"off-canvas";i:21;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1413425560;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6084, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6100, 'theme_mods_cwhite-pt', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:16:"desktop_head_nav";i:21;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1418702977;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6172, 'hmbkp_default_path', '/Applications/MAMP/htdocs/prettytendr/htdocs/wp-content/backupwordpress-581612334d-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (6173, 'hmbkp_path', '/Applications/MAMP/htdocs/prettytendr/htdocs/wp-content/backupwordpress-581612334d-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (6174, 'hmbkp_schedule_default-1', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1414018800;s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6175, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1414292400;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6176, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (6179, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2828097608', 'no') ; 
INSERT INTO `wp_options` VALUES (6180, '_transient_hmbkp_schedule_default-1_database_filesize', '3562941', 'no') ; 
INSERT INTO `wp_options` VALUES (6618, 'theme_mods_minimum 2', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1418144243;s:4:"data";a:8:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:12:"sidebar_page";N;s:19:"woocommerce_sidebar";N;s:13:"footer_slider";N;s:11:"footer_left";N;s:12:"footer_right";N;s:12:"header_right";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6620, 'qode_options', 'a:223:{s:17:"reset_to_defaults";s:0:"";s:15:"number_of_chars";s:2:"45";s:11:"first_color";s:0:"";s:12:"second_color";s:0:"";s:11:"third_color";s:0:"";s:16:"background_color";s:0:"";s:15:"highlight_color";s:0:"";s:15:"selection_color";s:0:"";s:13:"favicon_image";s:67:"http://localhost:8888/wp-content/themes/minimum%202/img/favicon.ico";s:23:"patern_background_image";s:0:"";s:28:"backstreach_background_image";s:0:"";s:12:"google_fonts";s:2:"-1";s:16:"page_transitions";s:1:"3";s:14:"responsiveness";s:3:"yes";s:14:"parallax_speed";s:1:"1";s:18:"parallax_minheight";s:3:"300";s:22:"internal_no_ajax_links";s:0:"";s:10:"custom_css";s:0:"";s:9:"custom_js";s:0:"";s:13:"meta_keywords";s:0:"";s:16:"meta_description";s:0:"";s:16:"disable_qode_seo";s:2:"no";s:12:"show_toolbar";s:2:"no";s:8:"h1_color";s:0:"";s:15:"h1_google_fonts";s:2:"-1";s:11:"h1_fontsize";s:0:"";s:13:"h1_lineheight";s:0:"";s:12:"h1_fontstyle";s:0:"";s:13:"h1_fontweight";s:0:"";s:8:"h2_color";s:0:"";s:15:"h2_google_fonts";s:2:"-1";s:11:"h2_fontsize";s:0:"";s:13:"h2_lineheight";s:0:"";s:12:"h2_fontstyle";s:0:"";s:13:"h2_fontweight";s:0:"";s:8:"h3_color";s:0:"";s:15:"h3_google_fonts";s:2:"-1";s:11:"h3_fontsize";s:0:"";s:13:"h3_lineheight";s:0:"";s:12:"h3_fontstyle";s:0:"";s:13:"h3_fontweight";s:0:"";s:8:"h4_color";s:0:"";s:15:"h4_google_fonts";s:2:"-1";s:11:"h4_fontsize";s:0:"";s:13:"h4_lineheight";s:0:"";s:12:"h4_fontstyle";s:0:"";s:13:"h4_fontweight";s:0:"";s:8:"h5_color";s:0:"";s:15:"h5_google_fonts";s:2:"-1";s:11:"h5_fontsize";s:0:"";s:13:"h5_lineheight";s:0:"";s:12:"h5_fontstyle";s:0:"";s:13:"h5_fontweight";s:0:"";s:8:"h6_color";s:0:"";s:15:"h6_google_fonts";s:2:"-1";s:11:"h6_fontsize";s:0:"";s:13:"h6_lineheight";s:0:"";s:12:"h6_fontstyle";s:0:"";s:13:"h6_fontweight";s:0:"";s:10:"text_color";s:0:"";s:17:"text_google_fonts";s:2:"-1";s:13:"text_fontsize";s:0:"";s:15:"text_lineheight";s:0:"";s:14:"text_fontstyle";s:0:"";s:15:"text_fontweight";s:0:"";s:11:"text_margin";s:0:"";s:10:"link_color";s:0:"";s:15:"link_hovercolor";s:0:"";s:14:"link_fontstyle";s:0:"";s:15:"link_fontweight";s:0:"";s:19:"link_fontdecoration";s:0:"";s:19:"page_title_position";s:0:"";s:16:"page_title_color";s:0:"";s:23:"page_title_google_fonts";s:2:"-1";s:19:"page_title_fontsize";s:0:"";s:21:"page_title_lineheight";s:0:"";s:20:"page_title_fontstyle";s:0:"";s:21:"page_title_fontweight";s:0:"";s:18:"main_menu_position";s:0:"";s:18:"magic_panes_height";s:0:"";s:22:"magic_pane_hover_color";s:0:"";s:23:"magic_pane_active_color";s:0:"";s:10:"menu_color";s:0:"";s:15:"menu_hovercolor";s:0:"";s:17:"menu_google_fonts";s:2:"-1";s:13:"menu_fontsize";s:0:"";s:15:"menu_lineheight";s:0:"";s:14:"menu_fontstyle";s:0:"";s:15:"menu_fontweight";s:0:"";s:10:"logo_image";s:72:"http://localhost:8888/wp-content/themes/minimum%202/img/minimum-logo.png";s:17:"center_logo_image";s:2:"no";s:8:"logo_top";s:0:"";s:9:"logo_left";s:0:"";s:13:"header_height";s:0:"";s:8:"top_menu";s:9:"drop_down";s:14:"dropdown_color";s:0:"";s:19:"dropdown_hovercolor";s:0:"";s:21:"dropdown_google_fonts";s:2:"-1";s:17:"dropdown_fontsize";s:0:"";s:19:"dropdown_lineheight";s:0:"";s:18:"dropdown_fontstyle";s:0:"";s:19:"dropdown_fontweight";s:0:"";s:23:"dropdown_color_thirdlvl";s:0:"";s:28:"dropdown_hovercolor_thirdlvl";s:0:"";s:30:"dropdown_google_fonts_thirdlvl";s:2:"-1";s:26:"dropdown_fontsize_thirdlvl";s:0:"";s:28:"dropdown_lineheight_thirdlvl";s:0:"";s:27:"dropdown_fontstyle_thirdlvl";s:0:"";s:28:"dropdown_fontweight_thirdlvl";s:0:"";s:17:"separation_number";s:0:"";s:26:"header_separator_thickness";s:0:"";s:26:"footer_separator_thickness";s:0:"";s:17:"footer_logo_image";s:72:"http://localhost:8888/wp-content/themes/minimum%202/img/minimum-logo.png";s:24:"center_footer_logo_image";s:2:"no";s:22:"hide_footer_logo_image";s:2:"no";s:18:"footer_widget_area";s:2:"no";s:22:"slider_transition_auto";s:0:"";s:24:"slider_transition_effect";s:0:"";s:23:"slider_transition_speed";s:0:"";s:25:"slider_transition_timeout";s:0:"";s:18:"slider_title_color";s:0:"";s:25:"slider_title_google_fonts";s:2:"-1";s:21:"slider_title_fontsize";s:0:"";s:23:"slider_title_lineheight";s:0:"";s:22:"slider_title_fontstyle";s:0:"";s:23:"slider_title_fontweight";s:0:"";s:17:"slider_text_color";s:0:"";s:24:"slider_text_google_fonts";s:2:"-1";s:20:"slider_text_fontsize";s:0:"";s:22:"slider_text_lineheight";s:0:"";s:21:"slider_text_fontstyle";s:0:"";s:22:"slider_text_fontweight";s:0:"";s:24:"slider_title_color_type2";s:0:"";s:31:"slider_title_google_fonts_type2";s:0:"";s:27:"slider_title_fontsize_type2";s:0:"";s:29:"slider_title_lineheight_type2";s:0:"";s:28:"slider_title_fontstyle_type2";s:0:"";s:29:"slider_title_fontweight_type2";s:0:"";s:23:"smallslider_move_slides";s:0:"";s:28:"smallslider_transition_speed";s:0:"";s:23:"smallslider_title_color";s:0:"";s:30:"smallslider_title_google_fonts";s:2:"-1";s:26:"smallslider_title_fontsize";s:0:"";s:28:"smallslider_title_lineheight";s:0:"";s:27:"smallslider_title_fontstyle";s:0:"";s:28:"smallslider_title_fontweight";s:0:"";s:22:"smallslider_text_color";s:0:"";s:29:"smallslider_text_google_fonts";s:2:"-1";s:25:"smallslider_text_fontsize";s:0:"";s:27:"smallslider_text_lineheight";s:0:"";s:26:"smallslider_text_fontstyle";s:0:"";s:27:"smallslider_text_fontweight";s:0:"";s:29:"smallslider_move_slides_type2";s:0:"";s:34:"smallslider_transition_speed_type2";s:0:"";s:29:"smallslider_title_color_type2";s:0:"";s:36:"smallslider_title_google_fonts_type2";s:0:"";s:32:"smallslider_title_fontsize_type2";s:0:"";s:34:"smallslider_title_lineheight_type2";s:0:"";s:33:"smallslider_title_fontstyle_type2";s:0:"";s:34:"smallslider_title_fontweight_type2";s:0:"";s:28:"smallslider_text_color_type2";s:0:"";s:35:"smallslider_text_google_fonts_type2";s:0:"";s:31:"smallslider_text_fontsize_type2";s:0:"";s:33:"smallslider_text_lineheight_type2";s:0:"";s:32:"smallslider_text_fontstyle_type2";s:0:"";s:33:"smallslider_text_fontweight_type2";s:0:"";s:19:"separator_thickness";s:0:"";s:19:"separator_topmargin";s:0:"";s:22:"separator_bottommargin";s:0:"";s:25:"separator_small_thickness";s:0:"";s:25:"separator_small_topmargin";s:0:"";s:28:"separator_small_bottommargin";s:0:"";s:18:"button_title_color";s:0:"";s:23:"button_title_hovercolor";s:0:"";s:25:"button_title_google_fonts";s:2:"-1";s:21:"button_title_fontsize";s:0:"";s:23:"button_title_lineheight";s:0:"";s:22:"button_title_fontstyle";s:0:"";s:23:"button_title_fontweight";s:0:"";s:11:"button_size";s:0:"";s:22:"button_backgroundcolor";s:0:"";s:27:"button_backgroundhovercolor";s:0:"";s:19:"message_title_color";s:0:"";s:26:"message_title_google_fonts";s:2:"-1";s:22:"message_title_fontsize";s:0:"";s:24:"message_title_lineheight";s:0:"";s:23:"message_title_fontstyle";s:0:"";s:24:"message_title_fontweight";s:0:"";s:14:"message_border";s:0:"";s:12:"message_size";s:0:"";s:23:"message_backgroundcolor";s:0:"";s:15:"portfolio_style";s:1:"1";s:26:"portfolio_list_title_color";s:0:"";s:33:"portfolio_list_title_google_fonts";s:2:"-1";s:29:"portfolio_list_title_fontsize";s:0:"";s:31:"portfolio_list_title_lineheight";s:0:"";s:30:"portfolio_list_title_fontstyle";s:0:"";s:31:"portfolio_list_title_fontweight";s:0:"";s:25:"portfolio_list_text_color";s:0:"";s:32:"portfolio_list_text_google_fonts";s:2:"-1";s:28:"portfolio_list_text_fontsize";s:0:"";s:30:"portfolio_list_text_lineheight";s:0:"";s:29:"portfolio_list_text_fontstyle";s:0:"";s:30:"portfolio_list_text_fontweight";s:0:"";s:10:"pagination";s:1:"2";s:10:"blog_style";s:1:"1";s:21:"category_blog_sidebar";s:7:"default";s:18:"blog_hide_comments";s:2:"no";s:12:"receive_mail";s:0:"";s:19:"enable_contact_form";s:2:"no";s:25:"hide_contact_form_website";s:2:"no";s:10:"email_from";s:0:"";s:13:"email_subject";s:0:"";s:13:"use_recaptcha";s:2:"no";s:20:"recaptcha_public_key";s:0:"";s:21:"recaptcha_private_key";s:0:"";s:21:"contact_heading_above";s:0:"";s:17:"enable_google_map";s:2:"no";s:18:"google_maps_iframe";s:0:"";s:9:"404_title";s:0:"";s:12:"404_subtitle";s:0:"";s:8:"404_text";s:0:"";s:13:"404_backlabel";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6706, '_site_transient_timeout_browser_e1b21c5d9d77c08a69d029a32a4f603a', '1419225423', 'yes') ; 
INSERT INTO `wp_options` VALUES (6707, '_site_transient_browser_e1b21c5d9d77c08a69d029a32a4f603a', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"39.0.2171.71";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6710, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (6746, '_site_transient_timeout_browser_21238ec846353e9f17708bd19fd640c9', '1419307505', 'yes') ; 
INSERT INTO `wp_options` VALUES (6747, '_site_transient_browser_21238ec846353e9f17708bd19fd640c9', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"39.0.2171.95";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6774, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1419146834;s:7:"checked";a:3:{s:13:"twentyfifteen";s:3:"1.0";s:14:"twentyfourteen";s:3:"1.3";s:14:"twentythirteen";s:3:"1.4";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6776, '_transient_doing_cron', '1419146829.7286291122436523437500', 'yes') ; 
INSERT INTO `wp_options` VALUES (6777, '_transient_featured_content_ids', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6778, 'WPLANG', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (6779, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (6780, 'rewrite_rules', 'a:69:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=10&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6782, '_site_transient_timeout_theme_roots', '1419148631', 'yes') ; 
INSERT INTO `wp_options` VALUES (6783, '_site_transient_theme_roots', 'a:3:{s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6784, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:57:"https://downloads.wordpress.org/release/wordpress-4.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:57:"https://downloads.wordpress.org/release/wordpress-4.1.zip";s:10:"no_content";s:68:"https://downloads.wordpress.org/release/wordpress-4.1-no-content.zip";s:11:"new_bundled";s:69:"https://downloads.wordpress.org/release/wordpress-4.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.1";s:7:"version";s:3:"4.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1419146832;s:15:"version_checked";s:3:"4.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (6785, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1419146833;s:8:"response";a:9:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.0.4";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.0.4.zip";}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":7:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"3.0.4";s:14:"upgrade_notice";s:56:"Fixes a few minor bugs. Immediate update is recommended.";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.3.0.4.zip";}s:24:"buddypress/bp-loader.php";O:8:"stdClass":7:{s:2:"id";s:4:"7756";s:4:"slug";s:10:"buddypress";s:6:"plugin";s:24:"buddypress/bp-loader.php";s:11:"new_version";s:5:"2.1.1";s:14:"upgrade_notice";s:56:"See: http://codex.buddypress.org/releases/version-2-1-1/";s:3:"url";s:41:"https://wordpress.org/plugins/buddypress/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/buddypress.2.1.1.zip";}s:37:"mailchimp-for-wp/mailchimp-for-wp.php";O:8:"stdClass":7:{s:2:"id";s:5:"41550";s:4:"slug";s:16:"mailchimp-for-wp";s:6:"plugin";s:37:"mailchimp-for-wp/mailchimp-for-wp.php";s:11:"new_version";s:3:"2.2";s:14:"upgrade_notice";s:115:"Contains many code improvements, updated translations and checkbox integration with WooCommerce &amp; EDD checkout.";s:3:"url";s:47:"https://wordpress.org/plugins/mailchimp-for-wp/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/mailchimp-for-wp.2.2.zip";}s:17:"mycred/mycred.php";O:8:"stdClass":7:{s:2:"id";s:5:"40289";s:4:"slug";s:6:"mycred";s:6:"plugin";s:17:"mycred/mycred.php";s:11:"new_version";s:5:"1.5.4";s:14:"upgrade_notice";s:85:"WooCommerce 2.2 support, BuddyPress 2.1 support, Balance widget update and bug fixes.";s:3:"url";s:37:"https://wordpress.org/plugins/mycred/";s:7:"package";s:55:"https://downloads.wordpress.org/plugin/mycred.1.5.4.zip";}s:27:"woocommerce/woocommerce.php";O:8:"stdClass":6:{s:2:"id";s:5:"25331";s:4:"slug";s:11:"woocommerce";s:6:"plugin";s:27:"woocommerce/woocommerce.php";s:11:"new_version";s:6:"2.2.10";s:3:"url";s:42:"https://wordpress.org/plugins/woocommerce/";s:7:"package";s:61:"https://downloads.wordpress.org/plugin/woocommerce.2.2.10.zip";}s:24:"wp-all-import/plugin.php";O:8:"stdClass":6:{s:2:"id";s:5:"33207";s:4:"slug";s:13:"wp-all-import";s:6:"plugin";s:24:"wp-all-import/plugin.php";s:11:"new_version";s:5:"3.2.3";s:3:"url";s:44:"https://wordpress.org/plugins/wp-all-import/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/wp-all-import.3.2.3.zip";}s:45:"woocommerce-xml-csv-product-import/plugin.php";O:8:"stdClass":6:{s:2:"id";s:5:"41821";s:4:"slug";s:34:"woocommerce-xml-csv-product-import";s:6:"plugin";s:45:"woocommerce-xml-csv-product-import/plugin.php";s:11:"new_version";s:5:"1.2.0";s:3:"url";s:65:"https://wordpress.org/plugins/woocommerce-xml-csv-product-import/";s:7:"package";s:83:"https://downloads.wordpress.org/plugin/woocommerce-xml-csv-product-import.1.2.0.zip";}s:47:"wp-social-invitations/wp-social-invitations.php";O:8:"stdClass":6:{s:2:"id";s:5:"42126";s:4:"slug";s:21:"wp-social-invitations";s:6:"plugin";s:47:"wp-social-invitations/wp-social-invitations.php";s:11:"new_version";s:5:"1.6.1";s:3:"url";s:52:"https://wordpress.org/plugins/wp-social-invitations/";s:7:"package";s:70:"https://downloads.wordpress.org/plugin/wp-social-invitations.1.6.1.zip";}}s:12:"translations";a:0:{}s:9:"no_update";a:4:{s:31:"buddypress-followers/loader.php";O:8:"stdClass":6:{s:2:"id";s:5:"15091";s:4:"slug";s:20:"buddypress-followers";s:6:"plugin";s:31:"buddypress-followers/loader.php";s:11:"new_version";s:5:"1.2.1";s:3:"url";s:51:"https://wordpress.org/plugins/buddypress-followers/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/buddypress-followers.1.2.1.zip";}s:23:"debug-bar/debug-bar.php";O:8:"stdClass":7:{s:2:"id";s:5:"18561";s:4:"slug";s:9:"debug-bar";s:6:"plugin";s:23:"debug-bar/debug-bar.php";s:11:"new_version";s:5:"0.8.2";s:14:"upgrade_notice";s:60:"Updated to handle a new deprecated message in WordPress 4.0.";s:3:"url";s:40:"https://wordpress.org/plugins/debug-bar/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/debug-bar.0.8.2.zip";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}s:41:"wordpress-importer/wordpress-importer.php";O:8:"stdClass":6:{s:2:"id";s:5:"14975";s:4:"slug";s:18:"wordpress-importer";s:6:"plugin";s:41:"wordpress-importer/wordpress-importer.php";s:11:"new_version";s:5:"0.6.1";s:3:"url";s:49:"https://wordpress.org/plugins/wordpress-importer/";s:7:"package";s:67:"https://downloads.wordpress.org/plugin/wordpress-importer.0.6.1.zip";}}}', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------


#
# Delete any existing table `wp_pmxi_files`
#

DROP TABLE IF EXISTS `wp_pmxi_files`;


#
# Table structure of table `wp_pmxi_files`
#

CREATE TABLE `wp_pmxi_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `import_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `path` text,
  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_pmxi_files (1 records)
#
 
INSERT INTO `wp_pmxi_files` VALUES (7, 6, 'dummy_products_imageFix.csv', '/Applications/MAMP/htdocs/wp-content/uploads/2014/07/dummy_products_imageFix.xml', '2014-07-21 21:03:41') ;
#
# End of data contents of table wp_pmxi_files
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------


#
# Delete any existing table `wp_pmxi_imports`
#

DROP TABLE IF EXISTS `wp_pmxi_imports`;


#
# Table structure of table `wp_pmxi_imports`
#

CREATE TABLE `wp_pmxi_imports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_import_id` bigint(20) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `friendly_name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(32) NOT NULL DEFAULT '',
  `feed_type` enum('xml','csv','zip','gz','') NOT NULL DEFAULT '',
  `path` text,
  `xpath` text,
  `template` longtext,
  `options` text,
  `scheduled` varchar(64) NOT NULL DEFAULT '',
  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `large_import` enum('Yes','No') NOT NULL DEFAULT 'No',
  `root_element` varchar(255) DEFAULT '',
  `processing` tinyint(1) NOT NULL DEFAULT '0',
  `triggered` tinyint(1) NOT NULL DEFAULT '0',
  `queue_chunk_number` bigint(20) NOT NULL DEFAULT '0',
  `first_import` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `count` bigint(20) NOT NULL DEFAULT '0',
  `imported` bigint(20) NOT NULL DEFAULT '0',
  `created` bigint(20) NOT NULL DEFAULT '0',
  `updated` bigint(20) NOT NULL DEFAULT '0',
  `skipped` bigint(20) NOT NULL DEFAULT '0',
  `iteration` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_pmxi_imports (1 records)
#
 
INSERT INTO `wp_pmxi_imports` VALUES (6, 0, 'dummy_products_imageFix.csv', '', 'upload', '', '/Applications/MAMP/htdocs/wp-content/uploads/2014/07/dummy_products_imageFix.csv', '/node', 'a:6:{s:5:"title";s:15:"{post_title[1]}";s:7:"content";s:17:"{post_content[1]}";s:4:"name";s:0:"";s:18:"is_keep_linebreaks";s:1:"0";s:13:"is_leave_html";s:1:"0";s:14:"fix_characters";i:0;}', 'a:247:{s:4:"type";s:4:"post";s:11:"custom_type";s:7:"product";s:10:"categories";s:0:"";s:4:"tags";s:0:"";s:10:"tags_delim";s:1:",";s:16:"categories_delim";s:1:",";s:22:"categories_auto_nested";i:0;s:14:"featured_delim";s:0:"";s:10:"atch_delim";s:1:",";s:15:"post_taxonomies";a:3:{s:11:"product_cat";s:126:"[{"item_id":"1","parent_id":null,"delim":",","left":2,"right":3,"xpath":"","assign":true,"auto_nested":false,"mapping":false}]";s:11:"product_tag";s:126:"[{"item_id":"1","parent_id":null,"delim":",","left":2,"right":3,"xpath":"","assign":true,"auto_nested":false,"mapping":false}]";s:22:"product_shipping_class";s:126:"[{"item_id":"1","parent_id":null,"delim":",","left":2,"right":3,"xpath":"","assign":true,"auto_nested":false,"mapping":false}]";}s:6:"parent";s:0:"";s:5:"order";s:1:"0";s:6:"status";s:7:"publish";s:13:"page_template";s:7:"default";s:15:"page_taxonomies";a:0:{}s:9:"date_type";s:8:"specific";s:4:"date";s:3:"now";s:10:"date_start";s:3:"now";s:8:"date_end";s:3:"now";s:11:"custom_name";a:0:{}s:12:"custom_value";a:0:{}s:13:"custom_format";a:1:{i:0;s:1:"0";}s:17:"serialized_values";a:2:{i:0;s:0:"";i:1;s:0:"";}s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:12:"create_draft";s:2:"no";s:6:"author";s:0:"";s:12:"post_excerpt";s:0:"";s:9:"post_slug";s:0:"";s:14:"featured_image";s:35:"{images_front[1]}
{images_back[1]}";s:11:"attachments";s:0:"";s:19:"is_import_specified";s:1:"0";s:16:"import_specified";s:0:"";s:16:"is_delete_source";i:0;s:8:"is_cloak";i:0;s:10:"unique_key";s:36:"{post_title[1]} - {id[1]} - {sku[1]}";s:9:"feed_type";s:4:"auto";s:18:"create_new_records";s:1:"1";s:17:"is_delete_missing";s:1:"0";s:20:"set_missing_to_draft";s:1:"0";s:20:"is_update_missing_cf";s:1:"0";s:22:"update_missing_cf_name";s:0:"";s:23:"update_missing_cf_value";s:0:"";s:20:"is_keep_former_posts";s:2:"no";s:16:"is_update_status";s:1:"1";s:17:"is_update_content";s:1:"1";s:15:"is_update_title";s:1:"1";s:14:"is_update_slug";s:1:"1";s:17:"is_update_excerpt";s:1:"1";s:20:"is_update_categories";s:1:"1";s:23:"update_categories_logic";s:11:"full_update";s:15:"taxonomies_list";s:1:"0";s:20:"taxonomies_only_list";s:0:"";s:22:"taxonomies_except_list";s:0:"";s:21:"is_update_attachments";s:1:"1";s:16:"is_update_images";s:1:"1";s:19:"update_images_logic";s:11:"full_update";s:15:"is_update_dates";s:1:"1";s:20:"is_update_menu_order";s:1:"1";s:16:"is_update_parent";s:1:"1";s:19:"is_keep_attachments";s:1:"0";s:12:"is_keep_imgs";s:1:"0";s:23:"is_update_custom_fields";s:1:"1";s:26:"update_custom_fields_logic";s:11:"full_update";s:18:"custom_fields_list";s:1:"0";s:23:"custom_fields_only_list";s:0:"";s:25:"custom_fields_except_list";s:0:"";s:18:"duplicate_matching";s:4:"auto";s:19:"duplicate_indicator";s:5:"title";s:21:"custom_duplicate_name";s:0:"";s:22:"custom_duplicate_value";s:0:"";s:18:"is_update_previous";i:0;s:12:"is_scheduled";s:0:"";s:16:"scheduled_period";s:0:"";s:13:"friendly_name";s:0:"";s:19:"records_per_request";s:2:"20";s:18:"auto_rename_images";s:1:"0";s:25:"auto_rename_images_suffix";s:0:"";s:11:"images_name";s:8:"filename";s:11:"post_format";s:8:"standard";s:8:"encoding";s:5:"UTF-8";s:9:"delimiter";s:1:",";s:19:"set_image_meta_data";s:1:"0";s:16:"image_meta_title";s:0:"";s:22:"image_meta_title_delim";s:0:"";s:18:"image_meta_caption";s:0:"";s:24:"image_meta_caption_delim";s:0:"";s:14:"image_meta_alt";s:0:"";s:20:"image_meta_alt_delim";s:0:"";s:22:"image_meta_description";s:0:"";s:28:"image_meta_description_delim";s:0:"";s:12:"status_xpath";s:0:"";s:15:"download_images";s:1:"0";s:17:"converted_options";s:1:"1";s:15:"update_all_data";s:3:"yes";s:12:"is_fast_mode";s:1:"0";s:9:"chuncking";s:1:"1";s:17:"import_processing";s:4:"ajax";s:24:"is_multiple_product_type";s:3:"yes";s:21:"multiple_product_type";s:6:"simple";s:19:"single_product_type";s:0:"";s:18:"is_product_virtual";s:2:"no";s:22:"single_product_virtual";s:0:"";s:23:"is_product_downloadable";s:2:"no";s:27:"single_product_downloadable";s:0:"";s:18:"is_product_enabled";s:3:"yes";s:22:"single_product_enabled";s:0:"";s:19:"is_product_featured";s:2:"no";s:23:"single_product_featured";s:0:"";s:21:"is_product_visibility";s:7:"visible";s:25:"single_product_visibility";s:0:"";s:18:"single_product_sku";s:8:"{sku[1]}";s:18:"single_product_url";s:0:"";s:26:"single_product_button_text";s:0:"";s:28:"single_product_regular_price";s:18:"{regular_price[1]}";s:25:"single_product_sale_price";s:15:"{sale_price[1]}";s:20:"single_product_files";s:0:"";s:26:"single_product_files_names";s:0:"";s:29:"single_product_download_limit";s:0:"";s:30:"single_product_download_expiry";s:0:"";s:28:"single_product_download_type";s:0:"";s:30:"is_multiple_product_tax_status";s:3:"yes";s:27:"multiple_product_tax_status";s:4:"none";s:25:"single_product_tax_status";s:0:"";s:29:"is_multiple_product_tax_class";s:3:"yes";s:26:"multiple_product_tax_class";s:0:"";s:24:"single_product_tax_class";s:0:"";s:23:"is_product_manage_stock";s:2:"no";s:27:"single_product_manage_stock";s:0:"";s:24:"single_product_stock_qty";s:10:"{stock[1]}";s:20:"product_stock_status";s:7:"instock";s:27:"single_product_stock_status";s:0:"";s:24:"product_allow_backorders";s:2:"no";s:31:"single_product_allow_backorders";s:0:"";s:25:"product_sold_individually";s:2:"no";s:32:"single_product_sold_individually";s:0:"";s:21:"single_product_weight";s:11:"{weight[1]}";s:21:"single_product_length";s:11:"{length[1]}";s:20:"single_product_width";s:10:"{width[1]}";s:21:"single_product_height";s:11:"{height[1]}";s:34:"is_multiple_product_shipping_class";s:3:"yes";s:31:"multiple_product_shipping_class";s:2:"-1";s:29:"single_product_shipping_class";s:0:"";s:28:"is_multiple_grouping_product";s:3:"yes";s:25:"multiple_grouping_product";s:0:"";s:23:"single_grouping_product";s:0:"";s:23:"single_product_up_sells";s:15:"{upsell_ids[1]}";s:26:"single_product_cross_sells";s:18:"{crosssell_ids[1]}";s:14:"attribute_name";a:0:{}s:15:"attribute_value";a:0:{}s:13:"in_variations";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:10:"is_visible";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:11:"is_taxonomy";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:29:"create_taxonomy_in_not_exists";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:28:"single_product_purchase_note";s:0:"";s:25:"single_product_menu_order";s:1:"0";s:25:"is_product_enable_reviews";s:2:"no";s:29:"single_product_enable_reviews";s:0:"";s:17:"single_product_id";s:0:"";s:24:"single_product_parent_id";s:0:"";s:36:"single_product_id_first_is_parent_id";s:0:"";s:39:"single_product_id_first_is_parent_title";s:15:"{post_title[1]}";s:36:"single_product_id_first_is_variation";s:15:"{post_title[1]}";s:8:"_virtual";s:1:"0";s:13:"_downloadable";s:1:"0";s:24:"is_regular_price_shedule";s:1:"0";s:28:"single_sale_price_dates_from";s:3:"now";s:26:"single_sale_price_dates_to";s:3:"now";s:19:"product_files_delim";s:1:",";s:25:"product_files_names_delim";s:1:",";s:15:"matching_parent";s:4:"auto";s:16:"parent_indicator";s:12:"custom field";s:28:"custom_parent_indicator_name";s:0:"";s:29:"custom_parent_indicator_value";s:0:"";s:28:"missing_records_stock_status";s:1:"0";s:16:"variations_xpath";s:0:"";s:17:"_variable_virtual";s:0:"";s:22:"_variable_downloadable";s:0:"";s:14:"variable_stock";s:0:"";s:22:"variable_regular_price";s:0:"";s:19:"variable_sale_price";s:0:"";s:30:"is_variable_sale_price_shedule";s:1:"0";s:30:"variable_sale_price_dates_from";s:0:"";s:28:"variable_sale_price_dates_to";s:0:"";s:15:"variable_weight";s:0:"";s:15:"variable_length";s:0:"";s:14:"variable_width";s:0:"";s:15:"variable_height";s:0:"";s:23:"variable_shipping_class";s:0:"";s:18:"variable_tax_class";s:0:"";s:19:"variable_file_paths";s:0:"";s:19:"variable_file_names";s:0:"";s:23:"variable_download_limit";s:0:"";s:24:"variable_download_expiry";s:0:"";s:27:"is_variable_product_virtual";s:2:"no";s:43:"is_multiple_variable_product_shipping_class";s:3:"yes";s:40:"multiple_variable_product_shipping_class";s:2:"-1";s:38:"single_variable_product_shipping_class";s:0:"";s:38:"is_multiple_variable_product_tax_class";s:3:"yes";s:35:"multiple_variable_product_tax_class";s:6:"parent";s:33:"single_variable_product_tax_class";s:0:"";s:32:"is_variable_product_downloadable";s:2:"no";s:36:"single_variable_product_downloadable";s:0:"";s:23:"variable_attribute_name";a:2:{i:0;s:0:"";i:1;s:0:"";}s:24:"variable_attribute_value";a:2:{i:0;s:0:"";i:1;s:0:"";}s:22:"variable_in_variations";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:19:"variable_is_visible";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:20:"variable_is_taxonomy";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:38:"variable_create_taxonomy_in_not_exists";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:28:"variable_product_files_delim";s:1:",";s:34:"variable_product_files_names_delim";s:1:",";s:14:"variable_image";s:0:"";s:12:"variable_sku";s:0:"";s:27:"is_variable_product_enabled";s:3:"yes";s:31:"single_variable_product_enabled";s:0:"";s:19:"link_all_variations";s:1:"0";s:25:"variable_stock_use_parent";s:1:"0";s:33:"variable_regular_price_use_parent";s:1:"0";s:30:"variable_sale_price_use_parent";s:1:"0";s:30:"variable_sale_dates_use_parent";s:1:"0";s:26:"variable_weight_use_parent";s:1:"0";s:31:"single_variable_product_virtual";s:0:"";s:42:"single_variable_product_virtual_use_parent";s:1:"0";s:30:"variable_dimensions_use_parent";s:1:"0";s:25:"variable_image_use_parent";s:1:"0";s:49:"single_variable_product_shipping_class_use_parent";s:1:"0";s:44:"single_variable_product_tax_class_use_parent";s:1:"0";s:47:"single_variable_product_downloadable_use_parent";s:1:"0";s:34:"variable_download_limit_use_parent";s:1:"0";s:35:"variable_download_expiry_use_parent";s:1:"0";s:15:"first_is_parent";s:3:"yes";s:28:"single_product_whosale_price";s:0:"";s:22:"variable_whosale_price";s:0:"";s:33:"variable_whosale_price_use_parent";i:0;s:27:"disable_auto_sku_generation";s:1:"0";s:21:"is_default_attributes";s:1:"1";s:20:"disable_sku_matching";s:1:"1";s:21:"disable_prepare_price";s:1:"0";s:18:"grouping_indicator";s:5:"xpath";s:30:"custom_grouping_indicator_name";s:0:"";s:31:"custom_grouping_indicator_value";s:0:"";s:22:"is_update_product_type";s:1:"1";s:20:"is_update_attributes";s:1:"1";s:23:"update_attributes_logic";s:11:"full_update";s:15:"attributes_list";s:1:"0";s:20:"attributes_only_list";s:0:"";s:22:"attributes_except_list";s:0:"";}', '', '2014-07-21 21:04:18', 'No', 'node', 0, 0, 0, '2014-07-21 21:00:04', 23, 23, 23, 0, 0, 1) ;
#
# End of data contents of table wp_pmxi_imports
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_pmxi_posts`
#

DROP TABLE IF EXISTS `wp_pmxi_posts`;


#
# Table structure of table `wp_pmxi_posts`
#

CREATE TABLE `wp_pmxi_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `import_id` bigint(20) unsigned NOT NULL,
  `unique_key` text,
  `product_key` text,
  `iteration` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_pmxi_posts (23 records)
#
 
INSERT INTO `wp_pmxi_posts` VALUES (72, 86, 6, 'Woo Logo - 15 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (73, 89, 6, 'Premium Quality - 19 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (74, 92, 6, 'Ship Your Idea - 22 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (75, 95, 6, 'Ninja Silhouette - 31 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (76, 98, 6, 'Woo Ninja - 34 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (77, 101, 6, 'Happy Ninja - 37 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (78, 104, 6, 'Ship Your Idea - 40 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (79, 107, 6, 'Woo Ninja - 47 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (80, 110, 6, 'Patient Ninja - 50 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (81, 113, 6, 'Happy Ninja - 53 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (82, 116, 6, 'Ninja Silhouette - 56 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (83, 119, 6, 'Woo Logo - 60 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (84, 122, 6, 'Ship Your Idea - 67 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (85, 125, 6, 'Flying Ninja - 70 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (86, 128, 6, 'Premium Quality - 73 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (87, 131, 6, 'Woo Ninja - 76 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (88, 134, 6, 'Woo Logo - 79 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (89, 137, 6, 'Woo Album #1 - 83 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (90, 140, 6, 'Woo Album #2 - 87 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (91, 143, 6, 'Woo Album #3 - 90 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (92, 146, 6, 'Woo Single #1 - 93 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (93, 149, 6, 'Woo Album #4 - 96 - ', '', 0) ; 
INSERT INTO `wp_pmxi_posts` VALUES (94, 152, 6, 'Woo Single #2 - 99 - ', '', 0) ;
#
# End of data contents of table wp_pmxi_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------


#
# Delete any existing table `wp_pmxi_templates`
#

DROP TABLE IF EXISTS `wp_pmxi_templates`;


#
# Table structure of table `wp_pmxi_templates`
#

CREATE TABLE `wp_pmxi_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `options` text,
  `scheduled` varchar(64) NOT NULL DEFAULT '',
  `name` varchar(200) NOT NULL DEFAULT '',
  `title` text,
  `content` longtext,
  `is_keep_linebreaks` tinyint(1) NOT NULL DEFAULT '0',
  `is_leave_html` tinyint(1) NOT NULL DEFAULT '0',
  `fix_characters` tinyint(1) NOT NULL DEFAULT '0',
  `meta` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_pmxi_templates (0 records)
#

#
# End of data contents of table wp_pmxi_templates
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4546 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (839 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 10, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (3, 10, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4, 10, '_edit_lock', '1417741401:1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 13, '_wp_attached_file', '2014/06/2-girls-on-park-bench.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (6, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2592;s:6:"height";i:1936;s:4:"file";s:33:"2014/06/2-girls-on-park-bench.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"2-girls-on-park-bench-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"2-girls-on-park-bench-300x224.jpg";s:5:"width";i:300;s:6:"height";i:224;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:34:"2-girls-on-park-bench-1024x764.jpg";s:5:"width";i:1024;s:6:"height";i:764;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:31:"2-girls-on-park-bench-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:33:"2-girls-on-park-bench-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:33:"2-girls-on-park-bench-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:33:"2-girls-on-park-bench-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:34:"2-girls-on-park-bench-1038x576.jpg";s:5:"width";i:1038;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";d:2.79999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 4";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1377459265;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"3.85";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:15:"0.0666666666667";s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (7, 13, '_edit_lock', '1401915323:1') ; 
INSERT INTO `wp_postmeta` VALUES (8, 13, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (9, 8, '_edit_lock', '1402500945:1') ; 
INSERT INTO `wp_postmeta` VALUES (3582, 86, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3583, 86, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3584, 86, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3585, 86, '_regular_price', '20.00') ; 
INSERT INTO `wp_postmeta` VALUES (3586, 86, '_sale_price', '18.00') ; 
INSERT INTO `wp_postmeta` VALUES (3587, 86, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3588, 86, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3589, 86, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3590, 86, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3591, 86, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3592, 86, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3593, 86, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3594, 86, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3595, 86, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3596, 86, '_sku', '1f5d9aa97c2e') ; 
INSERT INTO `wp_postmeta` VALUES (3597, 86, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3598, 86, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3599, 86, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3600, 86, '_price', '18.00') ; 
INSERT INTO `wp_postmeta` VALUES (3601, 86, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3602, 86, '_stock', '5') ; 
INSERT INTO `wp_postmeta` VALUES (3603, 86, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (3604, 86, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3605, 86, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3606, 86, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3607, 86, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3608, 87, '_wp_attached_file', '2014/07/T_1_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3609, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/T_1_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"T_1_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"T_1_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"T_1_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"T_1_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"T_1_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"T_1_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"T_1_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3610, 86, '_thumbnail_id', '87') ; 
INSERT INTO `wp_postmeta` VALUES (3611, 88, '_wp_attached_file', '2014/07/T_1_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3612, 88, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:20:"2014/07/T_1_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"T_1_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"T_1_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"T_1_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"T_1_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:20:"T_1_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"T_1_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:21:"T_1_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3613, 86, '_product_image_gallery', '88') ; 
INSERT INTO `wp_postmeta` VALUES (3614, 89, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3615, 89, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3616, 89, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3617, 89, '_regular_price', '20.00') ; 
INSERT INTO `wp_postmeta` VALUES (3618, 89, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3619, 89, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3620, 89, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3621, 89, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3622, 89, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3623, 89, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3624, 89, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3625, 89, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3626, 89, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3627, 89, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3628, 89, '_sku', '8941b14b5a4f') ; 
INSERT INTO `wp_postmeta` VALUES (3629, 89, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3630, 89, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3631, 89, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3632, 89, '_price', '20.00') ; 
INSERT INTO `wp_postmeta` VALUES (3633, 89, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3634, 89, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3635, 89, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3636, 89, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3637, 89, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3638, 89, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3639, 90, '_wp_attached_file', '2014/07/T_2_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3640, 90, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/T_2_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"T_2_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"T_2_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"T_2_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"T_2_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"T_2_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"T_2_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"T_2_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3641, 89, '_thumbnail_id', '90') ; 
INSERT INTO `wp_postmeta` VALUES (3642, 91, '_wp_attached_file', '2014/07/T_2_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3643, 91, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:20:"2014/07/T_2_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"T_2_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"T_2_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"T_2_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"T_2_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:20:"T_2_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"T_2_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:21:"T_2_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3644, 89, '_product_image_gallery', '91') ; 
INSERT INTO `wp_postmeta` VALUES (3645, 92, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3646, 92, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3647, 92, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3648, 92, '_regular_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3649, 92, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3650, 92, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3651, 92, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3652, 92, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3653, 92, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3654, 92, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3655, 92, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3656, 92, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3657, 92, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3658, 92, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3659, 92, '_sku', '8713b1c456c0') ; 
INSERT INTO `wp_postmeta` VALUES (3660, 92, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3661, 92, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3662, 92, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3663, 92, '_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3664, 92, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3665, 92, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3666, 92, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3667, 92, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3668, 92, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3669, 92, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3670, 92, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3671, 93, '_wp_attached_file', '2014/07/T_4_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3672, 93, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/T_4_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"T_4_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"T_4_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"T_4_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"T_4_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"T_4_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"T_4_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"T_4_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3673, 92, '_thumbnail_id', '93') ; 
INSERT INTO `wp_postmeta` VALUES (3674, 94, '_wp_attached_file', '2014/07/T_3_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3675, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:20:"2014/07/T_3_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"T_3_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"T_3_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"T_3_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"T_3_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:20:"T_3_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"T_3_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:21:"T_3_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3676, 92, '_product_image_gallery', '94') ; 
INSERT INTO `wp_postmeta` VALUES (3677, 95, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3678, 95, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3679, 95, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3680, 95, '_regular_price', '20.00') ; 
INSERT INTO `wp_postmeta` VALUES (3681, 95, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3682, 95, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3683, 95, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3684, 95, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3685, 95, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3686, 95, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3687, 95, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3688, 95, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3689, 95, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3690, 95, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3691, 95, '_sku', '615f6661aacb') ; 
INSERT INTO `wp_postmeta` VALUES (3692, 95, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3693, 95, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3694, 95, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3695, 95, '_price', '20.00') ; 
INSERT INTO `wp_postmeta` VALUES (3696, 95, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3697, 95, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3698, 95, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3699, 95, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3700, 95, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3701, 95, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3702, 95, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3703, 95, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3704, 96, '_wp_attached_file', '2014/07/T_5_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3705, 96, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/T_5_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"T_5_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"T_5_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"T_5_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"T_5_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"T_5_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"T_5_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"T_5_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3706, 95, '_thumbnail_id', '96') ; 
INSERT INTO `wp_postmeta` VALUES (3707, 97, '_wp_attached_file', '2014/07/T_5_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3708, 97, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:20:"2014/07/T_5_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"T_5_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"T_5_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"T_5_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"T_5_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:20:"T_5_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"T_5_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:21:"T_5_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3709, 95, '_product_image_gallery', '97') ; 
INSERT INTO `wp_postmeta` VALUES (3710, 98, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3711, 98, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3712, 98, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3713, 98, '_regular_price', '20.00') ; 
INSERT INTO `wp_postmeta` VALUES (3714, 98, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3715, 98, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3716, 98, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3717, 98, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3718, 98, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3719, 98, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3720, 98, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3721, 98, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3722, 98, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3723, 98, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3724, 98, '_sku', 'e04f969be146') ; 
INSERT INTO `wp_postmeta` VALUES (3725, 98, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3726, 98, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3727, 98, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3728, 98, '_price', '20.00') ; 
INSERT INTO `wp_postmeta` VALUES (3729, 98, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3730, 98, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3731, 98, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3732, 98, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3733, 98, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3734, 98, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3735, 98, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3736, 98, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3737, 99, '_wp_attached_file', '2014/07/T_6_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3738, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/T_6_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"T_6_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"T_6_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"T_6_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"T_6_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"T_6_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"T_6_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"T_6_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3739, 98, '_thumbnail_id', '99') ; 
INSERT INTO `wp_postmeta` VALUES (3740, 100, '_wp_attached_file', '2014/07/T_6_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3741, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:20:"2014/07/T_6_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"T_6_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"T_6_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"T_6_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"T_6_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:20:"T_6_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"T_6_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:21:"T_6_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3742, 98, '_product_image_gallery', '100') ; 
INSERT INTO `wp_postmeta` VALUES (3743, 101, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3744, 101, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3745, 101, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3746, 101, '_regular_price', '18.00') ; 
INSERT INTO `wp_postmeta` VALUES (3747, 101, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3748, 101, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3749, 101, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3750, 101, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3751, 101, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3752, 101, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3753, 101, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3754, 101, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3755, 101, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3756, 101, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3757, 101, '_sku', 'e6917f7bce72') ; 
INSERT INTO `wp_postmeta` VALUES (3758, 101, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3759, 101, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3760, 101, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3761, 101, '_price', '18.00') ; 
INSERT INTO `wp_postmeta` VALUES (3762, 101, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3763, 101, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3764, 101, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3765, 101, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3766, 101, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3767, 101, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3768, 101, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3769, 101, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3770, 102, '_wp_attached_file', '2014/07/T_7_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3771, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/T_7_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"T_7_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"T_7_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"T_7_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"T_7_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"T_7_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"T_7_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"T_7_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3772, 101, '_thumbnail_id', '102') ; 
INSERT INTO `wp_postmeta` VALUES (3773, 103, '_wp_attached_file', '2014/07/T_7_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3774, 103, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:20:"2014/07/T_7_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"T_7_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"T_7_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"T_7_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"T_7_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:20:"T_7_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"T_7_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:21:"T_7_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3775, 101, '_product_image_gallery', '103') ; 
INSERT INTO `wp_postmeta` VALUES (3776, 104, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3777, 104, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3778, 104, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3779, 104, '_regular_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3780, 104, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3781, 104, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3782, 104, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3783, 104, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3784, 104, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3785, 104, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3786, 104, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3787, 104, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3788, 104, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3789, 104, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3790, 104, '_sku', '3feaaee0b44e') ; 
INSERT INTO `wp_postmeta` VALUES (3791, 104, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3792, 104, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3793, 104, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3794, 104, '_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3795, 104, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3796, 104, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3797, 104, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3798, 104, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3799, 104, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3800, 104, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3801, 104, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3802, 105, '_wp_attached_file', '2014/07/hoodie_7_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3803, 105, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:26:"2014/07/hoodie_7_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"hoodie_7_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"hoodie_7_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:24:"hoodie_7_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:26:"hoodie_7_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:26:"hoodie_7_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"hoodie_7_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:27:"hoodie_7_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3804, 104, '_thumbnail_id', '105') ; 
INSERT INTO `wp_postmeta` VALUES (3805, 106, '_wp_attached_file', '2014/07/hoodie_7_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3806, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/hoodie_7_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"hoodie_7_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"hoodie_7_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"hoodie_7_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"hoodie_7_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"hoodie_7_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"hoodie_7_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"hoodie_7_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3807, 104, '_product_image_gallery', '106') ; 
INSERT INTO `wp_postmeta` VALUES (3808, 107, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3809, 107, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3810, 107, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3811, 107, '_regular_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3812, 107, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3813, 107, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3814, 107, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3815, 107, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3816, 107, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3817, 107, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3818, 107, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3819, 107, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3820, 107, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3821, 107, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3822, 107, '_sku', '21209aee5ff1') ; 
INSERT INTO `wp_postmeta` VALUES (3823, 107, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3824, 107, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3825, 107, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3826, 107, '_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3827, 107, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3828, 107, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3829, 107, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3830, 107, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3831, 107, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3832, 107, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3833, 107, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3834, 108, '_wp_attached_file', '2014/07/hoodie_2_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3835, 108, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:26:"2014/07/hoodie_2_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"hoodie_2_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"hoodie_2_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:24:"hoodie_2_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:26:"hoodie_2_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:26:"hoodie_2_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"hoodie_2_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:27:"hoodie_2_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3836, 107, '_thumbnail_id', '108') ; 
INSERT INTO `wp_postmeta` VALUES (3837, 109, '_wp_attached_file', '2014/07/hoodie_2_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3838, 109, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/hoodie_2_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"hoodie_2_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"hoodie_2_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"hoodie_2_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"hoodie_2_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"hoodie_2_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"hoodie_2_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"hoodie_2_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3839, 107, '_product_image_gallery', '109') ; 
INSERT INTO `wp_postmeta` VALUES (3840, 110, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3841, 110, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3842, 110, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3843, 110, '_regular_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3844, 110, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3845, 110, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3846, 110, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3847, 110, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3848, 110, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3849, 110, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3850, 110, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3851, 110, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3852, 110, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3853, 110, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3854, 110, '_sku', '6b0d5bf5e014') ; 
INSERT INTO `wp_postmeta` VALUES (3855, 110, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3856, 110, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3857, 110, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3858, 110, '_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3859, 110, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3860, 110, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3861, 110, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3862, 110, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3863, 110, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3864, 110, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3865, 110, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3866, 111, '_wp_attached_file', '2014/07/hoodie_3_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3867, 111, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:26:"2014/07/hoodie_3_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"hoodie_3_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"hoodie_3_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:24:"hoodie_3_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:26:"hoodie_3_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:26:"hoodie_3_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"hoodie_3_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:27:"hoodie_3_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3868, 110, '_thumbnail_id', '111') ; 
INSERT INTO `wp_postmeta` VALUES (3869, 112, '_wp_attached_file', '2014/07/hoodie_3_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3870, 112, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/hoodie_3_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"hoodie_3_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"hoodie_3_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"hoodie_3_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"hoodie_3_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"hoodie_3_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"hoodie_3_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"hoodie_3_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3871, 110, '_product_image_gallery', '112') ; 
INSERT INTO `wp_postmeta` VALUES (3872, 113, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3873, 113, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3874, 113, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3875, 113, '_regular_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3876, 113, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3877, 113, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3878, 113, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3879, 113, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3880, 113, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3881, 113, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3882, 113, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3883, 113, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3884, 113, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3885, 113, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3886, 113, '_sku', '5b155cb59069') ; 
INSERT INTO `wp_postmeta` VALUES (3887, 113, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3888, 113, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3889, 113, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3890, 113, '_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3891, 113, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3892, 113, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3893, 113, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3894, 113, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3895, 113, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3896, 113, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3897, 113, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3898, 114, '_wp_attached_file', '2014/07/hoodie_4_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3899, 114, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:26:"2014/07/hoodie_4_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"hoodie_4_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"hoodie_4_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:24:"hoodie_4_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:26:"hoodie_4_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:26:"hoodie_4_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"hoodie_4_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:27:"hoodie_4_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3900, 113, '_thumbnail_id', '114') ; 
INSERT INTO `wp_postmeta` VALUES (3901, 115, '_wp_attached_file', '2014/07/hoodie_4_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3902, 115, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/hoodie_4_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"hoodie_4_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"hoodie_4_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"hoodie_4_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"hoodie_4_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"hoodie_4_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"hoodie_4_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"hoodie_4_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3903, 113, '_product_image_gallery', '115') ; 
INSERT INTO `wp_postmeta` VALUES (3904, 116, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3905, 116, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3906, 116, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3907, 116, '_regular_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3908, 116, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3909, 116, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3910, 116, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3911, 116, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3912, 116, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3913, 116, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3914, 116, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3915, 116, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3916, 116, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3917, 116, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3918, 116, '_sku', '43c7bca5405f') ; 
INSERT INTO `wp_postmeta` VALUES (3919, 116, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3920, 116, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3921, 116, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3922, 116, '_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3923, 116, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3924, 116, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3925, 116, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3926, 116, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3927, 116, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3928, 116, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3929, 116, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3930, 117, '_wp_attached_file', '2014/07/hoodie_5_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3931, 117, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:26:"2014/07/hoodie_5_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"hoodie_5_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"hoodie_5_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:24:"hoodie_5_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:26:"hoodie_5_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:26:"hoodie_5_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"hoodie_5_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:27:"hoodie_5_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3932, 116, '_thumbnail_id', '117') ; 
INSERT INTO `wp_postmeta` VALUES (3933, 118, '_wp_attached_file', '2014/07/hoodie_5_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3934, 118, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/hoodie_5_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"hoodie_5_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"hoodie_5_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"hoodie_5_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"hoodie_5_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"hoodie_5_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"hoodie_5_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"hoodie_5_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3935, 116, '_product_image_gallery', '118') ; 
INSERT INTO `wp_postmeta` VALUES (3936, 119, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3937, 119, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3938, 119, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3939, 119, '_regular_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3940, 119, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3941, 119, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3942, 119, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3943, 119, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3944, 119, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3945, 119, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3946, 119, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (3947, 119, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3948, 119, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3949, 119, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3950, 119, '_sku', '3cb52d7f2f39') ; 
INSERT INTO `wp_postmeta` VALUES (3951, 119, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3952, 119, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3953, 119, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3954, 119, '_price', '35.00') ; 
INSERT INTO `wp_postmeta` VALUES (3955, 119, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3956, 119, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3957, 119, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3958, 119, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3959, 119, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3960, 119, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3961, 119, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3962, 120, '_wp_attached_file', '2014/07/hoodie_6_front.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3963, 120, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:26:"2014/07/hoodie_6_front.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"hoodie_6_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"hoodie_6_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:24:"hoodie_6_front-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:26:"hoodie_6_front-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:26:"hoodie_6_front-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"hoodie_6_front-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:27:"hoodie_6_front-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3964, 119, '_thumbnail_id', '120') ; 
INSERT INTO `wp_postmeta` VALUES (3965, 121, '_wp_attached_file', '2014/07/hoodie_6_back.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3966, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/hoodie_6_back.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"hoodie_6_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"hoodie_6_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"hoodie_6_back-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"hoodie_6_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"hoodie_6_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"hoodie_6_back-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"hoodie_6_back-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3967, 119, '_product_image_gallery', '121') ; 
INSERT INTO `wp_postmeta` VALUES (3968, 122, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3969, 122, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3970, 122, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3971, 122, '_regular_price', '15.00') ; 
INSERT INTO `wp_postmeta` VALUES (3972, 122, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (3973, 122, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (3974, 122, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (3975, 122, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (3976, 122, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (3977, 122, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3978, 122, '_weight', '14') ; 
INSERT INTO `wp_postmeta` VALUES (3979, 122, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (3980, 122, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (3981, 122, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (3982, 122, '_sku', 'dc0b914deae7') ; 
INSERT INTO `wp_postmeta` VALUES (3983, 122, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (3984, 122, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (3985, 122, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (3986, 122, '_price', '15.00') ; 
INSERT INTO `wp_postmeta` VALUES (3987, 122, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (3988, 122, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3989, 122, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (3990, 122, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (3991, 122, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (3994, 122, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (3995, 123, '_wp_attached_file', '2014/07/poster_1_up.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3996, 123, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:23:"2014/07/poster_1_up.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"poster_1_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"poster_1_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"poster_1_up-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"poster_1_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"poster_1_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"poster_1_up-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:24:"poster_1_up-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (3997, 122, '_thumbnail_id', '123') ; 
INSERT INTO `wp_postmeta` VALUES (3998, 124, '_wp_attached_file', '2014/07/Poster_1_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3999, 124, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/Poster_1_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Poster_1_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Poster_1_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"Poster_1_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"Poster_1_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"Poster_1_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Poster_1_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"Poster_1_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4000, 122, '_product_image_gallery', '124') ; 
INSERT INTO `wp_postmeta` VALUES (4001, 125, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4002, 125, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4003, 125, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4004, 125, '_regular_price', '15.00') ; 
INSERT INTO `wp_postmeta` VALUES (4005, 125, '_sale_price', '12.00') ; 
INSERT INTO `wp_postmeta` VALUES (4006, 125, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4007, 125, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4008, 125, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4009, 125, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4010, 125, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4011, 125, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4012, 125, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4013, 125, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4014, 125, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4015, 125, '_sku', '0dc10b56bb83') ; 
INSERT INTO `wp_postmeta` VALUES (4016, 125, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4017, 125, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4018, 125, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4019, 125, '_price', '12.00') ; 
INSERT INTO `wp_postmeta` VALUES (4020, 125, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4021, 125, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4022, 125, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (4023, 125, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4024, 125, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4025, 125, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4026, 126, '_wp_attached_file', '2014/07/poster_2_up.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4027, 126, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:23:"2014/07/poster_2_up.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"poster_2_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"poster_2_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"poster_2_up-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"poster_2_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"poster_2_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"poster_2_up-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:24:"poster_2_up-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4028, 125, '_thumbnail_id', '126') ; 
INSERT INTO `wp_postmeta` VALUES (4029, 127, '_wp_attached_file', '2014/07/Poster_2_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4030, 127, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/Poster_2_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Poster_2_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Poster_2_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"Poster_2_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"Poster_2_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"Poster_2_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Poster_2_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"Poster_2_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4031, 125, '_product_image_gallery', '127') ; 
INSERT INTO `wp_postmeta` VALUES (4032, 128, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4033, 128, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4034, 128, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4035, 128, '_regular_price', '15.00') ; 
INSERT INTO `wp_postmeta` VALUES (4036, 128, '_sale_price', '12.00') ; 
INSERT INTO `wp_postmeta` VALUES (4037, 128, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4038, 128, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4039, 128, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4040, 128, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4041, 128, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4042, 128, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4043, 128, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4044, 128, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4045, 128, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4046, 128, '_sku', 'c456663465d9') ; 
INSERT INTO `wp_postmeta` VALUES (4047, 128, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4048, 128, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4049, 128, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4050, 128, '_price', '12.00') ; 
INSERT INTO `wp_postmeta` VALUES (4051, 128, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4052, 128, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4053, 128, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (4054, 128, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4055, 128, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4056, 128, '_upsell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4057, 128, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4058, 129, '_wp_attached_file', '2014/07/poster_3_up.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4059, 129, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:23:"2014/07/poster_3_up.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"poster_3_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"poster_3_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"poster_3_up-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"poster_3_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"poster_3_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"poster_3_up-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:24:"poster_3_up-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4060, 128, '_thumbnail_id', '129') ; 
INSERT INTO `wp_postmeta` VALUES (4061, 130, '_wp_attached_file', '2014/07/Poster_3_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4062, 130, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/Poster_3_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Poster_3_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Poster_3_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"Poster_3_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"Poster_3_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"Poster_3_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Poster_3_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"Poster_3_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4063, 128, '_product_image_gallery', '130') ; 
INSERT INTO `wp_postmeta` VALUES (4064, 131, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4065, 131, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4066, 131, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4067, 131, '_regular_price', '15.00') ; 
INSERT INTO `wp_postmeta` VALUES (4068, 131, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (4069, 131, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4070, 131, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4071, 131, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4072, 131, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4073, 131, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4074, 131, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4075, 131, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4076, 131, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4077, 131, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4078, 131, '_sku', 'd67ba2dccc7a') ; 
INSERT INTO `wp_postmeta` VALUES (4079, 131, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4080, 131, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4081, 131, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4082, 131, '_price', '15.00') ; 
INSERT INTO `wp_postmeta` VALUES (4083, 131, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4084, 131, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4085, 131, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (4086, 131, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4087, 131, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4088, 131, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4089, 131, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4090, 132, '_wp_attached_file', '2014/07/poster_4_up.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4091, 132, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:23:"2014/07/poster_4_up.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"poster_4_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"poster_4_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"poster_4_up-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"poster_4_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"poster_4_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"poster_4_up-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:24:"poster_4_up-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4092, 131, '_thumbnail_id', '132') ; 
INSERT INTO `wp_postmeta` VALUES (4093, 133, '_wp_attached_file', '2014/07/Poster_4_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4094, 133, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/Poster_4_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Poster_4_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Poster_4_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"Poster_4_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"Poster_4_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"Poster_4_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Poster_4_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"Poster_4_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4095, 131, '_product_image_gallery', '133') ; 
INSERT INTO `wp_postmeta` VALUES (4096, 134, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4097, 134, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4098, 134, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4099, 134, '_regular_price', '15.00') ; 
INSERT INTO `wp_postmeta` VALUES (4100, 134, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (4101, 134, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4102, 134, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4103, 134, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4104, 134, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4105, 134, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4106, 134, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4107, 134, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4108, 134, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4109, 134, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4110, 134, '_sku', '76223ed487b2') ; 
INSERT INTO `wp_postmeta` VALUES (4111, 134, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4112, 134, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4113, 134, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4114, 134, '_price', '15.00') ; 
INSERT INTO `wp_postmeta` VALUES (4115, 134, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4116, 134, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4117, 134, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (4118, 134, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4119, 134, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4120, 134, '_crosssell_ids', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4121, 134, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4122, 135, '_wp_attached_file', '2014/07/poster_5_up.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4123, 135, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:23:"2014/07/poster_5_up.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"poster_5_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"poster_5_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"poster_5_up-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"poster_5_up-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:23:"poster_5_up-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"poster_5_up-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:24:"poster_5_up-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4124, 134, '_thumbnail_id', '135') ; 
INSERT INTO `wp_postmeta` VALUES (4125, 136, '_wp_attached_file', '2014/07/Poster_5_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4126, 136, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:25:"2014/07/Poster_5_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Poster_5_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Poster_5_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"Poster_5_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"Poster_5_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"Poster_5_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Poster_5_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:26:"Poster_5_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4127, 134, '_product_image_gallery', '136') ; 
INSERT INTO `wp_postmeta` VALUES (4128, 137, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4129, 137, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4130, 137, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4131, 137, '_regular_price', '9.00') ; 
INSERT INTO `wp_postmeta` VALUES (4132, 137, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (4133, 137, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4134, 137, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4135, 137, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4136, 137, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4137, 137, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4138, 137, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4139, 137, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4140, 137, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4141, 137, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4142, 137, '_sku', '69c65580e50c') ; 
INSERT INTO `wp_postmeta` VALUES (4143, 137, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4144, 137, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4145, 137, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4146, 137, '_price', '9.00') ; 
INSERT INTO `wp_postmeta` VALUES (4147, 137, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4148, 137, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4149, 137, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (4150, 137, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4151, 137, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4152, 137, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4153, 138, '_wp_attached_file', '2014/07/cd_1_angle.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4154, 138, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:22:"2014/07/cd_1_angle.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"cd_1_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"cd_1_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:20:"cd_1_angle-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:22:"cd_1_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:22:"cd_1_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"cd_1_angle-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:23:"cd_1_angle-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4155, 137, '_thumbnail_id', '138') ; 
INSERT INTO `wp_postmeta` VALUES (4156, 139, '_wp_attached_file', '2014/07/cd_1_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4157, 139, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/cd_1_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"cd_1_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"cd_1_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"cd_1_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"cd_1_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"cd_1_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"cd_1_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"cd_1_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4158, 137, '_product_image_gallery', '139') ; 
INSERT INTO `wp_postmeta` VALUES (4159, 140, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4160, 140, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4161, 140, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4162, 140, '_regular_price', '9.00') ; 
INSERT INTO `wp_postmeta` VALUES (4163, 140, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (4164, 140, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4165, 140, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4166, 140, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4167, 140, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4168, 140, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4169, 140, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4170, 140, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4171, 140, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4172, 140, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4173, 140, '_sku', '97c7710c91bd') ; 
INSERT INTO `wp_postmeta` VALUES (4174, 140, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4175, 140, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4176, 140, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4177, 140, '_price', '9.00') ; 
INSERT INTO `wp_postmeta` VALUES (4178, 140, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4179, 140, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4180, 140, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (4181, 140, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4182, 140, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4183, 140, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4184, 141, '_wp_attached_file', '2014/07/cd_2_angle.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4185, 141, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:22:"2014/07/cd_2_angle.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"cd_2_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"cd_2_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:20:"cd_2_angle-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:22:"cd_2_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:22:"cd_2_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"cd_2_angle-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:23:"cd_2_angle-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4186, 140, '_thumbnail_id', '141') ; 
INSERT INTO `wp_postmeta` VALUES (4187, 142, '_wp_attached_file', '2014/07/cd_2_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4188, 142, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/cd_2_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"cd_2_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"cd_2_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"cd_2_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"cd_2_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"cd_2_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"cd_2_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"cd_2_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4189, 140, '_product_image_gallery', '142') ; 
INSERT INTO `wp_postmeta` VALUES (4190, 143, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4191, 143, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4192, 143, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4193, 143, '_regular_price', '9.00') ; 
INSERT INTO `wp_postmeta` VALUES (4194, 143, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (4195, 143, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4196, 143, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4197, 143, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4198, 143, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4199, 143, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4200, 143, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4201, 143, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4202, 143, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4203, 143, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4204, 143, '_sku', '072925490d29') ; 
INSERT INTO `wp_postmeta` VALUES (4205, 143, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4206, 143, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4207, 143, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4208, 143, '_price', '9.00') ; 
INSERT INTO `wp_postmeta` VALUES (4209, 143, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4210, 143, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4211, 143, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (4212, 143, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4213, 143, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4214, 143, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4215, 144, '_wp_attached_file', '2014/07/cd_3_angle.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4216, 144, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:22:"2014/07/cd_3_angle.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"cd_3_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"cd_3_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:20:"cd_3_angle-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:22:"cd_3_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:22:"cd_3_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"cd_3_angle-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:23:"cd_3_angle-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4217, 143, '_thumbnail_id', '144') ; 
INSERT INTO `wp_postmeta` VALUES (4218, 145, '_wp_attached_file', '2014/07/cd_3_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4219, 145, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/cd_3_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"cd_3_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"cd_3_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"cd_3_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"cd_3_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"cd_3_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"cd_3_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"cd_3_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4220, 143, '_product_image_gallery', '145') ; 
INSERT INTO `wp_postmeta` VALUES (4221, 146, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4222, 146, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4223, 146, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4224, 146, '_regular_price', '3.00') ; 
INSERT INTO `wp_postmeta` VALUES (4225, 146, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (4226, 146, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4227, 146, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4228, 146, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4229, 146, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4230, 146, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4231, 146, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4232, 146, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4233, 146, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4234, 146, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4235, 146, '_sku', 'dfc6609be247') ; 
INSERT INTO `wp_postmeta` VALUES (4236, 146, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4237, 146, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4238, 146, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4239, 146, '_price', '3.00') ; 
INSERT INTO `wp_postmeta` VALUES (4240, 146, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4241, 146, '_stock', '20') ; 
INSERT INTO `wp_postmeta` VALUES (4242, 146, '_stock_status', 'instock') ; 
INSERT INTO `wp_postmeta` VALUES (4243, 146, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4244, 146, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4245, 146, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4246, 147, '_wp_attached_file', '2014/07/cd_4_angle.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4247, 147, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:22:"2014/07/cd_4_angle.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"cd_4_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"cd_4_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:20:"cd_4_angle-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:22:"cd_4_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:22:"cd_4_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"cd_4_angle-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:23:"cd_4_angle-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4248, 146, '_thumbnail_id', '147') ; 
INSERT INTO `wp_postmeta` VALUES (4249, 148, '_wp_attached_file', '2014/07/cd_4_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4250, 148, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/cd_4_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"cd_4_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"cd_4_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"cd_4_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"cd_4_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"cd_4_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"cd_4_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"cd_4_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4251, 146, '_product_image_gallery', '148') ; 
INSERT INTO `wp_postmeta` VALUES (4252, 149, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4253, 149, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4254, 149, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4255, 149, '_regular_price', '9.00') ; 
INSERT INTO `wp_postmeta` VALUES (4256, 149, '_sale_price', '') ; 
INSERT INTO `wp_postmeta` VALUES (4257, 149, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4258, 149, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4259, 149, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4260, 149, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4261, 149, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4262, 149, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4263, 149, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4264, 149, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4265, 149, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4266, 149, '_sku', 'caf582f7432c') ; 
INSERT INTO `wp_postmeta` VALUES (4267, 149, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4268, 149, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4269, 149, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4270, 149, '_price', '9.00') ; 
INSERT INTO `wp_postmeta` VALUES (4271, 149, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4272, 149, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4273, 149, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (4274, 149, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4275, 149, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4276, 149, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4277, 150, '_wp_attached_file', '2014/07/cd_5_angle.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4278, 150, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:22:"2014/07/cd_5_angle.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"cd_5_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"cd_5_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:20:"cd_5_angle-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:22:"cd_5_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:22:"cd_5_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"cd_5_angle-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:23:"cd_5_angle-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4279, 149, '_thumbnail_id', '150') ; 
INSERT INTO `wp_postmeta` VALUES (4280, 151, '_wp_attached_file', '2014/07/cd_5_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4281, 151, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/cd_5_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"cd_5_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"cd_5_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"cd_5_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"cd_5_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"cd_5_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"cd_5_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"cd_5_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4282, 149, '_product_image_gallery', '151') ; 
INSERT INTO `wp_postmeta` VALUES (4283, 152, 'total_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4284, 152, '_downloadable', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4285, 152, '_virtual', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4286, 152, '_regular_price', '3.00') ; 
INSERT INTO `wp_postmeta` VALUES (4287, 152, '_sale_price', '2.00') ; 
INSERT INTO `wp_postmeta` VALUES (4288, 152, '_tax_status', 'none') ; 
INSERT INTO `wp_postmeta` VALUES (4289, 152, '_tax_class', '') ; 
INSERT INTO `wp_postmeta` VALUES (4290, 152, '_visibility', 'visible') ; 
INSERT INTO `wp_postmeta` VALUES (4291, 152, '_purchase_note', '') ; 
INSERT INTO `wp_postmeta` VALUES (4292, 152, '_featured', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4293, 152, '_weight', '') ; 
INSERT INTO `wp_postmeta` VALUES (4294, 152, '_length', '') ; 
INSERT INTO `wp_postmeta` VALUES (4295, 152, '_width', '') ; 
INSERT INTO `wp_postmeta` VALUES (4296, 152, '_height', '') ; 
INSERT INTO `wp_postmeta` VALUES (4297, 152, '_sku', 'ff3ce75e6862') ; 
INSERT INTO `wp_postmeta` VALUES (4298, 152, '_product_attributes', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4299, 152, '_sale_price_dates_from', '') ; 
INSERT INTO `wp_postmeta` VALUES (4300, 152, '_sale_price_dates_to', '') ; 
INSERT INTO `wp_postmeta` VALUES (4301, 152, '_price', '2.00') ; 
INSERT INTO `wp_postmeta` VALUES (4302, 152, '_sold_individually', '') ; 
INSERT INTO `wp_postmeta` VALUES (4303, 152, '_stock', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4304, 152, '_stock_status', 'outofstock') ; 
INSERT INTO `wp_postmeta` VALUES (4305, 152, '_backorders', 'no') ; 
INSERT INTO `wp_postmeta` VALUES (4306, 152, '_manage_stock', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (4307, 152, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4308, 153, '_wp_attached_file', '2014/07/cd_6_angle.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4309, 153, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:22:"2014/07/cd_6_angle.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"cd_6_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"cd_6_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:20:"cd_6_angle-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:22:"cd_6_angle-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:22:"cd_6_angle-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"cd_6_angle-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:23:"cd_6_angle-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4310, 152, '_thumbnail_id', '153') ; 
INSERT INTO `wp_postmeta` VALUES (4311, 154, '_wp_attached_file', '2014/07/cd_6_flat.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4312, 154, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1000;s:4:"file";s:21:"2014/07/cd_6_flat.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"cd_6_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"cd_6_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"cd_6_flat-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"cd_6_flat-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"cd_6_flat-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"cd_6_flat-672x372.jpg";s:5:"width";i:672;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:25:"twentyfourteen-full-width";a:4:{s:4:"file";s:22:"cd_6_flat-1000x576.jpg";s:5:"width";i:1000;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4313, 152, '_product_image_gallery', '154') ; 
INSERT INTO `wp_postmeta` VALUES (4314, 152, '_edit_lock', '1417741490:1') ; 
INSERT INTO `wp_postmeta` VALUES (4315, 86, '_edit_lock', '1406649199:1') ; 
INSERT INTO `wp_postmeta` VALUES (4316, 122, '_edit_lock', '1411947438:1') ; 
INSERT INTO `wp_postmeta` VALUES (4317, 95, '_edit_lock', '1411428129:1') ; 
INSERT INTO `wp_postmeta` VALUES (4318, 146, '_edit_lock', '1410557126:1') ; 
INSERT INTO `wp_postmeta` VALUES (4319, 146, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4320, 1, '_edit_lock', '1410563710:1') ; 
INSERT INTO `wp_postmeta` VALUES (4321, 1, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4324, 159, '_wp_attached_file', '2014/05/twin_skincare.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4325, 159, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:326;s:4:"file";s:25:"2014/05/twin_skincare.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"twin_skincare-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"twin_skincare-300x195.jpg";s:5:"width";i:300;s:6:"height";i:195;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"twin_skincare-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"twin_skincare-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:25:"twin_skincare-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";d:5.5999999999999996447286321199499070644378662109375;s:6:"credit";s:14:"Mark Leibowitz";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1348799697;s:9:"copyright";s:50:"© Copyright Mark Leibowitz.  All rights reserved.";s:12:"focal_length";s:2:"58";s:3:"iso";s:3:"250";s:13:"shutter_speed";s:5:"0.008";s:5:"title";s:70:"Vionnet Backstage at Paris Fashion Week Spring Summer 2013 Collections";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4326, 1, '_thumbnail_id', '159') ; 
INSERT INTO `wp_postmeta` VALUES (4333, 162, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4334, 162, '_edit_lock', '1409181466:1') ; 
INSERT INTO `wp_postmeta` VALUES (4335, 163, '_wp_attached_file', '2014/07/pooljump.png') ; 
INSERT INTO `wp_postmeta` VALUES (4336, 163, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:373;s:4:"file";s:20:"2014/07/pooljump.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"pooljump-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:20:"pooljump-300x223.png";s:5:"width";i:300;s:6:"height";i:223;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"pooljump-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"pooljump-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:20:"pooljump-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"pooljump-500x372.png";s:5:"width";i:500;s:6:"height";i:372;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4337, 162, '_thumbnail_id', '163') ; 
INSERT INTO `wp_postmeta` VALUES (4342, 165, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4343, 165, '_edit_lock', '1413418226:1') ; 
INSERT INTO `wp_postmeta` VALUES (4344, 166, '_wp_attached_file', '2014/07/purptips.png') ; 
INSERT INTO `wp_postmeta` VALUES (4345, 166, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:499;s:4:"file";s:20:"2014/07/purptips.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"purptips-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:20:"purptips-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"purptips-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"purptips-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:20:"purptips-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"purptips-500x372.png";s:5:"width";i:500;s:6:"height";i:372;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4349, 168, '_wp_attached_file', '2014/07/nail9.png') ; 
INSERT INTO `wp_postmeta` VALUES (4350, 168, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:501;s:4:"file";s:17:"2014/07/nail9.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nail9-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"nail9-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"nail9-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"nail9-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:17:"nail9-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"nail9-500x372.png";s:5:"width";i:500;s:6:"height";i:372;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4351, 169, '_wp_attached_file', '2014/07/nail8.png') ; 
INSERT INTO `wp_postmeta` VALUES (4352, 169, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:500;s:4:"file";s:17:"2014/07/nail8.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nail8-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"nail8-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"nail8-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"nail8-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:17:"nail8-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"nail8-500x372.png";s:5:"width";i:500;s:6:"height";i:372;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4353, 170, '_wp_attached_file', '2014/07/nail7.png') ; 
INSERT INTO `wp_postmeta` VALUES (4354, 170, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:500;s:4:"file";s:17:"2014/07/nail7.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nail7-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"nail7-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"nail7-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"nail7-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:17:"nail7-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"nail7-500x372.png";s:5:"width";i:500;s:6:"height";i:372;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4355, 171, '_wp_attached_file', '2014/07/nail5.png') ; 
INSERT INTO `wp_postmeta` VALUES (4356, 171, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:497;s:4:"file";s:17:"2014/07/nail5.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nail5-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"nail5-300x298.png";s:5:"width";i:300;s:6:"height";i:298;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"nail5-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"nail5-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:17:"nail5-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"nail5-500x372.png";s:5:"width";i:500;s:6:"height";i:372;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4357, 172, '_wp_attached_file', '2014/07/nail4.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (4358, 172, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:250;s:4:"file";s:17:"2014/07/nail4.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nail4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"nail4-300x150.jpg";s:5:"width";i:300;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"nail4-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"nail4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:17:"nail4-300x250.jpg";s:5:"width";i:300;s:6:"height";i:250;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4359, 173, '_wp_attached_file', '2014/07/nail3.png') ; 
INSERT INTO `wp_postmeta` VALUES (4360, 173, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:497;s:4:"file";s:17:"2014/07/nail3.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nail3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"nail3-300x298.png";s:5:"width";i:300;s:6:"height";i:298;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"nail3-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"nail3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:17:"nail3-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"nail3-500x372.png";s:5:"width";i:500;s:6:"height";i:372;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4361, 174, '_wp_attached_file', '2014/07/nAIL2.png') ; 
INSERT INTO `wp_postmeta` VALUES (4362, 174, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:501;s:4:"file";s:17:"2014/07/nAIL2.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nAIL2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"nAIL2-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"nAIL2-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"nAIL2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:17:"nAIL2-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"nAIL2-500x372.png";s:5:"width";i:500;s:6:"height";i:372;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4363, 175, '_wp_attached_file', '2014/07/nail1.png') ; 
INSERT INTO `wp_postmeta` VALUES (4364, 175, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:502;s:4:"file";s:17:"2014/07/nail1.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nail1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"nail1-298x300.png";s:5:"width";i:298;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"nail1-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"nail1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:17:"nail1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"nail1-500x372.png";s:5:"width";i:500;s:6:"height";i:372;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4367, 165, '_thumbnail_id', '175') ; 
INSERT INTO `wp_postmeta` VALUES (4369, 183, '_edit_lock', '1410464003:1') ; 
INSERT INTO `wp_postmeta` VALUES (4370, 183, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4371, 183, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4372, 185, '_edit_lock', '1410464028:1') ; 
INSERT INTO `wp_postmeta` VALUES (4373, 185, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4374, 185, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4376, 92, '_edit_lock', '1411426476:1') ; 
INSERT INTO `wp_postmeta` VALUES (4377, 104, '_edit_lock', '1411425760:1') ; 
INSERT INTO `wp_postmeta` VALUES (4378, 122, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4379, 122, 'mycred_reward', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (4380, 110, '_edit_lock', '1411946389:1') ; 
INSERT INTO `wp_postmeta` VALUES (4381, 175, '_edit_lock', '1412015296:1') ; 
INSERT INTO `wp_postmeta` VALUES (4382, 5, '_edit_lock', '1412648461:1') ; 
INSERT INTO `wp_postmeta` VALUES (4383, 193, '_edit_lock', '1413395448:1') ; 
INSERT INTO `wp_postmeta` VALUES (4384, 193, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4385, 193, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (4386, 4, '_edit_lock', '1413393512:1') ; 
INSERT INTO `wp_postmeta` VALUES (4468, 212, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (4469, 212, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4470, 212, '_menu_item_object_id', '193') ; 
INSERT INTO `wp_postmeta` VALUES (4471, 212, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (4472, 212, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (4473, 212, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (4474, 212, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (4475, 212, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (4495, 215, '_edit_lock', '1413413775:1') ; 
INSERT INTO `wp_postmeta` VALUES (4496, 215, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4497, 218, '_edit_lock', '1413418069:1') ; 
INSERT INTO `wp_postmeta` VALUES (4498, 218, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4510, 223, '_edit_lock', '1413419380:1') ; 
INSERT INTO `wp_postmeta` VALUES (4511, 223, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4512, 225, '_edit_lock', '1413486513:1') ; 
INSERT INTO `wp_postmeta` VALUES (4513, 225, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4514, 228, '_edit_lock', '1413486552:1') ; 
INSERT INTO `wp_postmeta` VALUES (4515, 228, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4516, 230, '_edit_lock', '1413486573:1') ; 
INSERT INTO `wp_postmeta` VALUES (4517, 230, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4518, 232, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (4519, 232, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4520, 232, '_menu_item_object_id', '230') ; 
INSERT INTO `wp_postmeta` VALUES (4521, 232, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (4522, 232, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (4523, 232, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (4524, 232, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (4525, 232, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (4527, 233, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (4528, 233, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4529, 233, '_menu_item_object_id', '228') ; 
INSERT INTO `wp_postmeta` VALUES (4530, 233, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (4531, 233, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (4532, 233, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (4533, 233, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (4534, 233, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (4536, 234, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (4537, 234, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (4538, 234, '_menu_item_object_id', '225') ; 
INSERT INTO `wp_postmeta` VALUES (4539, 234, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (4540, 234, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (4541, 234, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (4542, 234, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (4543, 234, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (4544, 6, '_edit_lock', '1417741429:1') ; 
INSERT INTO `wp_postmeta` VALUES (4545, 123, '_edit_lock', '1418020493:1') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=238 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (139 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-05-26 22:33:13', '2014-05-26 22:33:13', '<p style="color: #555f57;"><em style="font-weight: inherit;">What is Vitamin C?</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">Aging is something of a four-letter word in the beauty business (er, we suppose it’s more like five letters). While completely unavoidable and totally natural, it still strikes fear in the hearts of even the genetically blessed. This leaves us with two options:</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">1. Freak the eff out.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">-or-</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">2. Accept the inevitable, get your game face on, and tackle this aging business with a modicum of grace.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">If you’ve chosen option 1, we can’t with you right now. If you’re in the mood to try door #2, we’re pleased to help you navigate the wealthy, but often overwhelming world of anti-aging beauty. Let us be your face coach. It’s yours and it’s time to treat it right.  It’s time to build a skin care routine that will keep you looking flawless well past the age when you start lying about your age. Here we cut through the noise (and the B.S.) so that you know exactly which ingredients fit your current and future needs and which products will deliver results you can actually see. Challenge accepted!</em></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What is it?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">You know Vitamin C (aka </span><span style="font-weight: inherit; font-style: inherit;">L-ascorbic acid) </span><span style="font-weight: inherit; font-style: inherit;">- the trusty old antioxidant that’s been making an appearance in all of your cold remedies. Found in everything from oranges, to red peppers and broccoli, vitamin C is an essential part of your diet and plays a critical role in the development of collagen, which is responsible for skin’s strength and elasticity. Also a powerful antioxidant, Vitamin C theoretically combats oxidative stress (read: counteracts the harmful environmental and intrinsic factors we deal with on a daily basis).</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">How does it work?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Your skin already is loaded with Vitamin C, but it diminishes over time. Vitamin C serums applied topically can help replace some of what is lost naturally. Read: you’re just trying to get what’s already yours.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What does it treat?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Wrinkles and age spots, primarily. Vitamin C’s essential role in the production of collagen will help smooth fine lines and it’s antioxidant power can help combat damage done by the sun.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">When will I see results?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Results vary, but some users report seeing changes as early as 2-4 weeks into daily use, while others report seeing results within the 6-8 week window. Max results can be seen after 6 months.</span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"> </span></p>
<p style="color: #555f57;">Try a Vitamin C based serum first thing in the morning to capitalize on the antioxidant power while you are dealing with UV rays. The serum’s concentration will take environmental pollutants and potential sun damage to task.</p>
&nbsp;
<p style="color: #555f57;"><strong style="font-style: inherit;">Our Fave 5:</strong></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1rox2I6" target="_blank">Paula’s Choice C15 Super Booster</a>, $33.75</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/e0aac41dcf4eba392c6d3160b3cfb9a7/tumblr_inline_n94g6aUQGv1r9cmrh.png" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://amzn.to/1o5Nhc7" target="_blank">Obagi Professional-C Serum 20% Vitamin C Serum Facial Treatment Products</a>, $99</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/10ba60bdd5848cb897f94e18d59e47e3/tumblr_inline_n94genrwRj1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkO4p" target="_blank">Sarah McNamara Miracle Skin Transformer</a>, $46.40</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/80eeb2bc40eda6f8080e50c4d80bd893/tumblr_inline_n94gb37i2I1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkZNb" target="_blank">Dr. Dennis Gross Skincare Vitamin C Brightening Serum</a>, $95</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/c5fa94e90d65c9c20f33eb37406c6268/tumblr_inline_n94gc5nYHG1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1lqSerg" target="_blank">Clinique CX™ Antioxidant Rescue Serum</a>, $135</p>
&nbsp;
<p style="color: #555f57;">                 <img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/66591da288c57d07d1d775405af8f7a6/tumblr_inline_n94gd5vhmk1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;">Looking to try premium samples before buying? Join our waitlist and get notified about <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1naV743" target="_blank">PrettyTendr.com</a>.</p>
<span style="font-weight: inherit; font-style: inherit;"> </span>', 'SKINCARE AISLE DEMYSTIFIED: VITAMIN C WILL CHANGE YOUR FACE', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-07-29 16:25:45', '2014-07-29 16:25:45', '', 0, 'http://localhost:8888/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2014-05-26 22:33:13', '2014-05-26 22:33:13', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-05-26 22:33:13', '2014-05-26 22:33:13', '', 0, 'http://localhost:8888/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2014-06-04 17:13:32', '2014-06-04 17:13:32', '', 'Activity', '', 'publish', 'closed', 'closed', '', 'activity', '', '', '2014-06-04 17:13:32', '2014-06-04 17:13:32', '', 0, 'http://localhost:8888/?page_id=4', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2014-06-04 17:13:32', '2014-06-04 17:13:32', '', 'Members', '', 'publish', 'closed', 'closed', '', 'members', '', '', '2014-06-04 17:13:32', '2014-06-04 17:13:32', '', 0, 'http://localhost:8888/?page_id=5', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2014-06-04 17:13:40', '2014-06-04 17:13:40', '', 'Shop', '', 'publish', 'closed', 'open', '', 'shop', '', '', '2014-06-04 17:13:40', '2014-06-04 17:13:40', '', 0, 'http://localhost:8888/?page_id=6', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2014-06-04 17:13:40', '2014-06-04 17:13:40', '[woocommerce_cart]', 'Cart', '', 'publish', 'closed', 'open', '', 'cart', '', '', '2014-06-04 17:13:40', '2014-06-04 17:13:40', '', 0, 'http://localhost:8888/?page_id=7', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2014-06-04 17:13:40', '2014-06-04 17:13:40', '[woocommerce_checkout]', 'Checkout', '', 'publish', 'closed', 'open', '', 'checkout', '', '', '2014-06-04 17:13:40', '2014-06-04 17:13:40', '', 0, 'http://localhost:8888/?page_id=8', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2014-06-04 17:13:40', '2014-06-04 17:13:40', '[woocommerce_my_account]', 'My Account', '', 'publish', 'closed', 'open', '', 'my-account', '', '', '2014-06-04 17:13:40', '2014-06-04 17:13:40', '', 0, 'http://localhost:8888/?page_id=9', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2014-06-04 20:21:21', '2014-06-04 20:21:21', 'this is a static home page

<span style="color: #000000;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </span>

&nbsp;

<span style="color: #000000;">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span>', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-10-15 22:58:59', '2014-10-15 22:58:59', '', 0, 'http://localhost:8888/?page_id=10', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2014-06-04 20:21:21', '2014-06-04 20:21:21', 'This is the front page.', 'Home', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-06-04 20:21:21', '2014-06-04 20:21:21', '', 10, 'http://localhost:8888/?p=11', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2014-06-04 20:55:46', '2014-06-04 20:55:46', '', '2 girls on park bench', '', 'inherit', 'open', 'open', '', '2-girls-on-park-bench', '', '', '2014-06-04 20:55:46', '2014-06-04 20:55:46', '', 0, 'http://localhost:8888/wp-content/uploads/2014/06/2-girls-on-park-bench.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Logo', '', 'publish', 'open', 'open', '', 'woo-logo', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=woo-logo', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 'T_1_front.jpg', '', 'inherit', 'open', 'open', '', 't_1_front-jpg', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 86, 'http://localhost:8888/wp-content/uploads/2014/07/T_1_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2014-07-21 21:03:43', '2014-07-21 21:03:43', '', 'T_1_back.jpg', '', 'inherit', 'open', 'open', '', 't_1_back-jpg', '', '', '2014-07-21 21:03:43', '2014-07-21 21:03:43', '', 86, 'http://localhost:8888/wp-content/uploads/2014/07/T_1_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Premium Quality', '', 'publish', 'open', 'open', '', 'premium-quality', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=premium-quality', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2014-07-21 21:03:44', '2014-07-21 21:03:44', '', 'T_2_front.jpg', '', 'inherit', 'open', 'open', '', 't_2_front-jpg', '', '', '2014-07-21 21:03:44', '2014-07-21 21:03:44', '', 89, 'http://localhost:8888/wp-content/uploads/2014/07/T_2_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2014-07-21 21:03:44', '2014-07-21 21:03:44', '', 'T_2_back.jpg', '', 'inherit', 'open', 'open', '', 't_2_back-jpg', '', '', '2014-07-21 21:03:44', '2014-07-21 21:03:44', '', 89, 'http://localhost:8888/wp-content/uploads/2014/07/T_2_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Ship Your Idea', '', 'publish', 'open', 'open', '', 'ship-your-idea', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=ship-your-idea', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2014-07-21 21:03:45', '2014-07-21 21:03:45', '', 'T_4_front.jpg', '', 'inherit', 'open', 'open', '', 't_4_front-jpg', '', '', '2014-07-21 21:03:45', '2014-07-21 21:03:45', '', 92, 'http://localhost:8888/wp-content/uploads/2014/07/T_4_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2014-07-21 21:03:46', '2014-07-21 21:03:46', '', 'T_3_back.jpg', '', 'inherit', 'open', 'open', '', 't_3_back-jpg', '', '', '2014-07-21 21:03:46', '2014-07-21 21:03:46', '', 92, 'http://localhost:8888/wp-content/uploads/2014/07/T_3_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Ninja Silhouette', '', 'publish', 'open', 'open', '', 'ninja-silhouette', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=ninja-silhouette', 0, 'product', '', 1) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2014-07-21 21:03:46', '2014-07-21 21:03:46', '', 'T_5_front.jpg', '', 'inherit', 'open', 'open', '', 't_5_front-jpg', '', '', '2014-07-21 21:03:46', '2014-07-21 21:03:46', '', 95, 'http://localhost:8888/wp-content/uploads/2014/07/T_5_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2014-07-21 21:03:47', '2014-07-21 21:03:47', '', 'T_5_back.jpg', '', 'inherit', 'open', 'open', '', 't_5_back-jpg', '', '', '2014-07-21 21:03:47', '2014-07-21 21:03:47', '', 95, 'http://localhost:8888/wp-content/uploads/2014/07/T_5_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Ninja', '', 'publish', 'open', 'open', '', 'woo-ninja', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=woo-ninja', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2014-07-21 21:03:48', '2014-07-21 21:03:48', '', 'T_6_front.jpg', '', 'inherit', 'open', 'open', '', 't_6_front-jpg', '', '', '2014-07-21 21:03:48', '2014-07-21 21:03:48', '', 98, 'http://localhost:8888/wp-content/uploads/2014/07/T_6_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2014-07-21 21:03:48', '2014-07-21 21:03:48', '', 'T_6_back.jpg', '', 'inherit', 'open', 'open', '', 't_6_back-jpg', '', '', '2014-07-21 21:03:48', '2014-07-21 21:03:48', '', 98, 'http://localhost:8888/wp-content/uploads/2014/07/T_6_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Happy Ninja', '', 'publish', 'open', 'open', '', 'happy-ninja', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=happy-ninja', 0, 'product', '', 1) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2014-07-21 21:03:49', '2014-07-21 21:03:49', '', 'T_7_front.jpg', '', 'inherit', 'open', 'open', '', 't_7_front-jpg', '', '', '2014-07-21 21:03:49', '2014-07-21 21:03:49', '', 101, 'http://localhost:8888/wp-content/uploads/2014/07/T_7_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2014-07-21 21:03:50', '2014-07-21 21:03:50', '', 'T_7_back.jpg', '', 'inherit', 'open', 'open', '', 't_7_back-jpg', '', '', '2014-07-21 21:03:50', '2014-07-21 21:03:50', '', 101, 'http://localhost:8888/wp-content/uploads/2014/07/T_7_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Ship Your Idea', '', 'publish', 'open', 'open', '', 'ship-your-idea-2', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=ship-your-idea-2', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2014-07-21 21:03:51', '2014-07-21 21:03:51', '', 'hoodie_7_front.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_7_front-jpg', '', '', '2014-07-21 21:03:51', '2014-07-21 21:03:51', '', 104, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_7_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2014-07-21 21:03:51', '2014-07-21 21:03:51', '', 'hoodie_7_back.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_7_back-jpg', '', '', '2014-07-21 21:03:51', '2014-07-21 21:03:51', '', 104, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_7_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (107, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Ninja', '', 'publish', 'open', 'open', '', 'woo-ninja-2', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=woo-ninja-2', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (108, 1, '2014-07-21 21:03:52', '2014-07-21 21:03:52', '', 'hoodie_2_front.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_2_front-jpg', '', '', '2014-07-21 21:03:52', '2014-07-21 21:03:52', '', 107, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_2_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (109, 1, '2014-07-21 21:03:53', '2014-07-21 21:03:53', '', 'hoodie_2_back.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_2_back-jpg', '', '', '2014-07-21 21:03:53', '2014-07-21 21:03:53', '', 107, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_2_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (110, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Patient Ninja', '', 'publish', 'open', 'open', '', 'patient-ninja', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=patient-ninja', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (111, 1, '2014-07-21 21:03:54', '2014-07-21 21:03:54', '', 'hoodie_3_front.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_3_front-jpg', '', '', '2014-07-21 21:03:54', '2014-07-21 21:03:54', '', 110, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_3_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (112, 1, '2014-07-21 21:03:54', '2014-07-21 21:03:54', '', 'hoodie_3_back.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_3_back-jpg', '', '', '2014-07-21 21:03:54', '2014-07-21 21:03:54', '', 110, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_3_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (113, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Happy Ninja', '', 'publish', 'open', 'open', '', 'happy-ninja-2', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=happy-ninja-2', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2014-07-21 21:03:55', '2014-07-21 21:03:55', '', 'hoodie_4_front.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_4_front-jpg', '', '', '2014-07-21 21:03:55', '2014-07-21 21:03:55', '', 113, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_4_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2014-07-21 21:03:56', '2014-07-21 21:03:56', '', 'hoodie_4_back.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_4_back-jpg', '', '', '2014-07-21 21:03:56', '2014-07-21 21:03:56', '', 113, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_4_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Ninja Silhouette', '', 'publish', 'open', 'open', '', 'ninja-silhouette-2', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=ninja-silhouette-2', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2014-07-21 21:03:57', '2014-07-21 21:03:57', '', 'hoodie_5_front.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_5_front-jpg', '', '', '2014-07-21 21:03:57', '2014-07-21 21:03:57', '', 116, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_5_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (118, 1, '2014-07-21 21:03:57', '2014-07-21 21:03:57', '', 'hoodie_5_back.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_5_back-jpg', '', '', '2014-07-21 21:03:57', '2014-07-21 21:03:57', '', 116, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_5_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Logo', '', 'publish', 'open', 'open', '', 'woo-logo-2', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=woo-logo-2', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (120, 1, '2014-07-21 21:03:58', '2014-07-21 21:03:58', '', 'hoodie_6_front.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_6_front-jpg', '', '', '2014-07-21 21:03:58', '2014-07-21 21:03:58', '', 119, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_6_front.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2014-07-21 21:03:59', '2014-07-21 21:03:59', '', 'hoodie_6_back.jpg', '', 'inherit', 'open', 'open', '', 'hoodie_6_back-jpg', '', '', '2014-07-21 21:03:59', '2014-07-21 21:03:59', '', 119, 'http://localhost:8888/wp-content/uploads/2014/07/hoodie_6_back.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo CAN YI SEE ME?.', 'Ship Your Idea', '', 'publish', 'open', 'closed', '', 'ship-your-idea-3', '', '', '2014-09-28 21:15:54', '2014-09-28 21:15:54', '', 0, 'http://localhost:8888/?product=ship-your-idea-3', 0, 'product', '', 4) ; 
INSERT INTO `wp_posts` VALUES (123, 1, '2014-07-21 21:04:00', '2014-07-21 21:04:00', '', 'poster_1_up.jpg', '', 'inherit', 'open', 'open', '', 'poster_1_up-jpg', '', '', '2014-07-21 21:04:00', '2014-07-21 21:04:00', '', 122, 'http://localhost:8888/wp-content/uploads/2014/07/poster_1_up.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (124, 1, '2014-07-21 21:04:00', '2014-07-21 21:04:00', '', 'Poster_1_flat.jpg', '', 'inherit', 'open', 'open', '', 'poster_1_flat-jpg', '', '', '2014-07-21 21:04:00', '2014-07-21 21:04:00', '', 122, 'http://localhost:8888/wp-content/uploads/2014/07/Poster_1_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (125, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Flying Ninja', '', 'publish', 'open', 'open', '', 'flying-ninja', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=flying-ninja', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (126, 1, '2014-07-21 21:04:01', '2014-07-21 21:04:01', '', 'poster_2_up.jpg', '', 'inherit', 'open', 'open', '', 'poster_2_up-jpg', '', '', '2014-07-21 21:04:01', '2014-07-21 21:04:01', '', 125, 'http://localhost:8888/wp-content/uploads/2014/07/poster_2_up.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (127, 1, '2014-07-21 21:04:02', '2014-07-21 21:04:02', '', 'Poster_2_flat.jpg', '', 'inherit', 'open', 'open', '', 'poster_2_flat-jpg', '', '', '2014-07-21 21:04:02', '2014-07-21 21:04:02', '', 125, 'http://localhost:8888/wp-content/uploads/2014/07/Poster_2_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (128, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Premium Quality', '', 'publish', 'open', 'open', '', 'premium-quality-2', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=premium-quality-2', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (129, 1, '2014-07-21 21:04:02', '2014-07-21 21:04:02', '', 'poster_3_up.jpg', '', 'inherit', 'open', 'open', '', 'poster_3_up-jpg', '', '', '2014-07-21 21:04:02', '2014-07-21 21:04:02', '', 128, 'http://localhost:8888/wp-content/uploads/2014/07/poster_3_up.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (130, 1, '2014-07-21 21:04:03', '2014-07-21 21:04:03', '', 'Poster_3_flat.jpg', '', 'inherit', 'open', 'open', '', 'poster_3_flat-jpg', '', '', '2014-07-21 21:04:03', '2014-07-21 21:04:03', '', 128, 'http://localhost:8888/wp-content/uploads/2014/07/Poster_3_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (131, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Ninja', '', 'publish', 'open', 'open', '', 'woo-ninja-3', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=woo-ninja-3', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (132, 1, '2014-07-21 21:04:04', '2014-07-21 21:04:04', '', 'poster_4_up.jpg', '', 'inherit', 'open', 'open', '', 'poster_4_up-jpg', '', '', '2014-07-21 21:04:04', '2014-07-21 21:04:04', '', 131, 'http://localhost:8888/wp-content/uploads/2014/07/poster_4_up.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (133, 1, '2014-07-21 21:04:04', '2014-07-21 21:04:04', '', 'Poster_4_flat.jpg', '', 'inherit', 'open', 'open', '', 'poster_4_flat-jpg', '', '', '2014-07-21 21:04:04', '2014-07-21 21:04:04', '', 131, 'http://localhost:8888/wp-content/uploads/2014/07/Poster_4_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (134, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Logo', '', 'publish', 'open', 'open', '', 'woo-logo-3', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=woo-logo-3', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (135, 1, '2014-07-21 21:04:05', '2014-07-21 21:04:05', '', 'poster_5_up.jpg', '', 'inherit', 'open', 'open', '', 'poster_5_up-jpg', '', '', '2014-07-21 21:04:05', '2014-07-21 21:04:05', '', 134, 'http://localhost:8888/wp-content/uploads/2014/07/poster_5_up.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (136, 1, '2014-07-21 21:04:05', '2014-07-21 21:04:05', '', 'Poster_5_flat.jpg', '', 'inherit', 'open', 'open', '', 'poster_5_flat-jpg', '', '', '2014-07-21 21:04:05', '2014-07-21 21:04:05', '', 134, 'http://localhost:8888/wp-content/uploads/2014/07/Poster_5_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (137, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Album #1', '', 'publish', 'open', 'open', '', 'woo-album-1', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=woo-album-1', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (138, 1, '2014-07-21 21:04:06', '2014-07-21 21:04:06', '', 'cd_1_angle.jpg', '', 'inherit', 'open', 'open', '', 'cd_1_angle-jpg', '', '', '2014-07-21 21:04:06', '2014-07-21 21:04:06', '', 137, 'http://localhost:8888/wp-content/uploads/2014/07/cd_1_angle.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (139, 1, '2014-07-21 21:04:07', '2014-07-21 21:04:07', '', 'cd_1_flat.jpg', '', 'inherit', 'open', 'open', '', 'cd_1_flat-jpg', '', '', '2014-07-21 21:04:07', '2014-07-21 21:04:07', '', 137, 'http://localhost:8888/wp-content/uploads/2014/07/cd_1_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (140, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Album #2', '', 'publish', 'open', 'open', '', 'woo-album-2', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=woo-album-2', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (141, 1, '2014-07-21 21:04:08', '2014-07-21 21:04:08', '', 'cd_2_angle.jpg', '', 'inherit', 'open', 'open', '', 'cd_2_angle-jpg', '', '', '2014-07-21 21:04:08', '2014-07-21 21:04:08', '', 140, 'http://localhost:8888/wp-content/uploads/2014/07/cd_2_angle.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (142, 1, '2014-07-21 21:04:08', '2014-07-21 21:04:08', '', 'cd_2_flat.jpg', '', 'inherit', 'open', 'open', '', 'cd_2_flat-jpg', '', '', '2014-07-21 21:04:08', '2014-07-21 21:04:08', '', 140, 'http://localhost:8888/wp-content/uploads/2014/07/cd_2_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (143, 1, '2014-07-21 21:03:42', '2014-07-21 21:03:42', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Album #3', '', 'publish', 'open', 'open', '', 'woo-album-3', '', '', '2014-07-21 21:03:42', '2014-07-21 21:03:42', '', 0, 'http://localhost:8888/?product=woo-album-3', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (144, 1, '2014-07-21 21:04:09', '2014-07-21 21:04:09', '', 'cd_3_angle.jpg', '', 'inherit', 'open', 'open', '', 'cd_3_angle-jpg', '', '', '2014-07-21 21:04:09', '2014-07-21 21:04:09', '', 143, 'http://localhost:8888/wp-content/uploads/2014/07/cd_3_angle.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (145, 1, '2014-07-21 21:04:10', '2014-07-21 21:04:10', '', 'cd_3_flat.jpg', '', 'inherit', 'open', 'open', '', 'cd_3_flat-jpg', '', '', '2014-07-21 21:04:10', '2014-07-21 21:04:10', '', 143, 'http://localhost:8888/wp-content/uploads/2014/07/cd_3_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (146, 1, '2014-07-21 21:04:11', '2014-07-21 21:04:11', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Single #1', '', 'publish', 'open', 'closed', '', 'woo-single-1', '', '', '2014-07-29 16:17:16', '2014-07-29 16:17:16', '', 0, 'http://localhost:8888/?product=woo-single-1', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (147, 1, '2014-07-21 21:04:11', '2014-07-21 21:04:11', '', 'cd_4_angle.jpg', '', 'inherit', 'open', 'open', '', 'cd_4_angle-jpg', '', '', '2014-07-21 21:04:11', '2014-07-21 21:04:11', '', 146, 'http://localhost:8888/wp-content/uploads/2014/07/cd_4_angle.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (148, 1, '2014-07-21 21:04:12', '2014-07-21 21:04:12', '', 'cd_4_flat.jpg', '', 'inherit', 'open', 'open', '', 'cd_4_flat-jpg', '', '', '2014-07-21 21:04:12', '2014-07-21 21:04:12', '', 146, 'http://localhost:8888/wp-content/uploads/2014/07/cd_4_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (149, 1, '2014-07-21 21:04:11', '2014-07-21 21:04:11', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Album #4', '', 'publish', 'open', 'open', '', 'woo-album-4', '', '', '2014-07-21 21:04:11', '2014-07-21 21:04:11', '', 0, 'http://localhost:8888/?product=woo-album-4', 0, 'product', '', 0) ; 
INSERT INTO `wp_posts` VALUES (150, 1, '2014-07-21 21:04:13', '2014-07-21 21:04:13', '', 'cd_5_angle.jpg', '', 'inherit', 'open', 'open', '', 'cd_5_angle-jpg', '', '', '2014-07-21 21:04:13', '2014-07-21 21:04:13', '', 149, 'http://localhost:8888/wp-content/uploads/2014/07/cd_5_angle.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (151, 1, '2014-07-21 21:04:13', '2014-07-21 21:04:13', '', 'cd_5_flat.jpg', '', 'inherit', 'open', 'open', '', 'cd_5_flat-jpg', '', '', '2014-07-21 21:04:13', '2014-07-21 21:04:13', '', 149, 'http://localhost:8888/wp-content/uploads/2014/07/cd_5_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (152, 1, '2014-07-21 21:04:11', '2014-07-21 21:04:11', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Woo Single #2', '', 'publish', 'open', 'open', '', 'woo-single-2', '', '', '2014-07-21 21:04:11', '2014-07-21 21:04:11', '', 0, 'http://localhost:8888/?product=woo-single-2', 0, 'product', '', 4) ; 
INSERT INTO `wp_posts` VALUES (153, 1, '2014-07-21 21:04:16', '2014-07-21 21:04:16', '', 'cd_6_angle.jpg', '', 'inherit', 'open', 'open', '', 'cd_6_angle-jpg', '', '', '2014-07-21 21:04:16', '2014-07-21 21:04:16', '', 152, 'http://localhost:8888/wp-content/uploads/2014/07/cd_6_angle.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (154, 1, '2014-07-21 21:04:16', '2014-07-21 21:04:16', '', 'cd_6_flat.jpg', '', 'inherit', 'open', 'open', '', 'cd_6_flat-jpg', '', '', '2014-07-21 21:04:16', '2014-07-21 21:04:16', '', 152, 'http://localhost:8888/wp-content/uploads/2014/07/cd_6_flat.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (155, 1, '2014-07-21 22:19:29', '2014-07-21 22:19:29', '<h1>Checkout</h1>

{{mj-checkout-form}}', 'Mijireh Secure Checkout', '', 'private', 'closed', 'closed', '', 'mijireh-secure-checkout', '', '', '2014-07-21 22:19:29', '2014-07-21 22:19:29', '', 0, 'http://localhost:8888/?page_id=155', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (157, 1, '2014-07-29 16:24:05', '2014-07-29 16:24:05', '<p style="color: #555f57;"><em style="font-weight: inherit;"><a href="http://localhost:8888/wp-content/uploads/2014/05/twin_skincare.jpg"><img class="alignnone size-full wp-image-159" src="http://localhost:8888/wp-content/uploads/2014/05/twin_skincare.jpg" alt="Vionnet Backstage at Paris Fashion Week Spring Summer 2013 Collections" width="500" height="326" /></a>What is Vitamin C?</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">Aging is something of a four-letter word in the beauty business (er, we suppose it’s more like five letters). While completely unavoidable and totally natural, it still strikes fear in the hearts of even the genetically blessed. This leaves us with two options:</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">1. Freak the eff out.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">-or-</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">2. Accept the inevitable, get your game face on, and tackle this aging business with a modicum of grace.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">If you’ve chosen option 1, we can’t with you right now. If you’re in the mood to try door #2, we’re pleased to help you navigate the wealthy, but often overwhelming world of anti-aging beauty. Let us be your face coach. It’s yours and it’s time to treat it right.  It’s time to build a skin care routine that will keep you looking flawless well past the age when you start lying about your age. Here we cut through the noise (and the B.S.) so that you know exactly which ingredients fit your current and future needs and which products will deliver results you can actually see. Challenge accepted!</em></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What is it?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">You know Vitamin C (aka </span><span style="font-weight: inherit; font-style: inherit;">L-ascorbic acid) </span><span style="font-weight: inherit; font-style: inherit;">- the trusty old antioxidant that’s been making an appearance in all of your cold remedies. Found in everything from oranges, to red peppers and broccoli, vitamin C is an essential part of your diet and plays a critical role in the development of collagen, which is responsible for skin’s strength and elasticity. Also a powerful antioxidant, Vitamin C theoretically combats oxidative stress (read: counteracts the harmful environmental and intrinsic factors we deal with on a daily basis).</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">How does it work?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Your skin already is loaded with Vitamin C, but it diminishes over time. Vitamin C serums applied topically can help replace some of what is lost naturally. Read: you’re just trying to get what’s already yours.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What does it treat?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Wrinkles and age spots, primarily. Vitamin C’s essential role in the production of collagen will help smooth fine lines and it’s antioxidant power can help combat damage done by the sun.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">When will I see results?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Results vary, but some users report seeing changes as early as 2-4 weeks into daily use, while others report seeing results within the 6-8 week window. Max results can be seen after 6 months.</span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"> </span></p>
<p style="color: #555f57;">Try a Vitamin C based serum first thing in the morning to capitalize on the antioxidant power while you are dealing with UV rays. The serum’s concentration will take environmental pollutants and potential sun damage to task.</p>
&nbsp;
<p style="color: #555f57;"><strong style="font-style: inherit;">Our Fave 5:</strong></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1rox2I6" target="_blank">Paula’s Choice C15 Super Booster</a>, $33.75</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/e0aac41dcf4eba392c6d3160b3cfb9a7/tumblr_inline_n94g6aUQGv1r9cmrh.png" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://amzn.to/1o5Nhc7" target="_blank">Obagi Professional-C Serum 20% Vitamin C Serum Facial Treatment Products</a>, $99</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/10ba60bdd5848cb897f94e18d59e47e3/tumblr_inline_n94genrwRj1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkO4p" target="_blank">Sarah McNamara Miracle Skin Transformer</a>, $46.40</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/80eeb2bc40eda6f8080e50c4d80bd893/tumblr_inline_n94gb37i2I1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkZNb" target="_blank">Dr. Dennis Gross Skincare Vitamin C Brightening Serum</a>, $95</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/c5fa94e90d65c9c20f33eb37406c6268/tumblr_inline_n94gc5nYHG1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1lqSerg" target="_blank">Clinique CX™ Antioxidant Rescue Serum</a>, $135</p>
&nbsp;
<p style="color: #555f57;">                 <img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/66591da288c57d07d1d775405af8f7a6/tumblr_inline_n94gd5vhmk1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;">Looking to try premium samples before buying? Join our waitlist and get notified about <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1naV743" target="_blank">PrettyTendr.com</a>.</p>
<span style="font-weight: inherit; font-style: inherit;"> </span>', 'SKINCARE AISLE DEMYSTIFIED: VITAMIN C WILL CHANGE YOUR FACE', '', 'inherit', 'open', 'open', '', '1-autosave-v1', '', '', '2014-07-29 16:24:05', '2014-07-29 16:24:05', '', 1, 'http://localhost:8888/2014/07/29/1-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (158, 1, '2014-07-29 16:23:01', '2014-07-29 16:23:01', '<p style="color: #555f57;"><em style="font-weight: inherit;">What is Vitamin C?</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">Aging is something of a four-letter word in the beauty business (er, we suppose it’s more like five letters). While completely unavoidable and totally natural, it still strikes fear in the hearts of even the genetically blessed. This leaves us with two options:</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">1. Freak the eff out.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">-or-</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">2. Accept the inevitable, get your game face on, and tackle this aging business with a modicum of grace.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">If you’ve chosen option 1, we can’t with you right now. If you’re in the mood to try door #2, we’re pleased to help you navigate the wealthy, but often overwhelming world of anti-aging beauty. Let us be your face coach. It’s yours and it’s time to treat it right.  It’s time to build a skin care routine that will keep you looking flawless well past the age when you start lying about your age. Here we cut through the noise (and the B.S.) so that you know exactly which ingredients fit your current and future needs and which products will deliver results you can actually see. Challenge accepted!</em></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What is it?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">You know Vitamin C (aka </span><span style="font-weight: inherit; font-style: inherit;">L-ascorbic acid) </span><span style="font-weight: inherit; font-style: inherit;">- the trusty old antioxidant that’s been making an appearance in all of your cold remedies. Found in everything from oranges, to red peppers and broccoli, vitamin C is an essential part of your diet and plays a critical role in the development of collagen, which is responsible for skin’s strength and elasticity. Also a powerful antioxidant, Vitamin C theoretically combats oxidative stress (read: counteracts the harmful environmental and intrinsic factors we deal with on a daily basis).</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">How does it work?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Your skin already is loaded with Vitamin C, but it diminishes over time. Vitamin C serums applied topically can help replace some of what is lost naturally. Read: you’re just trying to get what’s already yours.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What does it treat?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Wrinkles and age spots, primarily. Vitamin C’s essential role in the production of collagen will help smooth fine lines and it’s antioxidant power can help combat damage done by the sun.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">When will I see results?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Results vary, but some users report seeing changes as early as 2-4 weeks into daily use, while others report seeing results within the 6-8 week window. Max results can be seen after 6 months.</span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"> </span></p>
<p style="color: #555f57;">Try a Vitamin C based serum first thing in the morning to capitalize on the antioxidant power while you are dealing with UV rays. The serum’s concentration will take environmental pollutants and potential sun damage to task.</p>
&nbsp;
<p style="color: #555f57;"><strong style="font-style: inherit;">Our Fave 5:</strong></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1rox2I6" target="_blank">Paula’s Choice C15 Super Booster</a>, $33.75</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/e0aac41dcf4eba392c6d3160b3cfb9a7/tumblr_inline_n94g6aUQGv1r9cmrh.png" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://amzn.to/1o5Nhc7" target="_blank">Obagi Professional-C Serum 20% Vitamin C Serum Facial Treatment Products</a>, $99</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/10ba60bdd5848cb897f94e18d59e47e3/tumblr_inline_n94genrwRj1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkO4p" target="_blank">Sarah McNamara Miracle Skin Transformer</a>, $46.40</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/80eeb2bc40eda6f8080e50c4d80bd893/tumblr_inline_n94gb37i2I1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkZNb" target="_blank">Dr. Dennis Gross Skincare Vitamin C Brightening Serum</a>, $95</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/c5fa94e90d65c9c20f33eb37406c6268/tumblr_inline_n94gc5nYHG1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1lqSerg" target="_blank">Clinique CX™ Antioxidant Rescue Serum</a>, $135</p>
&nbsp;
<p style="color: #555f57;">                 <img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/66591da288c57d07d1d775405af8f7a6/tumblr_inline_n94gd5vhmk1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;">Looking to try premium samples before buying? Join our waitlist and get notified about <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1naV743" target="_blank">PrettyTendr.com</a>.</p>
<span style="font-weight: inherit; font-style: inherit;"> </span>', 'SKINCARE AISLE DEMYSTIFIED: VITAMIN C WILL CHANGE YOUR FACE', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-07-29 16:23:01', '2014-07-29 16:23:01', '', 1, 'http://localhost:8888/2014/07/29/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (159, 1, '2014-07-29 16:23:13', '2014-07-29 16:23:13', '', 'Vionnet Backstage at Paris Fashion Week Spring Summer 2013 Collections', '', 'inherit', 'open', 'open', '', 'vionnet-backstage-at-paris-fashion-week-spring-summer-2013-collections', '', '', '2014-07-29 16:23:13', '2014-07-29 16:23:13', '', 1, 'http://localhost:8888/wp-content/uploads/2014/05/twin_skincare.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (160, 1, '2014-07-29 16:24:54', '2014-07-29 16:24:54', '<p style="color: #555f57;"><em style="font-weight: inherit;"><a href="http://localhost:8888/wp-content/uploads/2014/05/twin_skincare.jpg"><img class="alignnone size-full wp-image-159" src="http://localhost:8888/wp-content/uploads/2014/05/twin_skincare.jpg" alt="Vionnet Backstage at Paris Fashion Week Spring Summer 2013 Collections" width="500" height="326" /></a>What is Vitamin C?</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">Aging is something of a four-letter word in the beauty business (er, we suppose it’s more like five letters). While completely unavoidable and totally natural, it still strikes fear in the hearts of even the genetically blessed. This leaves us with two options:</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">1. Freak the eff out.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">-or-</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">2. Accept the inevitable, get your game face on, and tackle this aging business with a modicum of grace.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">If you’ve chosen option 1, we can’t with you right now. If you’re in the mood to try door #2, we’re pleased to help you navigate the wealthy, but often overwhelming world of anti-aging beauty. Let us be your face coach. It’s yours and it’s time to treat it right.  It’s time to build a skin care routine that will keep you looking flawless well past the age when you start lying about your age. Here we cut through the noise (and the B.S.) so that you know exactly which ingredients fit your current and future needs and which products will deliver results you can actually see. Challenge accepted!</em></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What is it?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">You know Vitamin C (aka </span><span style="font-weight: inherit; font-style: inherit;">L-ascorbic acid) </span><span style="font-weight: inherit; font-style: inherit;">- the trusty old antioxidant that’s been making an appearance in all of your cold remedies. Found in everything from oranges, to red peppers and broccoli, vitamin C is an essential part of your diet and plays a critical role in the development of collagen, which is responsible for skin’s strength and elasticity. Also a powerful antioxidant, Vitamin C theoretically combats oxidative stress (read: counteracts the harmful environmental and intrinsic factors we deal with on a daily basis).</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">How does it work?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Your skin already is loaded with Vitamin C, but it diminishes over time. Vitamin C serums applied topically can help replace some of what is lost naturally. Read: you’re just trying to get what’s already yours.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What does it treat?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Wrinkles and age spots, primarily. Vitamin C’s essential role in the production of collagen will help smooth fine lines and it’s antioxidant power can help combat damage done by the sun.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">When will I see results?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Results vary, but some users report seeing changes as early as 2-4 weeks into daily use, while others report seeing results within the 6-8 week window. Max results can be seen after 6 months.</span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"> </span></p>
<p style="color: #555f57;">Try a Vitamin C based serum first thing in the morning to capitalize on the antioxidant power while you are dealing with UV rays. The serum’s concentration will take environmental pollutants and potential sun damage to task.</p>
&nbsp;
<p style="color: #555f57;"><strong style="font-style: inherit;">Our Fave 5:</strong></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1rox2I6" target="_blank">Paula’s Choice C15 Super Booster</a>, $33.75</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/e0aac41dcf4eba392c6d3160b3cfb9a7/tumblr_inline_n94g6aUQGv1r9cmrh.png" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://amzn.to/1o5Nhc7" target="_blank">Obagi Professional-C Serum 20% Vitamin C Serum Facial Treatment Products</a>, $99</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/10ba60bdd5848cb897f94e18d59e47e3/tumblr_inline_n94genrwRj1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkO4p" target="_blank">Sarah McNamara Miracle Skin Transformer</a>, $46.40</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/80eeb2bc40eda6f8080e50c4d80bd893/tumblr_inline_n94gb37i2I1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkZNb" target="_blank">Dr. Dennis Gross Skincare Vitamin C Brightening Serum</a>, $95</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/c5fa94e90d65c9c20f33eb37406c6268/tumblr_inline_n94gc5nYHG1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1lqSerg" target="_blank">Clinique CX™ Antioxidant Rescue Serum</a>, $135</p>
&nbsp;
<p style="color: #555f57;">                 <img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/66591da288c57d07d1d775405af8f7a6/tumblr_inline_n94gd5vhmk1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;">Looking to try premium samples before buying? Join our waitlist and get notified about <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1naV743" target="_blank">PrettyTendr.com</a>.</p>
<span style="font-weight: inherit; font-style: inherit;"> </span>', 'SKINCARE AISLE DEMYSTIFIED: VITAMIN C WILL CHANGE YOUR FACE', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-07-29 16:24:54', '2014-07-29 16:24:54', '', 1, 'http://localhost:8888/2014/07/29/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (161, 1, '2014-07-29 16:25:34', '2014-07-29 16:25:34', '<p style="color: #555f57;"><em style="font-weight: inherit;">What is Vitamin C?</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">Aging is something of a four-letter word in the beauty business (er, we suppose it’s more like five letters). While completely unavoidable and totally natural, it still strikes fear in the hearts of even the genetically blessed. This leaves us with two options:</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">1. Freak the eff out.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">-or-</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">2. Accept the inevitable, get your game face on, and tackle this aging business with a modicum of grace.</em></p>
<p style="color: #555f57;"><em style="font-weight: inherit;">If you’ve chosen option 1, we can’t with you right now. If you’re in the mood to try door #2, we’re pleased to help you navigate the wealthy, but often overwhelming world of anti-aging beauty. Let us be your face coach. It’s yours and it’s time to treat it right.  It’s time to build a skin care routine that will keep you looking flawless well past the age when you start lying about your age. Here we cut through the noise (and the B.S.) so that you know exactly which ingredients fit your current and future needs and which products will deliver results you can actually see. Challenge accepted!</em></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What is it?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">You know Vitamin C (aka </span><span style="font-weight: inherit; font-style: inherit;">L-ascorbic acid) </span><span style="font-weight: inherit; font-style: inherit;">- the trusty old antioxidant that’s been making an appearance in all of your cold remedies. Found in everything from oranges, to red peppers and broccoli, vitamin C is an essential part of your diet and plays a critical role in the development of collagen, which is responsible for skin’s strength and elasticity. Also a powerful antioxidant, Vitamin C theoretically combats oxidative stress (read: counteracts the harmful environmental and intrinsic factors we deal with on a daily basis).</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">How does it work?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Your skin already is loaded with Vitamin C, but it diminishes over time. Vitamin C serums applied topically can help replace some of what is lost naturally. Read: you’re just trying to get what’s already yours.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">What does it treat?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Wrinkles and age spots, primarily. Vitamin C’s essential role in the production of collagen will help smooth fine lines and it’s antioxidant power can help combat damage done by the sun.</span></p>
<p style="color: #555f57;"><strong style="font-style: inherit;">When will I see results?</strong></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Results vary, but some users report seeing changes as early as 2-4 weeks into daily use, while others report seeing results within the 6-8 week window. Max results can be seen after 6 months.</span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"> </span></p>
<p style="color: #555f57;">Try a Vitamin C based serum first thing in the morning to capitalize on the antioxidant power while you are dealing with UV rays. The serum’s concentration will take environmental pollutants and potential sun damage to task.</p>
&nbsp;
<p style="color: #555f57;"><strong style="font-style: inherit;">Our Fave 5:</strong></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1rox2I6" target="_blank">Paula’s Choice C15 Super Booster</a>, $33.75</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/e0aac41dcf4eba392c6d3160b3cfb9a7/tumblr_inline_n94g6aUQGv1r9cmrh.png" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://amzn.to/1o5Nhc7" target="_blank">Obagi Professional-C Serum 20% Vitamin C Serum Facial Treatment Products</a>, $99</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/10ba60bdd5848cb897f94e18d59e47e3/tumblr_inline_n94genrwRj1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkO4p" target="_blank">Sarah McNamara Miracle Skin Transformer</a>, $46.40</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/80eeb2bc40eda6f8080e50c4d80bd893/tumblr_inline_n94gb37i2I1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/WxkZNb" target="_blank">Dr. Dennis Gross Skincare Vitamin C Brightening Serum</a>, $95</p>
&nbsp;
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/c5fa94e90d65c9c20f33eb37406c6268/tumblr_inline_n94gc5nYHG1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;"><a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1lqSerg" target="_blank">Clinique CX™ Antioxidant Rescue Serum</a>, $135</p>
&nbsp;
<p style="color: #555f57;">                 <img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/66591da288c57d07d1d775405af8f7a6/tumblr_inline_n94gd5vhmk1r9cmrh.jpg" alt="image" /></p>
&nbsp;
<p style="color: #555f57;">Looking to try premium samples before buying? Join our waitlist and get notified about <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://bit.ly/1naV743" target="_blank">PrettyTendr.com</a>.</p>
<span style="font-weight: inherit; font-style: inherit;"> </span>', 'SKINCARE AISLE DEMYSTIFIED: VITAMIN C WILL CHANGE YOUR FACE', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-07-29 16:25:34', '2014-07-29 16:25:34', '', 1, 'http://localhost:8888/2014/07/29/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (162, 1, '2014-07-29 16:28:03', '2014-07-29 16:28:03', '<p style="color: #555f57;"><em style="font-weight: inherit;">It’s beyond official that summer has finally arrived. This leaves us with a long list of pros and cons. On the one hand, looking forward to endless days filled with barbecues, beach hangouts, and sunning ourselves by the pool is enough to make a girl downright euphoric. On the other, beauty related complications will arise. From sweat-proofing your makeup routine and to post pool hair TLC, we’ve got you covered. In this series we tackle the elements and give you the tools to defeat them so you can maintain that effortless cool look without missing a beat.</em></p>
<p style="color: #555f57;">While we are thrilled that beach (or pool if you’re into that) season is in full swing - almost like we were mermaids in another life - our hair just isn’t. From chlorine doing its very best to cause damage to the seemingly endless detangling that happens post ocean swim, it’s clear that swimming and cute summer hair styles don’t really want to be friends. But before you decide to relegate yourself to only lounging or worse - wearing a swim cap - try out our pre-swim prep. With a little elbow grease (read: hair conditioning mask or leave-in conditioner) and a some advanced notice, you can prep your hair for basically any water related occasion.</p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">The pool is out to destroy your hair on two planes. The first is that the same chemicals keeping the pool clean and are absorbed by your hair the second you head under water. The same goes for salt water. But this can be hacked. Soaking your hair before heading into the pool fills the cuticle and prevents your hair from taking on any additional water filled with harsh chemicals. In a pinch that means running to the poolside shower before jumping in. If you have the time and beach bag space, bringing your own water treated with a hair conditioning mask or leave in conditioner will leave your hair enviably soft.</span></p>
<p style="color: #555f57;">Try adding <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod4450609" target="_blank">WELLA Enrich Moisturizing Treatment For Coarse Hair</a> to a bottle of water and douse right before heading in.</p>
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/7dd7c6e360e47210a5a804c478628859/tumblr_inline_n85p12pWbD1r9cmrh.jpg" alt="" /></p>
<p style="color: #555f57;">The second issue is that hair can’t wait to tangle when water is involved. For our straight haired friends this is less of an issue, but for anyone with more than a whisper of a curl prevention is key. A couple of easy braids, a simple bun, or well placed flat twists are protective styles that will make any post water detangling a cinch.</p>


[caption id="attachment_172" align="alignnone" width="500"]<a href="http://localhost:8888/wp-content/uploads/2014/07/nail4.jpg"><img class="size-full wp-image-172" src="http://localhost:8888/wp-content/uploads/2014/07/nail4.jpg" alt="Too cool for school orange is the color we are loving for June.  To the left: @maybelline Color Show in Neutral Statement and Orange Fix (chevron) (both $3.99)  To the right: @maybelline Color Show Pretty in Peach ($3.99) (@juliamurphree)" width="500" height="250" /></a> Too cool for school orange is the color we are loving for June. To the left: @maybelline Color Show in Neutral Statement and Orange Fix (chevron) (both $3.99) To the right: @maybelline Color Show Pretty in Peach ($3.99) (@juliamurphree)[/caption]', 'HAIR PREP FOR THE BEACH AND POOL', '', 'publish', 'open', 'open', '', 'hair-prep-for-the-beach-and-pool', '', '', '2014-08-27 23:15:25', '2014-08-27 23:15:25', '', 0, 'http://localhost:8888/?p=162', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (163, 1, '2014-07-29 16:27:30', '2014-07-29 16:27:30', '', 'pooljump', '', 'inherit', 'open', 'open', '', 'pooljump', '', '', '2014-07-29 16:27:30', '2014-07-29 16:27:30', '', 162, 'http://localhost:8888/wp-content/uploads/2014/07/pooljump.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (164, 1, '2014-07-29 16:28:03', '2014-07-29 16:28:03', '<p style="color: #555f57;"><em style="font-weight: inherit;">It’s beyond official that summer has finally arrived. This leaves us with a long list of pros and cons. On the one hand, looking forward to endless days filled with barbecues, beach hangouts, and sunning ourselves by the pool is enough to make a girl downright euphoric. On the other, beauty related complications will arise. From sweat-proofing your makeup routine and to post pool hair TLC, we’ve got you covered. In this series we tackle the elements and give you the tools to defeat them so you can maintain that effortless cool look without missing a beat.</em></p>
<p style="color: #555f57;">While we are thrilled that beach (or pool if you’re into that) season is in full swing - almost like we were mermaids in another life - our hair just isn’t. From chlorine doing its very best to cause damage to the seemingly endless detangling that happens post ocean swim, it’s clear that swimming and cute summer hair styles don’t really want to be friends. But before you decide to relegate yourself to only lounging or worse - wearing a swim cap - try out our pre-swim prep. With a little elbow grease (read: hair conditioning mask or leave-in conditioner) and a some advanced notice, you can prep your hair for basically any water related occasion.</p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">The pool is out to destroy your hair on two planes. The first is that the same chemicals keeping the pool clean and are absorbed by your hair the second you head under water. The same goes for salt water. But this can be hacked. Soaking your hair before heading into the pool fills the cuticle and prevents your hair from taking on any additional water filled with harsh chemicals. In a pinch that means running to the poolside shower before jumping in. If you have the time and beach bag space, bringing your own water treated with a hair conditioning mask or leave in conditioner will leave your hair enviably soft.</span></p>
<p style="color: #555f57;">Try adding <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod4450609" target="_blank">WELLA Enrich Moisturizing Treatment For Coarse Hair</a> to a bottle of water and douse right before heading in.</p>
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/7dd7c6e360e47210a5a804c478628859/tumblr_inline_n85p12pWbD1r9cmrh.jpg" alt="" /></p>
<p style="color: #555f57;">The second issue is that hair can’t wait to tangle when water is involved. For our straight haired friends this is less of an issue, but for anyone with more than a whisper of a curl prevention is key. A couple of easy braids, a simple bun, or well placed flat twists are protective styles that will make any post water detangling a cinch.</p>', 'HAIR PREP FOR THE BEACH AND POOL', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-07-29 16:28:03', '2014-07-29 16:28:03', '', 162, 'http://localhost:8888/2014/07/29/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (165, 1, '2014-07-29 16:32:58', '2014-07-29 16:32:58', '<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Now that summer is in full swing, we can put our winter gear out of it’s misery (read: into storage) and embrace all things sandals and minis. Also - manis. Nails rejoice! From the bright and beautiful to the neutral and classic, Instagram is our go to spot for nail color inpsoration. It’s chock-full of creative manicures to celebrating our escape from a hellish all-consuming winter that chewed us up and spit is out. Let’s paint our nails together and forget.</span></p>
[gallery ids="168,169,170,171,172,173,174,175,166"]
<p style="color: #555f57;"></p>', 'SUMMER MANI INSPIRATION', '', 'publish', 'open', 'open', '', 'summer-mani-insporation', '', '', '2014-10-16 00:10:26', '2014-10-16 00:10:26', '', 0, 'http://localhost:8888/?p=165', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (166, 1, '2014-07-29 16:32:36', '2014-07-29 16:32:36', '', 'Purple Tips', 'This sums up how summer makes us feel. Love. Love. Love.
(@sahsaniegraynails)', 'inherit', 'open', 'open', '', 'purptips', '', '', '2014-07-29 16:32:36', '2014-07-29 16:32:36', '', 165, 'http://localhost:8888/wp-content/uploads/2014/07/purptips.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (167, 1, '2014-07-29 16:32:58', '2014-07-29 16:32:58', '<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Now that summer is in full swing, we can put our winter gear out of it’s misery (read: into storage) and embrace all things sandals and minis. Also - manis. Nails rejoice! From the bright and beautiful to the neutral and classic, Instagram is our go to spot for nail color inpsoration. It’s chock-full of creative manicures to celebrating our escape from a hellish all-consuming winter that chewed us up and spit is out. Let’s paint our nails together and forget.</span></p>
<p style="color: #555f57;"></p>


[caption id="" align="alignleft" width="500"]<img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/bf7b80f86e58bfd3f8c60b0bf0a2ce08/tumblr_inline_n81b0c6VFK1r9cmrh.png" alt="" width="500" height="502" /> @tombachik[/caption]
<p style="color: #555f57;">Thank God it’s summer. Truer words have never been spoken.</p>
<p style="color: #555f57;"></p>


[caption id="" align="alignnone" width="500"]<img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/5a8526650b4298d8a1d65a8acc2e78b4/tumblr_inline_n81b0xBECc1r9cmrh.png" alt="" width="500" height="501" /> @laurenconrad[/caption]
<p style="color: #555f57;">Nothing says, “Winter, who?” like pink and gold.</p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"> </span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"><a class="tumblelog" style="font-weight: bold; font-style: inherit; color: #000000;" href="http://tmblr.co/mvNEFiPtMJhpNW9hA9lM57A" target="_blank">essiepolish</a></span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/9e72edeced2747960fca826351dcea75/tumblr_inline_n81b60SPBH1r9cmrh.png" alt="" /></span></p>
<p style="color: #555f57;">Easily recreate this chic nail art with <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod1320170&amp;skuId=2077630&amp;_requestid=532994" target="_blank">Blanc</a> ($8.50), <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.target.com/p/essie-nail-color-licorice/-/A-13249434" target="_blank">Licorice</a> ($8.50), and <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod4540247&amp;skuId=2248239&amp;_requestid=124817" target="_blank">No Place Like Chrome</a>  ($8.50) from Essie.</p>
<p style="color: #555f57;">@juliamurphree</p>
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/13f039bfd4199984e5c29d8f6190c52a/tumblr_inline_n81bdcv7pr1r9cmrh.jpg" alt="" /></p>
<p style="color: #555f57;">Too cool for school orange is the color we are loving for June.</p>
<p style="color: #555f57;">To the left: <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://instagram.com/maybelline" target="_blank">@maybelline</a> Color Show in <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.drugstore.com/maybelline-color-show-nail-lacquer-neutral-statement/qxp513181" target="_blank">Neutral Statement</a> and <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.target.com/p/maybelline-color-show-nail-lacquer-0-23-fl-oz/-/A-15114925" target="_blank">Orange Fix</a>(chevron) (both $3.99)</p>
<p style="color: #555f57;">To the right: <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://instagram.com/maybelline" target="_blank">@maybelline</a> <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.drugstore.com/maybelline-color-show-nail-lacquer-pretty-in-peach/qxp513191" target="_blank">Color Show Pretty in Peach</a> ($3.99)</p>
<p style="color: #555f57;">@oliveandjune</p>
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/6451fbaa488007de9f7cb53b2add0ca1/tumblr_inline_n81bi2n44K1r9cmrh.png" alt="" /></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Again with the orange - it’s clearly having a moment.</span></p>
<p style="color: #555f57;">@jinsoonchoi</p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/05edeb7f6045b647ad3cf1eeea6e5ab5/tumblr_inline_n81bkxJvbX1r9cmrh.png" alt="" /></span></p>
<p style="color: #555f57;">Polka dot nail art is so simple with Jin Soon’s <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.jinsoon.com/catalog/product/view/id/41/s/cherryberry/category/20/" target="_blank">Polka White</a> matte glitter top coat ($18), seen over <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.jinsoon.com/catalog/product/view/id/40/s/polkawhite/category/20/" target="_blank">Cherry Berry</a> ($18).</p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">
</span>@tenoverten_nyc</p>
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/ba64be7cbcd1d8581308762ae96ce840/tumblr_inline_n81bln9jJS1r9cmrh.png" alt="" /></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">This updated french manicure is so chic we don’t even remember what a winter is.</span></p>
<p style="color: #555f57;"><a class="tumblelog" style="font-weight: bold; font-style: inherit; color: #000000;" href="http://tmblr.co/mGyuNFpn89sBc48t2x4hS9Q" target="_blank">vanityprojects</a></p>
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/9dad0ed5d445bb0a0044a7b144887ba7/tumblr_inline_n81bmhJ2SO1r9cmrh.png" alt="" /></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">A little tribal mani never hurt anybody.</span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"> </span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">@sahsaniegraynails</span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/f16cb00e6c9b4a4a0b8f62af7fd9cc14/tumblr_inline_n81bmzjqo41r9cmrh.png" alt="" /></span></p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">This sums up how summer makes us feel. Love. Love. Love.</span></p>
<span style="font-weight: inherit; font-style: inherit;"> </span>', 'SUMMER MANI INSPORATION', '', 'inherit', 'open', 'open', '', '165-revision-v1', '', '', '2014-07-29 16:32:58', '2014-07-29 16:32:58', '', 165, 'http://localhost:8888/2014/07/29/165-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (168, 1, '2014-07-29 16:36:20', '2014-07-29 16:36:20', '', 'Tribal', 'A little tribal mani never hurt anybody. (vanityprojects)', 'inherit', 'open', 'open', '', 'nail9', '', '', '2014-07-29 16:36:20', '2014-07-29 16:36:20', '', 165, 'http://localhost:8888/wp-content/uploads/2014/07/nail9.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (169, 1, '2014-07-29 16:36:21', '2014-07-29 16:36:21', '', 'Frenchie', 'This updated french manicure is so chic we don’t even remember what a winter is. (@tenoverten_nyc)', 'inherit', 'open', 'open', '', 'nail8', '', '', '2014-07-29 16:36:21', '2014-07-29 16:36:21', '', 165, 'http://localhost:8888/wp-content/uploads/2014/07/nail8.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (170, 1, '2014-07-29 16:36:23', '2014-07-29 16:36:23', '', 'Polka', 'Polka dot nail art is so simple with Jin Soon’s Polka White matte glitter top coat ($18), seen over Cherry Berry ($18). (@jinsoonchoi)', 'inherit', 'open', 'open', '', 'nail7', '', '', '2014-07-29 16:36:23', '2014-07-29 16:36:23', '', 165, 'http://localhost:8888/wp-content/uploads/2014/07/nail7.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (171, 1, '2014-07-29 16:36:24', '2014-07-29 16:36:24', '', 'Orange', 'Again with the orange - it’s clearly having a moment. (@oliveandjune)', 'inherit', 'open', 'open', '', 'nail5', '', '', '2014-07-29 16:36:24', '2014-07-29 16:36:24', '', 165, 'http://localhost:8888/wp-content/uploads/2014/07/nail5.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (172, 1, '2014-07-29 16:36:26', '2014-07-29 16:36:26', '', 'Orange Chevron', 'Too cool for school orange is the color we are loving for June.  To the left: @maybelline Color Show in Neutral Statement and Orange Fix (chevron) (both $3.99)  To the right: @maybelline Color Show Pretty in Peach ($3.99) (@juliamurphree)', 'inherit', 'open', 'open', '', 'nail4', '', '', '2014-07-29 16:36:26', '2014-07-29 16:36:26', '', 165, 'http://localhost:8888/wp-content/uploads/2014/07/nail4.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (173, 1, '2014-07-29 16:36:27', '2014-07-29 16:36:27', '', 'Black & Blanc', 'Easily recreate this chic nail art with Blanc ($8.50), Licorice ($8.50), and No Place Like Chrome  ($8.50) from Essie. (essie polish)', 'inherit', 'open', 'open', '', 'nail3', '', '', '2014-07-29 16:36:27', '2014-07-29 16:36:27', '', 165, 'http://localhost:8888/wp-content/uploads/2014/07/nail3.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (174, 1, '2014-07-29 16:36:28', '2014-07-29 16:36:28', '', 'Pink & Gold', 'Nothing says, “Winter, who?” like pink and gold. (@laurenconrad)', 'inherit', 'open', 'open', '', 'nail2', '', '', '2014-07-29 16:36:28', '2014-07-29 16:36:28', '', 165, 'http://localhost:8888/wp-content/uploads/2014/07/nAIL2.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (175, 1, '2014-07-29 16:36:30', '2014-07-29 16:36:30', '', 'TGISummer', 'Thank God it’s summer. Truer words have never been spoken. (@tombachik)', 'inherit', 'open', 'open', '', 'nail1', '', '', '2014-07-29 16:36:30', '2014-07-29 16:36:30', '', 165, 'http://localhost:8888/wp-content/uploads/2014/07/nail1.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (176, 1, '2014-07-29 16:40:46', '2014-07-29 16:40:46', '<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Now that summer is in full swing, we can put our winter gear out of it’s misery (read: into storage) and embrace all things sandals and minis. Also - manis. Nails rejoice! From the bright and beautiful to the neutral and classic, Instagram is our go to spot for nail color inpsoration. It’s chock-full of creative manicures to celebrating our escape from a hellish all-consuming winter that chewed us up and spit is out. Let’s paint our nails together and forget.</span></p>
[gallery ids="168,169,170,171,172,173,174,175"]
<p style="color: #555f57;"></p>', 'SUMMER MANI INSPORATION', '', 'inherit', 'open', 'open', '', '165-revision-v1', '', '', '2014-07-29 16:40:46', '2014-07-29 16:40:46', '', 165, 'http://localhost:8888/2014/07/29/165-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (177, 1, '2014-07-29 16:45:35', '2014-07-29 16:45:35', '<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Now that summer is in full swing, we can put our winter gear out of it’s misery (read: into storage) and embrace all things sandals and minis. Also - manis. Nails rejoice! From the bright and beautiful to the neutral and classic, Instagram is our go to spot for nail color inpsoration. It’s chock-full of creative manicures to celebrating our escape from a hellish all-consuming winter that chewed us up and spit is out. Let’s paint our nails together and forget.</span></p>
[gallery ids="168,169,170,171,172,173,174,175,166"]
<p style="color: #555f57;"></p>', 'SUMMER MANI INSPORATION', '', 'inherit', 'open', 'open', '', '165-autosave-v1', '', '', '2014-07-29 16:45:35', '2014-07-29 16:45:35', '', 165, 'http://localhost:8888/2014/07/29/165-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (178, 1, '2014-07-29 16:45:37', '2014-07-29 16:45:37', '<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Now that summer is in full swing, we can put our winter gear out of it’s misery (read: into storage) and embrace all things sandals and minis. Also - manis. Nails rejoice! From the bright and beautiful to the neutral and classic, Instagram is our go to spot for nail color inpsoration. It’s chock-full of creative manicures to celebrating our escape from a hellish all-consuming winter that chewed us up and spit is out. Let’s paint our nails together and forget.</span></p>
[gallery ids="168,169,170,171,172,173,174,175,166"]
<p style="color: #555f57;"></p>', 'SUMMER MANI INSPORATION', '', 'inherit', 'open', 'open', '', '165-revision-v1', '', '', '2014-07-29 16:45:37', '2014-07-29 16:45:37', '', 165, 'http://localhost:8888/2014/07/29/165-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (180, 1, '2014-08-27 23:15:25', '2014-08-27 23:15:25', '<p style="color: #555f57;"><em style="font-weight: inherit;">It’s beyond official that summer has finally arrived. This leaves us with a long list of pros and cons. On the one hand, looking forward to endless days filled with barbecues, beach hangouts, and sunning ourselves by the pool is enough to make a girl downright euphoric. On the other, beauty related complications will arise. From sweat-proofing your makeup routine and to post pool hair TLC, we’ve got you covered. In this series we tackle the elements and give you the tools to defeat them so you can maintain that effortless cool look without missing a beat.</em></p>
<p style="color: #555f57;">While we are thrilled that beach (or pool if you’re into that) season is in full swing - almost like we were mermaids in another life - our hair just isn’t. From chlorine doing its very best to cause damage to the seemingly endless detangling that happens post ocean swim, it’s clear that swimming and cute summer hair styles don’t really want to be friends. But before you decide to relegate yourself to only lounging or worse - wearing a swim cap - try out our pre-swim prep. With a little elbow grease (read: hair conditioning mask or leave-in conditioner) and a some advanced notice, you can prep your hair for basically any water related occasion.</p>
<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">The pool is out to destroy your hair on two planes. The first is that the same chemicals keeping the pool clean and are absorbed by your hair the second you head under water. The same goes for salt water. But this can be hacked. Soaking your hair before heading into the pool fills the cuticle and prevents your hair from taking on any additional water filled with harsh chemicals. In a pinch that means running to the poolside shower before jumping in. If you have the time and beach bag space, bringing your own water treated with a hair conditioning mask or leave in conditioner will leave your hair enviably soft.</span></p>
<p style="color: #555f57;">Try adding <a style="font-weight: bold; font-style: inherit; color: #000000;" href="http://www.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod4450609" target="_blank">WELLA Enrich Moisturizing Treatment For Coarse Hair</a> to a bottle of water and douse right before heading in.</p>
<p style="color: #555f57;"><img style="font-weight: inherit; font-style: inherit;" src="http://media.tumblr.com/7dd7c6e360e47210a5a804c478628859/tumblr_inline_n85p12pWbD1r9cmrh.jpg" alt="" /></p>
<p style="color: #555f57;">The second issue is that hair can’t wait to tangle when water is involved. For our straight haired friends this is less of an issue, but for anyone with more than a whisper of a curl prevention is key. A couple of easy braids, a simple bun, or well placed flat twists are protective styles that will make any post water detangling a cinch.</p>


[caption id="attachment_172" align="alignnone" width="500"]<a href="http://localhost:8888/wp-content/uploads/2014/07/nail4.jpg"><img class="size-full wp-image-172" src="http://localhost:8888/wp-content/uploads/2014/07/nail4.jpg" alt="Too cool for school orange is the color we are loving for June.  To the left: @maybelline Color Show in Neutral Statement and Orange Fix (chevron) (both $3.99)  To the right: @maybelline Color Show Pretty in Peach ($3.99) (@juliamurphree)" width="500" height="250" /></a> Too cool for school orange is the color we are loving for June. To the left: @maybelline Color Show in Neutral Statement and Orange Fix (chevron) (both $3.99) To the right: @maybelline Color Show Pretty in Peach ($3.99) (@juliamurphree)[/caption]', 'HAIR PREP FOR THE BEACH AND POOL', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-08-27 23:15:25', '2014-08-27 23:15:25', '', 162, 'http://localhost:8888/2014/08/27/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (183, 1, '2014-09-11 19:35:40', '2014-09-11 19:35:40', 'Test content', 'Register', '', 'publish', 'open', 'open', '', 'register', '', '', '2014-09-11 19:35:40', '2014-09-11 19:35:40', '', 0, 'http://localhost:8888/?page_id=183', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (184, 1, '2014-09-11 19:35:24', '2014-09-11 19:35:24', 'Test content', 'Register', '', 'inherit', 'open', 'open', '', '183-revision-v1', '', '', '2014-09-11 19:35:24', '2014-09-11 19:35:24', '', 183, 'http://localhost:8888/2014/09/11/183-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (185, 1, '2014-09-11 19:36:07', '2014-09-11 19:36:07', 'Also test content', 'Activate', '', 'publish', 'open', 'open', '', 'activate', '', '', '2014-09-11 19:36:07', '2014-09-11 19:36:07', '', 0, 'http://localhost:8888/?page_id=185', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (186, 1, '2014-09-11 19:36:07', '2014-09-11 19:36:07', 'Also test content', 'Activate', '', 'inherit', 'open', 'open', '', '185-revision-v1', '', '', '2014-09-11 19:36:07', '2014-09-11 19:36:07', '', 185, 'http://localhost:8888/2014/09/11/185-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (192, 1, '2014-10-15 01:11:45', '2014-10-15 01:11:45', 'This is a WYSIWYG page.', 'Home', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-10-15 01:11:45', '2014-10-15 01:11:45', '', 10, 'http://localhost:8888/2014/10/15/10-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (193, 1, '2014-10-15 01:18:17', '2014-10-15 01:18:17', '    <div class="row">
      <div class="large-12 large-centered columns">
        <div class="leaderboard-container">
          <img src="http://placehold.it/728x90">
        </div>
      </div>  
    </div>
    <div class="row">
      <div class="small-12 columns">
        <h3 class="page-header">
           <span>Reviews</span></h3>
      </div>
    </div>
    <div class="row">
      <div class="small-12 columns">
        <aside class="small-12 medium-12 large-4 large-push-8 columns">

<!--******************************************Review Categories************************************-->
        <div class="review-categories">
          <h4>Categories</h4>
          <ul>
            <li>Hair</li>
            <li>Makeup</li>           
            <li>Nails</li>
            <li>Skincare</li>
            <li>Bath&nbsp;&amp;&nbsp;Body</li>
            <li>Tools&nbsp;/&nbsp;Accessories</li>
            <li>Fragrances</li>
            <li>Brands</li>
         </ul>          
        </div>
        <div class="product-request">
          <p>Don\'t<br> see your favorite</br> product?</p>
          <div></div>
          <button>Request It</button>
        </div>
        <div class="small-12 small-centered medium-12 medium-centered large-12 large-uncentered columns">
        <div class="halfpage-container">
          <img src="http://placehold.it/300x600">
        </div> 
        </div>
<!--******************************************Pinterest************************************-->
        <div class="pinterest-widget">
          <h4>Pinterest</h4>
          <a data-pin-do="embedUser" href="http://www.pinterest.com/prettytendr/" data-pin-scale-width="90" data-pin-scale-height="406" data-pin-board-width="294">Visit PrettyTendr\'s profile on Pinterest.</a>
 <!-- Please call pinit.js only once per page -->
      <script type="text/javascript" async src="//assets.pinterest.com/js/pinit.js"></script>
        </div>
<!--******************************************Instagram************************************-->
          <div class="instagram-widget">
            <h4>Instagram</h4>
            <iframe src="http://www.intagme.com/in/?u=cHJldHR5dGVuZHJ8aW58MTQ4fDJ8NHx8bm98MHx1bmRlZmluZWR8bm8=" allowTransparency="true" frameborder="0" scrolling="no" style="border:none; overflow:hidden; width:296px; height: 592px" ></iframe>
          </div>
        </aside>
        <div class="small-12 medium-12 large-8 large-uncentered large-pull-4 columns">
<!--******************************************Featured Slider************************************-->
          <div class="featured-slider">
            <div><img src="http://placehold.it/600x300"></div>
            <div><img src="http://placehold.it/600x300"></div>
            <div><img src="http://placehold.it/600x300"></div>
           </div>
 

<!--******************************************Product Segments************************************-->
          <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Hair</h4>
            </div>
          </div>
          <div class="row" >
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer >
              <div class="small-6 medium-3 large-3 columns">
                <li class"none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Phytospecific</p>
                  </div>
                  <div class="review-product-name">
                    <p>Moisture Creme</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Bumble and Bumble</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Pret a Powder</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Briogeo</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Don\'t Despair Repair!</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Living Proof</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Leave-In Conditioner</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Alterna</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Caviar Creme</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Ouidad</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Moisture Lock</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>DryBar</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Curling Set</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Ojon</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Moisturizing Oil</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Makeup Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Makeup</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/smashbox_finish.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/revlon.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/japonesque.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/hourglass.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/kat.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bare.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/buxom.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/urban.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Nails Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Nails</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/tenoverten_nails.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2279440?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2277728?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2255622?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2263980?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2278427?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2257916?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2237180?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Skincare Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Skincare</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/v/a/vasanti_brightenup_new_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/d/r/drbrandt_poresnomore_vacuumcleaner_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/suki_exfoliate_foaming_cleanser_120_ml_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/k/skin_co_sicillianlightserum_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/r/e/realchemistry_3minutepeel_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/c/a/caudalie_polyphenolc15_overnightdetoxoil_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/supergoop_everydaysunscreen_spf50_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/s/h/shiseido_ultimune_30ml_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div>
<!--****************************Mobile AD*******************************-->
  <div class="leaderboard-container" id="mobile-leaderboard">
          <img src="http://placehold.it/728x90">
        </div>
<!--********************************** Bath&nbsp;&amp;&nbsp;Body*********************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Bath&nbsp;&amp;&nbsp;Body</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--***********************************Tools&nbsp;/&nbsp;Accessories******************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Tools&nbsp;/&nbsp;Accessories</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name Extra Long</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Fragrances Section*******************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Fragrances</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Brands Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Brands</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Arcona_Logo_168x200_2.png">
                  </div>
                  

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Cartier_Logo_168x200.png">
                  </div>
                  
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/DrBrandt_logo_168x200_1.png">
                  </div>
                  
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch> 
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Kerastase_168x200_2.png">
                  </div>
                 
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Oribe-logo-wall_3.png">
                  </div>
                 
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch> 
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Tweezerman-Logo-168x200_1.png">
                  </div>
                  
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Shu_168x200_1.png">
                  </div>
                
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/StriVectin_Logo_NEW2014_168x200_1.png">
                  </div>
                  
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
 
        </div>
<!--Aside went here-->
      </div>
        
      </div>
      <div class="row">
          <div class="large-12 large-centered columns">
            <div class="leaderboard-container">
            <img src="http://placehold.it/728x90">
        </div>   
 
 
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <script src="bower_components/fastclick/lib/fastclick.js"></script>
    <script src="bower_components/foundation/js/foundation.min.js"></script>
    <script src="bower_components/foundation/js/foundation/foundation.equalizer.js"></script> 
    <script src="bower_components/foundation/js/foundation/foundation.offcanvas.js"></script>
    <script type="text/javascript" src="slick/slick.min.js"></script>
    <script src="js/app.js"></script>
      <script>
    $(document).foundation();
  </script>
  <script>
  $(document).ready(function(){
  $(\'.featured-slider\').slick({
    dots: true,
    autoplay: true,
    autoplaySpeed: 2000,
 
  });
});
  </script>
  <script>
   $(document).foundation({
  equalizer : {
    // Specify if Equalizer should make elements equal height once they become stacked.
    equalize_on_stack: true
  }
});
  </script>
', 'Reviews', '', 'publish', 'open', 'open', '', 'reviews', '', '', '2014-10-15 01:31:13', '2014-10-15 01:31:13', '', 0, 'http://localhost:8888/?page_id=193', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (194, 1, '2014-10-15 01:18:17', '2014-10-15 01:18:17', 'hiya!', 'Reviews', '', 'inherit', 'open', 'open', '', '193-revision-v1', '', '', '2014-10-15 01:18:17', '2014-10-15 01:18:17', '', 193, 'http://localhost:8888/2014/10/15/193-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (195, 1, '2014-10-15 01:31:11', '2014-10-15 01:31:11', '    <div class="row">
      <div class="large-12 large-centered columns">
        <div class="leaderboard-container">
          <img src="http://placehold.it/728x90">
        </div>
      </div>  
    </div>
    <div class="row">
      <div class="small-12 columns">
        <h3 class="page-header">
           <span>Reviews</span></h3>
      </div>
    </div>
    <div class="row">
      <div class="small-12 columns">
        <aside class="small-12 medium-12 large-4 large-push-8 columns">

<!--******************************************Review Categories************************************-->
        <div class="review-categories">
          <h4>Categories</h4>
          <ul>
            <li>Hair</li>
            <li>Makeup</li>           
            <li>Nails</li>
            <li>Skincare</li>
            <li>Bath&nbsp;&amp;&nbsp;Body</li>
            <li>Tools&nbsp;/&nbsp;Accessories</li>
            <li>Fragrances</li>
            <li>Brands</li>
         </ul>          
        </div>
        <div class="product-request">
          <p>Don\'t<br> see your favorite</br> product?</p>
          <div></div>
          <button>Request It</button>
        </div>
        <div class="small-12 small-centered medium-12 medium-centered large-12 large-uncentered columns">
        <div class="halfpage-container">
          <img src="http://placehold.it/300x600">
        </div> 
        </div>
<!--******************************************Pinterest************************************-->
        <div class="pinterest-widget">
          <h4>Pinterest</h4>
          <a data-pin-do="embedUser" href="http://www.pinterest.com/prettytendr/" data-pin-scale-width="90" data-pin-scale-height="406" data-pin-board-width="294">Visit PrettyTendr\'s profile on Pinterest.</a>
 <!-- Please call pinit.js only once per page -->
      <script type="text/javascript" async src="//assets.pinterest.com/js/pinit.js"></script>
        </div>
<!--******************************************Instagram************************************-->
          <div class="instagram-widget">
            <h4>Instagram</h4>
            <iframe src="http://www.intagme.com/in/?u=cHJldHR5dGVuZHJ8aW58MTQ4fDJ8NHx8bm98MHx1bmRlZmluZWR8bm8=" allowTransparency="true" frameborder="0" scrolling="no" style="border:none; overflow:hidden; width:296px; height: 592px" ></iframe>
          </div>
        </aside>
        <div class="small-12 medium-12 large-8 large-uncentered large-pull-4 columns">
<!--******************************************Featured Slider************************************-->
          <div class="featured-slider">
            <div><img src="http://placehold.it/600x300"></div>
            <div><img src="http://placehold.it/600x300"></div>
            <div><img src="http://placehold.it/600x300"></div>
           </div>
 

<!--******************************************Product Segments************************************-->
          <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Hair</h4>
            </div>
          </div>
          <div class="row" >
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer >
              <div class="small-6 medium-3 large-3 columns">
                <li class"none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Phytospecific</p>
                  </div>
                  <div class="review-product-name">
                    <p>Moisture Creme</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Bumble and Bumble</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Pret a Powder</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Briogeo</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Don\'t Despair Repair!</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Living Proof</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Leave-In Conditioner</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Alterna</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Caviar Creme</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Ouidad</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Moisture Lock</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>DryBar</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Curling Set</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Ojon</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Moisturizing Oil</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Makeup Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Makeup</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/smashbox_finish.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/revlon.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/japonesque.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/hourglass.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/kat.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bare.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/buxom.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/urban.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Nails Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Nails</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/tenoverten_nails.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2279440?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2277728?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2255622?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2263980?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2278427?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2257916?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2237180?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Skincare Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Skincare</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/v/a/vasanti_brightenup_new_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/d/r/drbrandt_poresnomore_vacuumcleaner_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/suki_exfoliate_foaming_cleanser_120_ml_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/k/skin_co_sicillianlightserum_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/r/e/realchemistry_3minutepeel_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/c/a/caudalie_polyphenolc15_overnightdetoxoil_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/supergoop_everydaysunscreen_spf50_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/s/h/shiseido_ultimune_30ml_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div>
<!--****************************Mobile AD*******************************-->
  <div class="leaderboard-container" id="mobile-leaderboard">
          <img src="http://placehold.it/728x90">
        </div>
<!--********************************** Bath&nbsp;&amp;&nbsp;Body*********************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Bath&nbsp;&amp;&nbsp;Body</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--***********************************Tools&nbsp;/&nbsp;Accessories******************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Tools&nbsp;/&nbsp;Accessories</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name Extra Long</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Fragrances Section*******************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Fragrances</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Brands Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Brands</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Arcona_Logo_168x200_2.png">
                  </div>
                  

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Cartier_Logo_168x200.png">
                  </div>
                  
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/DrBrandt_logo_168x200_1.png">
                  </div>
                  
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch> 
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Kerastase_168x200_2.png">
                  </div>
                 
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Oribe-logo-wall_3.png">
                  </div>
                 
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch> 
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Tweezerman-Logo-168x200_1.png">
                  </div>
                  
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Shu_168x200_1.png">
                  </div>
                
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/StriVectin_Logo_NEW2014_168x200_1.png">
                  </div>
                  
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
 
        </div>
<!--Aside went here-->
      </div>
        
      </div>
      <div class="row">
          <div class="large-12 large-centered columns">
            <div class="leaderboard-container">
            <img src="http://placehold.it/728x90">
        </div>   
 
 
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <script src="bower_components/fastclick/lib/fastclick.js"></script>
    <script src="bower_components/foundation/js/foundation.min.js"></script>
    <script src="bower_components/foundation/js/foundation/foundation.equalizer.js"></script> 
    <script src="bower_components/foundation/js/foundation/foundation.offcanvas.js"></script>
    <script type="text/javascript" src="slick/slick.min.js"></script>
    <script src="js/app.js"></script>
      <script>
    $(document).foundation();
  </script>
  <script>
  $(document).ready(function(){
  $(\'.featured-slider\').slick({
    dots: true,
    autoplay: true,
    autoplaySpeed: 2000,
 
  });
});
  </script>
  <script>
   $(document).foundation({
  equalizer : {
    // Specify if Equalizer should make elements equal height once they become stacked.
    equalize_on_stack: true
  }
});
  </script>
', 'Reviews', '', 'inherit', 'open', 'open', '', '193-autosave-v1', '', '', '2014-10-15 01:31:11', '2014-10-15 01:31:11', '', 193, 'http://localhost:8888/2014/10/15/193-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (196, 1, '2014-10-15 01:20:02', '2014-10-15 01:20:02', '<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>PrettyTendr | The Currency of Beauty</title>
    <link rel="stylesheet" href="stylesheets/app.css" />
     <script src="//use.typekit.net/tog3fnw.js"></script>
    <script>try{Typekit.load();}catch(e){}</script>
    <script src="bower_components/modernizr/modernizr.js"></script>

    <link rel="stylesheet" type="text/css" href="slick/slick.css"/>
     <link rel="stylesheet" href="bower_components/foundation/css/foundation-icons/foundation-icons.css" />


  </head>
  <body>
    <div class="row">
      <div class="large-12 large-centered columns">
        <div class="leaderboard-container">
          <img src="http://placehold.it/728x90">
        </div>
      </div>  
    </div>
    <div class="row">
      <div class="small-12 columns">
        <h3 class="page-header">
           <span>Reviews</span></h3>
      </div>
    </div>
    <div class="row">
      <div class="small-12 columns">
        <aside class="small-12 medium-12 large-4 large-push-8 columns">

<!--******************************************Review Categories************************************-->
        <div class="review-categories">
          <h4>Categories</h4>
          <ul>
            <li>Hair</li>
            <li>Makeup</li>           
            <li>Nails</li>
            <li>Skincare</li>
            <li>Bath&nbsp;&amp;&nbsp;Body</li>
            <li>Tools&nbsp;/&nbsp;Accessories</li>
            <li>Fragrances</li>
            <li>Brands</li>
         </ul>          
        </div>
        <div class="product-request">
          <p>Don\'t<br> see your favorite</br> product?</p>
          <div></div>
          <button>Request It</button>
        </div>
        <div class="small-12 small-centered medium-12 medium-centered large-12 large-uncentered columns">
        <div class="halfpage-container">
          <img src="http://placehold.it/300x600">
        </div> 
        </div>
<!--******************************************Pinterest************************************-->
        <div class="pinterest-widget">
          <h4>Pinterest</h4>
          <a data-pin-do="embedUser" href="http://www.pinterest.com/prettytendr/" data-pin-scale-width="90" data-pin-scale-height="406" data-pin-board-width="294">Visit PrettyTendr\'s profile on Pinterest.</a>
 <!-- Please call pinit.js only once per page -->
      <script type="text/javascript" async src="//assets.pinterest.com/js/pinit.js"></script>
        </div>
<!--******************************************Instagram************************************-->
          <div class="instagram-widget">
            <h4>Instagram</h4>
            <iframe src="http://www.intagme.com/in/?u=cHJldHR5dGVuZHJ8aW58MTQ4fDJ8NHx8bm98MHx1bmRlZmluZWR8bm8=" allowTransparency="true" frameborder="0" scrolling="no" style="border:none; overflow:hidden; width:296px; height: 592px" ></iframe>
          </div>
        </aside>
        <div class="small-12 medium-12 large-8 large-uncentered large-pull-4 columns">
<!--******************************************Featured Slider************************************-->
          <div class="featured-slider">
            <div><img src="http://placehold.it/600x300"></div>
            <div><img src="http://placehold.it/600x300"></div>
            <div><img src="http://placehold.it/600x300"></div>
           </div>
 

<!--******************************************Product Segments************************************-->
          <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Hair</h4>
            </div>
          </div>
          <div class="row" >
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer >
              <div class="small-6 medium-3 large-3 columns">
                <li class"none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Phytospecific</p>
                  </div>
                  <div class="review-product-name">
                    <p>Moisture Creme</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Bumble and Bumble</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Pret a Powder</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Briogeo</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Don\'t Despair Repair!</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Living Proof</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Leave-In Conditioner</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Alterna</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Caviar Creme</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Ouidad</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Moisture Lock</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>DryBar</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Curling Set</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Ojon</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Moisturizing Oil</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Makeup Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Makeup</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/smashbox_finish.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/revlon.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/japonesque.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/hourglass.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/kat.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bare.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/buxom.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/urban.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Nails Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Nails</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/tenoverten_nails.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2279440?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2277728?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2255622?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2263980?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2278427?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2257916?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2237180?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Skincare Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Skincare</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/v/a/vasanti_brightenup_new_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/d/r/drbrandt_poresnomore_vacuumcleaner_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/suki_exfoliate_foaming_cleanser_120_ml_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/k/skin_co_sicillianlightserum_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/r/e/realchemistry_3minutepeel_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/c/a/caudalie_polyphenolc15_overnightdetoxoil_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/supergoop_everydaysunscreen_spf50_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/s/h/shiseido_ultimune_30ml_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div>
<!--****************************Mobile AD*******************************-->
  <div class="leaderboard-container" id="mobile-leaderboard">
          <img src="http://placehold.it/728x90">
        </div>
<!--********************************** Bath&nbsp;&amp;&nbsp;Body*********************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Bath&nbsp;&amp;&nbsp;Body</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--***********************************Tools&nbsp;/&nbsp;Accessories******************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Tools&nbsp;/&nbsp;Accessories</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name Extra Long</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Fragrances Section*******************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Fragrances</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Brands Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Brands</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Arcona_Logo_168x200_2.png">
                  </div>
                  

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Cartier_Logo_168x200.png">
                  </div>
                  
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/DrBrandt_logo_168x200_1.png">
                  </div>
                  
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch> 
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Kerastase_168x200_2.png">
                  </div>
                 
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Oribe-logo-wall_3.png">
                  </div>
                 
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch> 
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Tweezerman-Logo-168x200_1.png">
                  </div>
                  
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Shu_168x200_1.png">
                  </div>
                
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/StriVectin_Logo_NEW2014_168x200_1.png">
                  </div>
                  
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
 
        </div>
<!--Aside went here-->
      </div>
        
      </div>
      <div class="row">
          <div class="large-12 large-centered columns">
            <div class="leaderboard-container">
            <img src="http://placehold.it/728x90">
        </div>   
 
 
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <script src="bower_components/fastclick/lib/fastclick.js"></script>
    <script src="bower_components/foundation/js/foundation.min.js"></script>
    <script src="bower_components/foundation/js/foundation/foundation.equalizer.js"></script> 
    <script src="bower_components/foundation/js/foundation/foundation.offcanvas.js"></script>
    <script type="text/javascript" src="slick/slick.min.js"></script>
    <script src="js/app.js"></script>
      <script>
    $(document).foundation();
  </script>
  <script>
  $(document).ready(function(){
  $(\'.featured-slider\').slick({
    dots: true,
    autoplay: true,
    autoplaySpeed: 2000,
 
  });
});
  </script>
  <script>
   $(document).foundation({
  equalizer : {
    // Specify if Equalizer should make elements equal height once they become stacked.
    equalize_on_stack: true
  }
});
  </script>
   </body>
</html>
', 'Reviews', '', 'inherit', 'open', 'open', '', '193-revision-v1', '', '', '2014-10-15 01:20:02', '2014-10-15 01:20:02', '', 193, 'http://localhost:8888/2014/10/15/193-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (197, 1, '2014-10-15 01:27:13', '2014-10-15 01:27:13', '&lt;!doctype html&gt;



PrettyTendr | The Currency of Beauty
<script src="//use.typekit.net/tog3fnw.js"></script><script>// <![CDATA[
try{Typekit.load();}catch(e){}
// ]]></script>
<script src="bower_components/modernizr/modernizr.js"></script> 

<div class="row">

<div class="large-12 large-centered columns">

<div class="leaderboard-container"><img src="http://placehold.it/728x90" alt="" /></div>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-12 columns">

<h3 class="page-header">Reviews</h3>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-12 columns">
<aside class="small-12 medium-12 large-4 large-push-8 columns"><!--******************************************Review Categories************************************--> 

<div class="review-categories">
<div class="review-categories">

<h4>Categories</h4>
<ul>
<ul>
	<li>Hair</li>
</ul>
</ul>

&nbsp;
</div>
</div>
	<li>Makeup</li>
	<li>Nails</li>
	<li>Skincare</li>
	<li>Bath &amp; Body</li>
	<li>Tools / Accessories</li>
	<li>Fragrances</li>
	<li>Brands</li>

&nbsp;

<div class="product-request">
Don\'t
 see your favorite product?

<div></div>

<button>Request It</button>
</div>

&nbsp;

<div class="small-12 small-centered medium-12 medium-centered large-12 large-uncentered columns">

<div class="halfpage-container"><img src="http://placehold.it/300x600" alt="" /></div>

&nbsp;
</div>

<!--******************************************Pinterest************************************--> 

<div class="pinterest-widget">

<h4>Pinterest</h4>

<a href="http://www.pinterest.com/prettytendr/" data-pin-do="embedUser" data-pin-scale-width="90" data-pin-scale-height="406" data-pin-board-width="294">Visit PrettyTendr\'s profile on Pinterest.</a> <!-- Please call pinit.js only once per page --><script src="//assets.pinterest.com/js/pinit.js" async=""></script>

</div>
<!--******************************************Instagram************************************-->
<div class="instagram-widget">
<h4>Instagram</h4>
<iframe style="border: none; overflow: hidden; width: 296px; height: 592px;" src="http://www.intagme.com/in/?u=cHJldHR5dGVuZHJ8aW58MTQ4fDJ8NHx8bm98MHx1bmRlZmluZWR8bm8=" width="300" height="150" frameborder="0" scrolling="no"></iframe>

</div>
</aside>
<div class="small-12 medium-12 large-8 large-uncentered large-pull-4 columns"><!--******************************************Featured Slider************************************--></div>
</div>
</div>
<div class="featured-slider">
<div><img src="http://placehold.it/600x300" alt="" /></div>
<div><img src="http://placehold.it/600x300" alt="" /></div>
<div><img src="http://placehold.it/600x300" alt="" /></div>
</div>
<!--******************************************Product Segments************************************-->
<div class="reviews-section">
<div class="large-8 large-centered columns">
<h4>Top-Rated Hair</h4>
</div>
</div>
<div class="row">
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/phyto.jpg" alt="" /></div>
<div class="review-product-brand">

Phytospecific

</div>
<div class="review-product-name">

Moisture Creme

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i id="back" class="fi-heart"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li class="none" data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/bumble_pret.jpeg" alt="" /></div>
<div class="review-product-brand">

Bumble and Bumble

</div>
<div class="review-product-name">

Pret a Powder

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li class="none" data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/briogeo_repair.jpeg" alt="" /></div>
<div class="review-product-brand">

Briogeo

</div>
<div class="review-product-name">

Don\'t Despair Repair!

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li class="none" data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/living_proof.jpeg" alt="" /></div>
<div class="review-product-brand">

Living Proof

</div>
<div class="review-product-name">

Leave-In Conditioner

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li class="none" data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/alterna_caviar.jpeg" alt="" /></div>
<div class="review-product-brand">

Alterna

</div>
<div class="review-product-name">

Caviar Creme

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li class="none" data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/ouidad_define.jpeg" alt="" /></div>
<div class="review-product-brand">

Ouidad

</div>
<div class="review-product-name">

Moisture Lock

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li class="none" data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/dry_bar.jpeg" alt="" /></div>
<div class="review-product-brand">

DryBar

</div>
<div class="review-product-name">

Curling Set

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li class="none" data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/ojon_oil.jpeg" alt="" /></div>
<div class="review-product-brand">

Ojon

</div>
<div class="review-product-name">

Moisturizing Oil

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="reviews-all">

See all

</div>
</div>
<!--******************************************Makeup Section************************************-->
<div class="reviews-section">
<div class="large-8 large-centered columns">
<h4>Top-Rated Makeup</h4>
</div>
</div>
<div class="row">
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/smashbox_finish.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name Extra Long

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i id="back" class="fi-heart"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/revlon.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/japonesque.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/hourglass.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/kat.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/bare.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/buxom.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name Extra Long

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/urban.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="reviews-all">

See all

</div>
</div>
<!--******************************************Nails Section************************************-->
<div class="reviews-section">
<div class="large-8 large-centered columns">
<h4>Top-Rated Nails</h4>
</div>
</div>
<div class="row">
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/tenoverten_nails.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i id="back" class="fi-heart"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2279440?$md$" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2277728?$md$" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2255622?$md$" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2263980?$md$" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name Extra Long

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2278427?$md$" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2257916?$md$" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2237180?$md$" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="reviews-all">

See all

</div>
</div>
<!--******************************************Skincare Section************************************-->
<div class="reviews-section">
<div class="large-8 large-centered columns">
<h4>Top-Rated Skincare</h4>
</div>
</div>
<div class="row">
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/v/a/vasanti_brightenup_new_900x900.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i id="back" class="fi-heart"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/d/r/drbrandt_poresnomore_vacuumcleaner_900x900.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/suki_exfoliate_foaming_cleanser_120_ml_900x900.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name Extra Long

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/k/skin_co_sicillianlightserum_900x900.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/r/e/realchemistry_3minutepeel_900x900.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/c/a/caudalie_polyphenolc15_overnightdetoxoil_900x900.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/supergoop_everydaysunscreen_spf50_900x900.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li>
<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/s/h/shiseido_ultimune_30ml_900x900.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="reviews-all">

See all

</div>
</div>
<!--****************************Mobile AD*******************************-->
<div id="mobile-leaderboard" class="leaderboard-container"><img src="http://placehold.it/728x90" alt="" /></div>
<!--********************************** Bath&nbsp;&amp;&nbsp;Body*********************************-->
<div class="reviews-section">
<div class="large-8 large-centered columns">
<h4>Top-Rated Bath &amp; Body</h4>
</div>
</div>
<div class="row">
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/phyto.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name Extra Long

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i id="back" class="fi-heart"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/bumble_pret.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/briogeo_repair.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/living_proof.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/alterna_caviar.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/ouidad_define.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/dry_bar.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name Extra Long

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/ojon_oil.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="reviews-all">

See all

</div>
</div>
<!--***********************************Tools&nbsp;/&nbsp;Accessories******************************-->
<div class="reviews-section">
<div class="large-8 large-centered columns">
<h4>Top-Rated Tools / Accessories</h4>
</div>
</div>
<div class="row">
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/phyto.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i id="back" class="fi-heart"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/bumble_pret.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/briogeo_repair.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/living_proof.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/alterna_caviar.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/ouidad_define.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/dry_bar.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name Extra Long

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/ojon_oil.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="reviews-all">

See all

</div>
</div>
<!--******************************************Fragrances Section*******************************-->
<div class="reviews-section">
<div class="large-8 large-centered columns">
<h4>Top-Rated Fragrances</h4>
</div>
</div>
<div class="row">
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/phyto.jpg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i id="back" class="fi-heart"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/bumble_pret.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/briogeo_repair.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/living_proof.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/alterna_caviar.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/ouidad_define.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/dry_bar.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name Extra Long

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="stylesheets/img/ojon_oil.jpeg" alt="" /></div>
<div class="review-product-brand">

Brand Name

</div>
<div class="review-product-name">

Product Name

</div>
<div class="review-rating">
<div class="star-rating"></div>
<span class="review-count">(108)</span>

</div>
<div class="review-price"><span class="rev-price">$39.00</span></div>
<div class="review-faves"><i class="fi-heart size-20"></i>
<span class="review-fave-count">65</span></div></li>
</ul>
</div>
<div class="reviews-all">

See all

</div>
</div>
<!--******************************************Brands Section************************************-->
<div class="reviews-section">
<div class="large-8 large-centered columns">
<h4>Top-Rated Brands</h4>
</div>
</div>
<div class="row">
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Arcona_Logo_168x200_2.png" alt="" /></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Cartier_Logo_168x200.png" alt="" /></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/DrBrandt_logo_168x200_1.png" alt="" /></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Kerastase_168x200_2.png" alt="" /></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Oribe-logo-wall_3.png" alt="" /></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Tweezerman-Logo-168x200_1.png" alt="" /></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Shu_168x200_1.png" alt="" /></div></li>
</ul>
</div>
<div class="small-6 medium-3 large-3 columns">
<ul>
	<li data-equalizer-watch="">
<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/StriVectin_Logo_NEW2014_168x200_1.png" alt="" /></div></li>
</ul>
</div>
<div class="reviews-all">

See all

</div>
</div>
<!--Aside went here-->
<div class="row">
<div class="large-12 large-centered columns">
<div class="leaderboard-container"><img src="http://placehold.it/728x90" alt="" /></div>
<script src="bower_components/jquery/dist/jquery.min.js"></script><script src="bower_components/fastclick/lib/fastclick.js"></script>
<script src="bower_components/foundation/js/foundation.min.js"></script><script src="bower_components/foundation/js/foundation/foundation.equalizer.js"></script>
<script src="bower_components/foundation/js/foundation/foundation.offcanvas.js"></script><script src="slick/slick.min.js"></script>
<script src="js/app.js"></script><script>// <![CDATA[
    $(document).foundation();
  
// ]]></script>
<script>// <![CDATA[
  $(document).ready(function(){
  $(\'.featured-slider\').slick({
    dots: true,
    autoplay: true,
    autoplaySpeed: 2000,
 
  });
});
  
// ]]></script>
<script>// <![CDATA[
   $(document).foundation({
  equalizer : {
    // Specify if Equalizer should make elements equal height once they become stacked.
    equalize_on_stack: true
  }
});
  
// ]]></script>

</div>
</div>
&nbsp;', 'Reviews', '', 'inherit', 'open', 'open', '', '193-revision-v1', '', '', '2014-10-15 01:27:13', '2014-10-15 01:27:13', '', 193, 'http://localhost:8888/2014/10/15/193-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (198, 1, '2014-10-15 01:29:05', '2014-10-15 01:29:05', '', 'Reviews', '', 'inherit', 'open', 'open', '', '193-revision-v1', '', '', '2014-10-15 01:29:05', '2014-10-15 01:29:05', '', 193, 'http://localhost:8888/2014/10/15/193-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (199, 1, '2014-10-15 01:31:13', '2014-10-15 01:31:13', '    <div class="row">
      <div class="large-12 large-centered columns">
        <div class="leaderboard-container">
          <img src="http://placehold.it/728x90">
        </div>
      </div>  
    </div>
    <div class="row">
      <div class="small-12 columns">
        <h3 class="page-header">
           <span>Reviews</span></h3>
      </div>
    </div>
    <div class="row">
      <div class="small-12 columns">
        <aside class="small-12 medium-12 large-4 large-push-8 columns">

<!--******************************************Review Categories************************************-->
        <div class="review-categories">
          <h4>Categories</h4>
          <ul>
            <li>Hair</li>
            <li>Makeup</li>           
            <li>Nails</li>
            <li>Skincare</li>
            <li>Bath&nbsp;&amp;&nbsp;Body</li>
            <li>Tools&nbsp;/&nbsp;Accessories</li>
            <li>Fragrances</li>
            <li>Brands</li>
         </ul>          
        </div>
        <div class="product-request">
          <p>Don\'t<br> see your favorite</br> product?</p>
          <div></div>
          <button>Request It</button>
        </div>
        <div class="small-12 small-centered medium-12 medium-centered large-12 large-uncentered columns">
        <div class="halfpage-container">
          <img src="http://placehold.it/300x600">
        </div> 
        </div>
<!--******************************************Pinterest************************************-->
        <div class="pinterest-widget">
          <h4>Pinterest</h4>
          <a data-pin-do="embedUser" href="http://www.pinterest.com/prettytendr/" data-pin-scale-width="90" data-pin-scale-height="406" data-pin-board-width="294">Visit PrettyTendr\'s profile on Pinterest.</a>
 <!-- Please call pinit.js only once per page -->
      <script type="text/javascript" async src="//assets.pinterest.com/js/pinit.js"></script>
        </div>
<!--******************************************Instagram************************************-->
          <div class="instagram-widget">
            <h4>Instagram</h4>
            <iframe src="http://www.intagme.com/in/?u=cHJldHR5dGVuZHJ8aW58MTQ4fDJ8NHx8bm98MHx1bmRlZmluZWR8bm8=" allowTransparency="true" frameborder="0" scrolling="no" style="border:none; overflow:hidden; width:296px; height: 592px" ></iframe>
          </div>
        </aside>
        <div class="small-12 medium-12 large-8 large-uncentered large-pull-4 columns">
<!--******************************************Featured Slider************************************-->
          <div class="featured-slider">
            <div><img src="http://placehold.it/600x300"></div>
            <div><img src="http://placehold.it/600x300"></div>
            <div><img src="http://placehold.it/600x300"></div>
           </div>
 

<!--******************************************Product Segments************************************-->
          <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Hair</h4>
            </div>
          </div>
          <div class="row" >
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer >
              <div class="small-6 medium-3 large-3 columns">
                <li class"none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Phytospecific</p>
                  </div>
                  <div class="review-product-name">
                    <p>Moisture Creme</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Bumble and Bumble</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Pret a Powder</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Briogeo</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Don\'t Despair Repair!</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Living Proof</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Leave-In Conditioner</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Alterna</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Caviar Creme</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Ouidad</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Moisture Lock</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>DryBar</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Curling Set</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li class="none" data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Ojon</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Moisturizing Oil</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Makeup Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Makeup</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/smashbox_finish.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/revlon.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/japonesque.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/hourglass.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/kat.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bare.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/buxom.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/urban.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Nails Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Nails</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/tenoverten_nails.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2279440?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2277728?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2255622?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2263980?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2278427?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2257916?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="http://s7d5.scene7.com/is/image/Ulta/2237180?$md$">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Skincare Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Skincare</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/v/a/vasanti_brightenup_new_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/d/r/drbrandt_poresnomore_vacuumcleaner_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/suki_exfoliate_foaming_cleanser_120_ml_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/k/skin_co_sicillianlightserum_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/r/e/realchemistry_3minutepeel_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/c/a/caudalie_polyphenolc15_overnightdetoxoil_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/supergoop_everydaysunscreen_spf50_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/s/h/shiseido_ultimune_30ml_900x900.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div>
<!--****************************Mobile AD*******************************-->
  <div class="leaderboard-container" id="mobile-leaderboard">
          <img src="http://placehold.it/728x90">
        </div>
<!--********************************** Bath&nbsp;&amp;&nbsp;Body*********************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Bath&nbsp;&amp;&nbsp;Body</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--***********************************Tools&nbsp;/&nbsp;Accessories******************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Tools&nbsp;/&nbsp;Accessories</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name Extra Long</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Fragrances Section*******************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Fragrances</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/phyto.jpg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div>
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">

                      <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                   <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                     <i id="back" class="fi-heart"></i>
                     <span class="review-fave-count">65</span>
                  </div>

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/bumble_pret.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/briogeo_repair.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/living_proof.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/alterna_caviar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ouidad_define.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/dry_bar.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name Extra Long</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="stylesheets/img/ojon_oil.jpeg">
                  </div>
                  <div class="review-product-brand">
                    <p>Brand Name</p>
                  </div> 
                  <div class="review-product-name">
                    <p>Product Name</p>
                  </div>
                  <div class="review-rating">
                    <div class="star-rating"></div>
                    <span class="review-count">(108)</span>
                  </div>
                  <div class="review-price">
                    <span class="rev-price">$39.00</span>
                  </div>
                  <div class="review-faves">
                    <i class="fi-heart size-20"></i>
                    <span class="review-fave-count">65</span>
                  </div>
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
<!--******************************************Brands Section************************************-->
 <div class="reviews-section">
            <div class="large-8 large-centered columns">
              <h4>Top-Rated Brands</h4>
            </div>
          </div>
          <div class="row">
            <ul class="reviews-module medium-12 large-12 large-centered columns" data-equalizer>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Arcona_Logo_168x200_2.png">
                  </div>
                  

                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Cartier_Logo_168x200.png">
                  </div>
                  
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/DrBrandt_logo_168x200_1.png">
                  </div>
                  
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch> 
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Kerastase_168x200_2.png">
                  </div>
                 
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Oribe-logo-wall_3.png">
                  </div>
                 
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch> 
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Tweezerman-Logo-168x200_1.png">
                  </div>
                  
                </li> 
              </div>
              <div class="small-6 medium-3 large-3 columns"> 
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/Shu_168x200_1.png">
                  </div>
                
                </li>
              </div>
              <div class="small-6 medium-3 large-3 columns">
                <li data-equalizer-watch>
                  <div class="review-thumbnail">
                    <img src="https://www.birchbox.com/men/media/catalog/category/StriVectin_Logo_NEW2014_168x200_1.png">
                  </div>
                  
                </li> 
              </div>                            
            </ul>
            <div class="reviews-all">
              <p>See all</p>
            </div>
          </div> 
 
        </div>
<!--Aside went here-->
      </div>
        
      </div>
      <div class="row">
          <div class="large-12 large-centered columns">
            <div class="leaderboard-container">
            <img src="http://placehold.it/728x90">
        </div>   
 
 
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <script src="bower_components/fastclick/lib/fastclick.js"></script>
    <script src="bower_components/foundation/js/foundation.min.js"></script>
    <script src="bower_components/foundation/js/foundation/foundation.equalizer.js"></script> 
    <script src="bower_components/foundation/js/foundation/foundation.offcanvas.js"></script>
    <script type="text/javascript" src="slick/slick.min.js"></script>
    <script src="js/app.js"></script>
      <script>
    $(document).foundation();
  </script>
  <script>
  $(document).ready(function(){
  $(\'.featured-slider\').slick({
    dots: true,
    autoplay: true,
    autoplaySpeed: 2000,
 
  });
});
  </script>
  <script>
   $(document).foundation({
  equalizer : {
    // Specify if Equalizer should make elements equal height once they become stacked.
    equalize_on_stack: true
  }
});
  </script>
', 'Reviews', '', 'inherit', 'open', 'open', '', '193-revision-v1', '', '', '2014-10-15 01:31:13', '2014-10-15 01:31:13', '', 193, 'http://localhost:8888/2014/10/15/193-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (200, 1, '2014-10-15 01:42:38', '2014-10-15 01:42:38', '<div class="row">
<div class="large-12 large-centered columns">
<div class="leaderboard-container"><img src="http://placehold.it/728x90" alt="" /></div>
</div>
</div>
<div class="row">
<div class="small-12 columns">
<h3 class="page-header">Reviews</h3>
</div>
</div>
<div class="row">
<div class="small-12 columns"><aside class="small-12 medium-12 large-4 large-push-8 columns"><!--******************************************Review Categories************************************-->
<div class="review-categories">
<h4>Categories</h4>
<ul>
	<li>Hair</li>
	<li>Makeup</li>
	<li>Nails</li>
	<li>Skincare</li>
	<li>Bath &amp; Body</li>
	<li>Tools / Accessories</li>
	<li>Fragrances</li>
	<li>Brands</li>
</ul>
</div>
<div class="product-request">

Don\'t
see your favorite product?
<div></div>
<button>Request It</button>

</div>
<div class="small-12 small-centered medium-12 medium-centered large-12 large-uncentered columns">
<div class="halfpage-container"><img src="http://placehold.it/300x600" alt="" /></div>
</div>
<!--******************************************Pinterest************************************-->
<div class="pinterest-widget">
<h4>Pinterest</h4>
<a href="http://www.pinterest.com/prettytendr/" data-pin-do="embedUser" data-pin-scale-width="90" data-pin-scale-height="406" data-pin-board-width="294">Visit PrettyTendr\'s profile on Pinterest.</a>
<!-- Please call pinit.js only once per page -->
<script src="//assets.pinterest.com/js/pinit.js" async=""></script>
</div>

<!--******************************************Instagram************************************--> 

<div class="instagram-widget">

<h4>Instagram</h4>

<iframe style="border: none; overflow: hidden; width: 296px; height: 592px;" src="http://www.intagme.com/in/?u=cHJldHR5dGVuZHJ8aW58MTQ4fDJ8NHx8bm98MHx1bmRlZmluZWR8bm8=" width="300" height="150" frameborder="0" scrolling="no"></iframe>
</div>
</aside>
&nbsp;

<div class="small-12 medium-12 large-8 large-uncentered large-pull-4 columns"><!--******************************************Featured Slider************************************--> 

<div class="featured-slider">
<div><img src="http://placehold.it/600x300" alt="" /></div>
<div><img src="http://placehold.it/600x300" alt="" /></div>
<div><img src="http://placehold.it/600x300" alt="" /></div>
</div>

<!--******************************************Product Segments************************************--> 

<div class="reviews-section">

<div class="large-8 large-centered columns">

<h4>Top-Rated Hair</h4>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/phyto.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Phytospecific</div>

&nbsp;

<div class="review-product-name">Moisture Creme</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i id="back" class="fi-heart"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li class="none" data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/bumble_pret.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Bumble and Bumble</div>

&nbsp;

<div class="review-product-name">Pret a Powder</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li class="none" data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/briogeo_repair.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Briogeo</div>

&nbsp;

<div class="review-product-name">Don\'t Despair Repair!</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li class="none" data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/living_proof.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Living Proof</div>

&nbsp;

<div class="review-product-name">Leave-In Conditioner</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li class="none" data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/alterna_caviar.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Alterna</div>

&nbsp;

<div class="review-product-name">Caviar Creme</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li class="none" data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/ouidad_define.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Ouidad</div>

&nbsp;

<div class="review-product-name">Moisture Lock</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li class="none" data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/dry_bar.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">DryBar</div>

&nbsp;

<div class="review-product-name">Curling Set</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li class="none" data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/ojon_oil.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Ojon</div>

&nbsp;

<div class="review-product-name">Moisturizing Oil</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="reviews-all">See all</div>
</div>

<!--******************************************Makeup Section************************************--> 

<div class="reviews-section">

<div class="large-8 large-centered columns">

<h4>Top-Rated Makeup</h4>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/smashbox_finish.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name Extra Long</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i id="back" class="fi-heart"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/revlon.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/japonesque.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/hourglass.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/kat.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/bare.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/buxom.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name Extra Long</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/urban.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="reviews-all">See all</div>
</div>

<!--******************************************Nails Section************************************--> 

<div class="reviews-section">

<div class="large-8 large-centered columns">

<h4>Top-Rated Nails</h4>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/tenoverten_nails.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i id="back" class="fi-heart"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2279440?$md$" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2277728?$md$" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2255622?$md$" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2263980?$md$" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name Extra Long</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2278427?$md$" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2257916?$md$" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="http://s7d5.scene7.com/is/image/Ulta/2237180?$md$" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="reviews-all">See all</div>
</div>

<!--******************************************Skincare Section************************************--> 

<div class="reviews-section">

<div class="large-8 large-centered columns">

<h4>Top-Rated Skincare</h4>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/v/a/vasanti_brightenup_new_900x900.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i id="back" class="fi-heart"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/d/r/drbrandt_poresnomore_vacuumcleaner_900x900.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/suki_exfoliate_foaming_cleanser_120_ml_900x900.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name Extra Long</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/k/skin_co_sicillianlightserum_900x900.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/r/e/realchemistry_3minutepeel_900x900.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/c/a/caudalie_polyphenolc15_overnightdetoxoil_900x900.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/image/460x/9df78eab33525d08d6e5fb8d27136e95/s/u/supergoop_everydaysunscreen_spf50_900x900.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">
<ul>
<ul>
	<li>

<div class="review-thumbnail"><img src="https://www.birchbox.com/shop/media/catalog/product/cache/1/small_image/220x/9df78eab33525d08d6e5fb8d27136e95/s/h/shiseido_ultimune_30ml_900x900.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="reviews-all">See all</div>
</div>

<!--****************************Mobile AD*******************************--> 

<div id="mobile-leaderboard" class="leaderboard-container"><img src="http://placehold.it/728x90" alt="" /></div>

<!--********************************** Bath&nbsp;&amp;&nbsp;Body*********************************--> 

<div class="reviews-section">

<div class="large-8 large-centered columns">

<h4>Top-Rated Bath &amp; Body</h4>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/phyto.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name Extra Long</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i id="back" class="fi-heart"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/bumble_pret.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/briogeo_repair.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/living_proof.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/alterna_caviar.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/ouidad_define.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/dry_bar.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name Extra Long</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/ojon_oil.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="reviews-all">See all</div>
</div>

<!--***********************************Tools&nbsp;/&nbsp;Accessories******************************--> 

<div class="reviews-section">

<div class="large-8 large-centered columns">

<h4>Top-Rated Tools / Accessories</h4>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/phyto.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i id="back" class="fi-heart"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/bumble_pret.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/briogeo_repair.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/living_proof.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/alterna_caviar.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/ouidad_define.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/dry_bar.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name Extra Long</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/ojon_oil.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="reviews-all">See all</div>
</div>

<!--******************************************Fragrances Section*******************************--> 

<div class="reviews-section">

<div class="large-8 large-centered columns">

<h4>Top-Rated Fragrances</h4>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/phyto.jpg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i id="back" class="fi-heart"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/bumble_pret.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/briogeo_repair.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/living_proof.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/alterna_caviar.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/ouidad_define.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/dry_bar.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name Extra Long</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="stylesheets/img/ojon_oil.jpeg" alt="" /></div>

&nbsp;

<div class="review-product-brand">Brand Name</div>

&nbsp;

<div class="review-product-name">Product Name</div>

&nbsp;

<div class="review-rating">

<div class="star-rating"></div>

<span class="review-count">(108)</span>
</div>

&nbsp;

<div class="review-price"><span class="rev-price">$39.00</span></div>

&nbsp;

<div class="review-faves"><i class="fi-heart size-20"></i> <span class="review-fave-count">65</span></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="reviews-all">See all</div>
</div>

<!--******************************************Brands Section************************************--> 

<div class="reviews-section">

<div class="large-8 large-centered columns">

<h4>Top-Rated Brands</h4>

&nbsp;
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Arcona_Logo_168x200_2.png" alt="" /></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Cartier_Logo_168x200.png" alt="" /></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/DrBrandt_logo_168x200_1.png" alt="" /></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Kerastase_168x200_2.png" alt="" /></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Oribe-logo-wall_3.png" alt="" /></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Tweezerman-Logo-168x200_1.png" alt="" /></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/Shu_168x200_1.png" alt="" /></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="small-6 medium-3 large-3 columns">

<ul>
<ul>
	<li data-equalizer-watch="">

<div class="review-thumbnail"><img src="https://www.birchbox.com/men/media/catalog/category/StriVectin_Logo_NEW2014_168x200_1.png" alt="" /></div></li>
</ul>
</ul>

&nbsp;

&nbsp;
</div>

&nbsp;

<div class="reviews-all">See all</div>
</div>
</div>

<!--Aside went here-->
</div>

&nbsp;
</div>

&nbsp;

<div class="row">

<div class="large-12 large-centered columns">

<div class="leaderboard-container"><img src="http://placehold.it/728x90" alt="" /></div>

<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/fastclick/lib/fastclick.js"></script><script src="bower_components/foundation/js/foundation.min.js"></script>
<script src="bower_components/foundation/js/foundation/foundation.equalizer.js"></script><script src="bower_components/foundation/js/foundation/foundation.offcanvas.js"></script>
<script src="slick/slick.min.js"></script><script src="js/app.js"></script>
<script>// <![CDATA[
$(document).foundation();
// ]]></script>
<script>// <![CDATA[
$(document).ready(function(){   $(\'.featured-slider\').slick({     dots: true,     autoplay: true,     autoplaySpeed: 2000,   }); });
// ]]></script>
<script>// <![CDATA[
$(document).foundation({   equalizer : {     // Specify if Equalizer should make elements equal height once they become stacked.     equalize_on_stack: true   } });
// ]]></script>

</div>
</div>', 'Home', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-10-15 01:42:38', '2014-10-15 01:42:38', '', 10, 'http://localhost:8888/2014/10/15/10-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (201, 1, '2014-10-15 01:43:33', '2014-10-15 01:43:33', 'this is a wysiwyg editor', 'Home', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-10-15 01:43:33', '2014-10-15 01:43:33', '', 10, 'http://localhost:8888/2014/10/15/10-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (202, 1, '2014-10-15 18:16:12', '2014-10-15 18:16:12', 'this is a static home page', 'Home', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-10-15 18:16:12', '2014-10-15 18:16:12', '', 10, 'http://localhost:8888/2014/10/15/10-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (212, 1, '2014-10-15 22:55:01', '2014-10-15 22:55:01', ' ', '', '', 'publish', 'open', 'open', '', '212', '', '', '2014-10-16 20:16:20', '2014-10-16 20:16:20', '', 0, 'http://localhost:8888/?p=212', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (215, 1, '2014-10-15 22:58:26', '2014-10-15 22:58:26', '<span style="color: #000000;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span>

<span style="color: #000000;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span>

<span style="color: #000000;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span>', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2014-10-15 22:58:26', '2014-10-15 22:58:26', '', 0, 'http://localhost:8888/?page_id=215', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (216, 1, '2014-10-15 22:58:26', '2014-10-15 22:58:26', '<span style="color: #000000;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span>

<span style="color: #000000;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span>

<span style="color: #000000;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span>', 'About', '', 'inherit', 'open', 'open', '', '215-revision-v1', '', '', '2014-10-15 22:58:26', '2014-10-15 22:58:26', '', 215, 'http://localhost:8888/2014/10/15/215-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (217, 1, '2014-10-15 22:58:59', '2014-10-15 22:58:59', 'this is a static home page

<span style="color: #000000;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </span>

&nbsp;

<span style="color: #000000;">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span>', 'Home', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-10-15 22:58:59', '2014-10-15 22:58:59', '', 10, 'http://localhost:8888/2014/10/15/10-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (218, 1, '2014-10-15 22:59:27', '2014-10-15 22:59:27', '<h3 style="color: #000000;"></h3>
&nbsp;', 'Blog', '', 'publish', 'open', 'open', '', 'blog', '', '', '2014-10-15 22:59:52', '2014-10-15 22:59:52', '', 0, 'http://localhost:8888/?page_id=218', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (219, 1, '2014-10-15 22:59:27', '2014-10-15 22:59:27', '<h3 style="color: #000000;">Section 1.10.32 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC</h3>
<p style="color: #000000;">"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>
&nbsp;', 'Blog', '', 'inherit', 'open', 'open', '', '218-revision-v1', '', '', '2014-10-15 22:59:27', '2014-10-15 22:59:27', '', 218, 'http://localhost:8888/2014/10/15/218-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (220, 1, '2014-10-15 22:59:52', '2014-10-15 22:59:52', '<h3 style="color: #000000;"></h3>
&nbsp;', 'Blog', '', 'inherit', 'open', 'open', '', '218-revision-v1', '', '', '2014-10-15 22:59:52', '2014-10-15 22:59:52', '', 218, 'http://localhost:8888/2014/10/15/218-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (222, 1, '2014-10-16 00:10:26', '2014-10-16 00:10:26', '<p style="color: #555f57;"><span style="font-weight: inherit; font-style: inherit;">Now that summer is in full swing, we can put our winter gear out of it’s misery (read: into storage) and embrace all things sandals and minis. Also - manis. Nails rejoice! From the bright and beautiful to the neutral and classic, Instagram is our go to spot for nail color inpsoration. It’s chock-full of creative manicures to celebrating our escape from a hellish all-consuming winter that chewed us up and spit is out. Let’s paint our nails together and forget.</span></p>
[gallery ids="168,169,170,171,172,173,174,175,166"]
<p style="color: #555f57;"></p>', 'SUMMER MANI INSPIRATION', '', 'inherit', 'open', 'open', '', '165-revision-v1', '', '', '2014-10-16 00:10:26', '2014-10-16 00:10:26', '', 165, 'http://localhost:8888/165-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (223, 1, '2014-10-16 00:31:55', '2014-10-16 00:31:55', 'Lorem Ipsum', 'New Post', '', 'publish', 'open', 'open', '', 'new-post', '', '', '2014-10-16 00:31:55', '2014-10-16 00:31:55', '', 0, 'http://localhost:8888/?p=223', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (224, 1, '2014-10-16 00:31:55', '2014-10-16 00:31:55', 'Lorem Ipsum', 'New Post', '', 'inherit', 'open', 'open', '', '223-revision-v1', '', '', '2014-10-16 00:31:55', '2014-10-16 00:31:55', '', 223, 'http://localhost:8888/223-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (225, 1, '2014-10-16 19:10:53', '2014-10-16 19:10:53', 'Lorem Ipsum Editorial', 'Editorial', '', 'publish', 'open', 'open', '', 'editorial', '', '', '2014-10-16 19:10:53', '2014-10-16 19:10:53', '', 0, 'http://localhost:8888/?page_id=225', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (226, 1, '2014-10-16 19:10:53', '2014-10-16 19:10:53', 'Lorem Ipsum Editorial', 'Editorial', '', 'inherit', 'open', 'open', '', '225-revision-v1', '', '', '2014-10-16 19:10:53', '2014-10-16 19:10:53', '', 225, 'http://localhost:8888/225-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (228, 1, '2014-10-16 19:11:27', '2014-10-16 19:11:27', 'Lorem Ipsum community', 'Community', '', 'publish', 'open', 'open', '', 'community', '', '', '2014-10-16 19:11:27', '2014-10-16 19:11:27', '', 0, 'http://localhost:8888/?page_id=228', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (229, 1, '2014-10-16 19:11:27', '2014-10-16 19:11:27', 'Lorem Ipsum community', 'Community', '', 'inherit', 'open', 'open', '', '228-revision-v1', '', '', '2014-10-16 19:11:27', '2014-10-16 19:11:27', '', 228, 'http://localhost:8888/228-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (230, 1, '2014-10-16 19:11:53', '2014-10-16 19:11:53', 'Lorem Ipsum Exchange', 'Exchange', '', 'publish', 'open', 'open', '', 'exchange', '', '', '2014-10-16 19:11:53', '2014-10-16 19:11:53', '', 0, 'http://localhost:8888/?page_id=230', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (231, 1, '2014-10-16 19:11:53', '2014-10-16 19:11:53', 'Lorem Ipsum Exchange', 'Exchange', '', 'inherit', 'open', 'open', '', '230-revision-v1', '', '', '2014-10-16 19:11:53', '2014-10-16 19:11:53', '', 230, 'http://localhost:8888/230-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (232, 1, '2014-10-16 20:16:20', '2014-10-16 20:16:20', ' ', '', '', 'publish', 'open', 'open', '', '232', '', '', '2014-10-16 20:16:20', '2014-10-16 20:16:20', '', 0, 'http://localhost:8888/?p=232', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (233, 1, '2014-10-16 20:16:20', '2014-10-16 20:16:20', ' ', '', '', 'publish', 'open', 'open', '', '233', '', '', '2014-10-16 20:16:20', '2014-10-16 20:16:20', '', 0, 'http://localhost:8888/?p=233', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (234, 1, '2014-10-16 20:16:20', '2014-10-16 20:16:20', ' ', '', '', 'publish', 'open', 'open', '', '234', '', '', '2014-10-16 20:16:20', '2014-10-16 20:16:20', '', 0, 'http://localhost:8888/?p=234', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (237, 1, '2014-12-15 05:17:05', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-12-15 05:17:05', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=237', 0, 'post', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------


#
# Delete any existing table `wp_signups`
#

DROP TABLE IF EXISTS `wp_signups`;


#
# Table structure of table `wp_signups`
#

CREATE TABLE `wp_signups` (
  `signup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `title` longtext NOT NULL,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activation_key` varchar(50) NOT NULL DEFAULT '',
  `meta` longtext,
  PRIMARY KEY (`signup_id`),
  KEY `activation_key` (`activation_key`),
  KEY `user_email` (`user_email`),
  KEY `user_login_email` (`user_login`,`user_email`),
  KEY `domain_path` (`domain`,`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_signups (0 records)
#

#
# End of data contents of table wp_signups
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (58 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (86, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (86, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (89, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (89, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (92, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (92, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (95, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (95, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (98, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (98, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (101, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (101, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (104, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (104, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (107, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (107, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (110, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (110, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (113, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (113, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (116, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (116, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (119, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (119, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (122, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (122, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (125, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (125, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (128, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (128, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (131, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (131, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (134, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (134, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (137, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (137, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (140, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (140, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (143, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (143, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (146, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (146, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (149, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (149, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (152, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (152, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (162, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (162, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (162, 18, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (165, 19, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (165, 20, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (212, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (223, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (232, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (233, 21, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (234, 21, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (21 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'product_type', '', 0, 23) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'product_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'product_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'product_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 6, 'shop_order_status', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'shop_order_status', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 8, 'shop_order_status', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (9, 9, 'shop_order_status', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (10, 10, 'shop_order_status', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (11, 11, 'shop_order_status', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (12, 12, 'shop_order_status', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (13, 13, 'product_shipping_class', '', 0, 23) ; 
INSERT INTO `wp_term_taxonomy` VALUES (14, 14, 'post_format', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (15, 15, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (16, 16, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (17, 17, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (18, 18, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (19, 19, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (20, 20, 'post_format', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (21, 21, 'nav_menu', '', 0, 4) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `name` (`name`),
  KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (21 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'simple', 'simple', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'grouped', 'grouped', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'variable', 'variable', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'external', 'external', 0) ; 
INSERT INTO `wp_terms` VALUES (6, 'pending', 'pending', 0) ; 
INSERT INTO `wp_terms` VALUES (7, 'failed', 'failed', 0) ; 
INSERT INTO `wp_terms` VALUES (8, 'on-hold', 'on-hold', 0) ; 
INSERT INTO `wp_terms` VALUES (9, 'processing', 'processing', 0) ; 
INSERT INTO `wp_terms` VALUES (10, 'completed', 'completed', 0) ; 
INSERT INTO `wp_terms` VALUES (11, 'refunded', 'refunded', 0) ; 
INSERT INTO `wp_terms` VALUES (12, 'cancelled', 'cancelled', 0) ; 
INSERT INTO `wp_terms` VALUES (13, '-1', '1', 0) ; 
INSERT INTO `wp_terms` VALUES (14, 'post-format-image', 'post-format-image', 0) ; 
INSERT INTO `wp_terms` VALUES (15, 'Skin', 'skin', 0) ; 
INSERT INTO `wp_terms` VALUES (16, 'Hair', 'hair', 0) ; 
INSERT INTO `wp_terms` VALUES (17, 'Makeup', 'makeup', 0) ; 
INSERT INTO `wp_terms` VALUES (18, 'Wellness', 'wellness', 0) ; 
INSERT INTO `wp_terms` VALUES (19, 'Nails', 'nails', 0) ; 
INSERT INTO `wp_terms` VALUES (20, 'post-format-gallery', 'post-format-gallery', 0) ; 
INSERT INTO `wp_terms` VALUES (21, 'Desktop Header Navigation Menu', 'desktop-header-navigation-menu', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (77 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'rfombrun') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets,pksn1') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '237') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'last_activity', '2014-10-15 01:29:09') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, '_woocommerce_persistent_cart', 'a:1:{s:4:"cart";a:0:{}}') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'mycred_comment_limit_post', 'a:5:{i:152;i:1;i:122;i:1;i:95;i:1;i:165;i:1;i:101;i:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'mycred_default', '2092') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'wp_user-settings', 'libraryContent=browse&imgsize=full&advImgDetails=show&editor=tinymce') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'wp_user-settings-time', '1413337353') ; 
INSERT INTO `wp_usermeta` VALUES (21, 2, 'first_name', 'marie') ; 
INSERT INTO `wp_usermeta` VALUES (22, 2, 'last_name', 'f') ; 
INSERT INTO `wp_usermeta` VALUES (23, 2, 'nickname', 'mcfombrun') ; 
INSERT INTO `wp_usermeta` VALUES (24, 2, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (25, 2, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (26, 2, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (27, 2, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (28, 2, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (29, 2, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (30, 2, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (31, 2, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (32, 2, 'mycred_default', '100') ; 
INSERT INTO `wp_usermeta` VALUES (33, 2, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (34, 3, 'first_name', 'carron') ; 
INSERT INTO `wp_usermeta` VALUES (35, 3, 'last_name', 'w') ; 
INSERT INTO `wp_usermeta` VALUES (36, 3, 'nickname', 'carrot') ; 
INSERT INTO `wp_usermeta` VALUES (37, 3, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (38, 3, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (39, 3, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (40, 3, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (41, 3, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (42, 3, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (43, 3, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (44, 3, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (45, 3, 'mycred_default', '100') ; 
INSERT INTO `wp_usermeta` VALUES (46, 3, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (47, 2, 'billing_first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (48, 2, 'billing_last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (49, 2, 'billing_company', '') ; 
INSERT INTO `wp_usermeta` VALUES (50, 2, 'billing_address_1', '') ; 
INSERT INTO `wp_usermeta` VALUES (51, 2, 'billing_address_2', '') ; 
INSERT INTO `wp_usermeta` VALUES (52, 2, 'billing_city', '') ; 
INSERT INTO `wp_usermeta` VALUES (53, 2, 'billing_postcode', '') ; 
INSERT INTO `wp_usermeta` VALUES (54, 2, 'billing_state', '') ; 
INSERT INTO `wp_usermeta` VALUES (55, 2, 'billing_country', '') ; 
INSERT INTO `wp_usermeta` VALUES (56, 2, 'billing_phone', '') ; 
INSERT INTO `wp_usermeta` VALUES (57, 2, 'billing_email', '') ; 
INSERT INTO `wp_usermeta` VALUES (58, 2, 'shipping_first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (59, 2, 'shipping_last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (60, 2, 'shipping_company', '') ; 
INSERT INTO `wp_usermeta` VALUES (61, 2, 'shipping_address_1', '') ; 
INSERT INTO `wp_usermeta` VALUES (62, 2, 'shipping_address_2', '') ; 
INSERT INTO `wp_usermeta` VALUES (63, 2, 'shipping_city', '') ; 
INSERT INTO `wp_usermeta` VALUES (64, 2, 'shipping_postcode', '') ; 
INSERT INTO `wp_usermeta` VALUES (65, 2, 'shipping_state', '') ; 
INSERT INTO `wp_usermeta` VALUES (66, 2, 'shipping_country', '') ; 
INSERT INTO `wp_usermeta` VALUES (67, 2, 'last_activity', '2014-08-27 19:21:16') ; 
INSERT INTO `wp_usermeta` VALUES (70, 2, 'bp_latest_update', 'a:2:{s:2:"id";i:3;s:7:"content";s:62:"@rfombrun lookin good with that hat. where was that pic taken?";}') ; 
INSERT INTO `wp_usermeta` VALUES (71, 2, 'bp_favorite_activities', 'a:1:{i:0;s:1:"3";}') ; 
INSERT INTO `wp_usermeta` VALUES (72, 2, '_woocommerce_persistent_cart', 'a:1:{s:4:"cart";a:0:{}}') ; 
INSERT INTO `wp_usermeta` VALUES (73, 1, 'closedpostboxes_product', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (74, 1, 'metaboxhidden_product', 'a:1:{i:0;s:7:"slugdiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (75, 1, 'closedpostboxes_dashboard', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (76, 1, 'metaboxhidden_dashboard', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (77, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (78, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}') ; 
INSERT INTO `wp_usermeta` VALUES (79, 1, 'nav_menu_recently_edited', '21') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (3 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'rfombrun', '$P$BFxRbFl1UPz/b1EbObOboHqdB9FQ820', 'rfombrun', 'rfombrun@gmail.com', '', '2014-05-26 22:33:13', '', 0, 'rfombrun') ; 
INSERT INTO `wp_users` VALUES (2, 'mcfombrun', '$P$BovqfATEXXqWTMdRGZIp4ZWoOdehYd.', 'mcfombrun', 'mcfombrun@gmail.com', '', '2014-08-27 17:40:47', '', 0, 'marie f') ; 
INSERT INTO `wp_users` VALUES (3, 'carrot', '$P$B5q9EnG/Bh5Rb62P9nxnbtQmD1svBW1', 'carrot', 'carronwhite@gmail.com', '', '2014-08-27 17:41:53', '', 0, 'carron w') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` longtext,
  `attribute_type` varchar(200) NOT NULL,
  `attribute_orderby` varchar(200) NOT NULL,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_attribute_taxonomies (0 records)
#

#
# End of data contents of table wp_woocommerce_attribute_taxonomies
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`,`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_downloadable_product_permissions (0 records)
#

#
# End of data contents of table wp_woocommerce_downloadable_product_permissions
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_order_itemmeta (0 records)
#

#
# End of data contents of table wp_woocommerce_order_itemmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_order_items (0 records)
#

#
# End of data contents of table wp_woocommerce_order_items
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(255) NOT NULL,
  `tax_rate_id` bigint(20) NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_tax_rate_locations (0 records)
#

#
# End of data contents of table wp_woocommerce_tax_rate_locations
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) NOT NULL DEFAULT '',
  `tax_rate` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) NOT NULL,
  `tax_rate_class` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`),
  KEY `tax_rate_class` (`tax_rate_class`),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_tax_rates (0 records)
#

#
# End of data contents of table wp_woocommerce_tax_rates
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_woocommerce_termmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_termmeta`;


#
# Table structure of table `wp_woocommerce_termmeta`
#

CREATE TABLE `wp_woocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `woocommerce_term_id` (`woocommerce_term_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_woocommerce_termmeta (0 records)
#

#
# End of data contents of table wp_woocommerce_termmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wsi_queue`
# --------------------------------------------------------


#
# Delete any existing table `wp_wsi_queue`
#

DROP TABLE IF EXISTS `wp_wsi_queue`;


#
# Table structure of table `wp_wsi_queue`
#

CREATE TABLE `wp_wsi_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Index ID',
  `provider` varchar(32) NOT NULL COMMENT 'Provider Name',
  `user_id` int(11) DEFAULT NULL COMMENT 'User''s ID',
  `sdata` text COMMENT 'hybrid session data',
  `friends` text COMMENT 'serialized array of emails or facebook ids etc',
  `i_count` int(11) DEFAULT NULL COMMENT 'Quantity of Invitations',
  `date_added` datetime NOT NULL,
  `display_name` varchar(120) DEFAULT NULL COMMENT 'Display name in provider',
  `subject` text COMMENT 'message subject',
  `message` text COMMENT 'message',
  `send_at` int(10) DEFAULT NULL COMMENT 'When to send invitation',
  PRIMARY KEY (`id`),
  KEY `provider` (`provider`),
  KEY `date_added` (`date_added`,`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_wsi_queue (0 records)
#

#
# End of data contents of table wp_wsi_queue
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 21. December 2014 07:27 UTC
# Hostname: localhost
# Database: `prettytendr`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_activity_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_notifications`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_groups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_bp_xprofile_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_myCRED_log`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_imports`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_pmxi_templates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_signups`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_order_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_tax_rates`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_woocommerce_termmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wsi_queue`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wsi_stats`
# --------------------------------------------------------


#
# Delete any existing table `wp_wsi_stats`
#

DROP TABLE IF EXISTS `wp_wsi_stats`;


#
# Table structure of table `wp_wsi_stats`
#

CREATE TABLE `wp_wsi_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Index ID',
  `provider` varchar(32) NOT NULL COMMENT 'Provider Name',
  `user_id` int(11) DEFAULT NULL COMMENT 'User''s ID',
  `quantity` int(11) DEFAULT NULL COMMENT 'Quantity of friends invited',
  `queue_id` int(11) DEFAULT NULL COMMENT 'original id from queue',
  `i_datetime` datetime NOT NULL,
  `display_name` varchar(120) DEFAULT NULL COMMENT 'Display name in provider',
  PRIMARY KEY (`id`),
  KEY `provider` (`provider`),
  KEY `i_datetime` (`i_datetime`,`user_id`,`queue_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_wsi_stats (2 records)
#
 
INSERT INTO `wp_wsi_stats` VALUES (1, 'mail', 1, 1, 1, '2014-07-21 19:44:01', '') ; 
INSERT INTO `wp_wsi_stats` VALUES (2, 'mail', 1, 2, 2, '2014-07-21 19:44:01', '') ;
#
# End of data contents of table wp_wsi_stats
# --------------------------------------------------------

